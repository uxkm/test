<route lang="yaml">
meta:
  id: SAT049A07
  title: 약관동의 (선택약관)
  menu: 자산 > 금융추천 > 대출 > 정보계좌 관리 > 금융사 연결현황 > 선택약관(BS) > 약관동의 (선택약관)
  layout: SubLayout
  category: 자산
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  header:
    fixed: true
    back: true
    home: true
</route>
<template>
  <div class="sc-contents__body sc-agree__page">
    <section class="section">
      <div class="agree-select-type__header">
        <h2 class="agree-select-type__title">동의등급제 유형 선택</h2>
        <Tooltip
          placement="top-center"
          :show-close="true"
          class="select-type__tooltip"
        >
          <template #content>
            <div class="sc-tooltip__content">
              <span class="sc-tooltip-content__title"
                >동의서 고지사항의 요약</span
              >
              <UnorderedList :gap="4">
                <UnorderedListItem
                  variant="bullet"
                  size="small"
                  text="동의서(고지사항 중 그 일부를 생략하거나 중요한 사항만을 발췌) 또는 전체 동의서 (고지사항 전 항목을 표기)를 선택할 수 있습니다."
                />
                <UnorderedListItem
                  variant="bullet"
                  size="small"
                  text="동의서 유형에 따라 노출되는 동의서 전문이 변경되며 동의항목 수는 유형에 상관없이 동일합니다."
                />
              </UnorderedList>
            </div>
          </template>
        </Tooltip>
      </div>
      <SelectBoxGroup
        v-model="selected"
        :disabled="false"
        :items="items"
        :multiple="false"
        orientation="horizontal"
      />
    </section>

    <Divider variant="group" color="tertiary" />

    <section class="section">
      <div class="sc-agree__list compound" role="region">
        <div class="agree-list__group">
          <div
            class="agree-item item-basic"
            :class="{ 'is-checked': basicAgree }"
          >
            <Checkbox
              v-model="basicAgree"
              class="agree-item__checkbox item-checkbox__basic"
              variant="box"
              align="left"
            >
              <template #label>
                <span class="agree-item__label item-label__basic">{{
                  basicItem.label
                }}</span>
              </template>
            </Checkbox>
          </div>

          <div class="section">
            <!-- ======================================== -->
            <!-- 동의등급제 안내 -->
            <!-- ======================================== -->
            <Card
              variant="solid"
              color="gray"
              class="agree-info__card card-white"
            >
              <div class="info-card__header">
                <p class="info-card__title">동의등급제 안내</p>
              </div>
              <div class="info-card__content">
                <div class="label-group">
                  <SolidLabel color="cyan" title="안심" />
                  <SolidLabel color="green" title="다소안심" />
                  <SolidLabel color="yellow" title="보통" />
                  <SolidLabel color="orange" title="신중" />
                  <SolidLabel color="red" title="주의" />
                </div>
                <UnorderedList>
                  <UnorderedListItem
                    variant="bullet"
                    size="small"
                    text="동의등급제는 개인(신용) 선택적 동의 항목에 대해 사생활의 비밀과 자유를 침해할 위험, 이익이나 혜택, 등의 내용의 명확성 등을 고려하여 5가지 등급을 부여하는 제도입니다."
                  />
                </UnorderedList>
              </div>
            </Card>
          </div>

          <!-- ======================================== -->
          <!-- 1뎁스 영역: 기본 약관 항목들 -->
          <!-- ======================================== -->
          <div class="agree-sublist" role="group">
            <div
              v-for="item in subItems"
              :key="item.value"
              class="agree-subitem"
              :class="{ 'agree-subitem__accordion': Boolean(item.accordion) }"
            >
              <template v-if="item.accordion">
                <SolidListAccordion
                  class="agree-subitem__accordion"
                  :rowClickable="false"
                  :value="item.value"
                  v-model:isExpanded="subAccordionState[item.value]"
                >
                  <template #title>
                    <div
                      class="agree-item agree-item__sub"
                      :class="{
                        'is-checked': subAgrees.includes(item.value),
                      }"
                    >
                      <Checkbox
                        :value="item.value"
                        variant="box"
                        align="left"
                        :model-value="subAgrees.includes(item.value)"
                        class="agree-item__checkbox item-checkbox__sub"
                        @update:model-value="onToggleSub(item.value, $event)"
                        @click.stop
                      >
                        <template #label>
                          <span class="agree-item__label item-label__sub">{{
                            item.label
                          }}</span>
                        </template>
                      </Checkbox>
                    </div>
                  </template>
                  <div class="agree-subitem__panel">
                    <div v-if="item.value === 'depth1'" class="agree-depth">
                      <!-- ======================================== -->
                      <!-- 2뎁스 영역: 개인(신용)정보 선택적 동의 -->
                      <!-- ======================================== -->
                      <ul class="agree-sublist agree-sublist__depth2">
                        <li
                          v-for="depth2Item in subItemsDepth2"
                          :key="depth2Item.value"
                          class="agree-subitem agree-subitem__depth2"
                        >
                          <!-- 마케팅 정보 수신 동의는 아코디언 없이 바로 하위 항목 표시 -->
                          <template
                            v-if="depth2Item.value === 'depth2-marketing'"
                          >
                            <div
                              class="agree-item agree-item__sub"
                              :class="{
                                'is-checked': subAgrees.includes(
                                  depth2Item.value
                                ),
                              }"
                            >
                              <Checkbox
                                :value="depth2Item.value"
                                variant="mark"
                                align="left"
                                :model-value="
                                  subAgrees.includes(depth2Item.value)
                                "
                                class="agree-item__checkbox item-checkbox__sub"
                                @update:model-value="
                                  onToggleSub(depth2Item.value, $event)
                                "
                                @click.stop
                              >
                                <template #label>
                                  <span
                                    class="agree-item__label item-label__sub"
                                    >{{ depth2Item.label }}</span
                                  >
                                </template>
                              </Checkbox>
                            </div>
                            <div
                              class="agree-subitem__panel depth-panel pr-none pl-4xl"
                            >
                              <div class="agree-depth">
                                <Card
                                  variant="solid"
                                  color="gray"
                                  class="agree-details card-color__graylight"
                                >
                                  <ul
                                    class="agree-sublist agree-sublist__depth2"
                                    role="group"
                                  >
                                    <li
                                      v-for="marketingItem in marketingItems"
                                      :key="marketingItem.value"
                                      class="agree-subitem agree-subitem__depth2"
                                    >
                                      <div class="agree-item agree-item__sub">
                                        <Checkbox
                                          :value="marketingItem.value"
                                          variant="mark"
                                          align="left"
                                          :model-value="
                                            subAgrees.includes(
                                              marketingItem.value
                                            )
                                          "
                                          class="agree-item__checkbox item-checkbox__sub"
                                          @update:model-value="
                                            onToggleSub(
                                              marketingItem.value,
                                              $event
                                            )
                                          "
                                          @click.stop
                                        >
                                          <template #label>
                                            <span
                                              class="agree-item__label item-label__sub"
                                              >{{ marketingItem.label }}</span
                                            >
                                          </template>
                                        </Checkbox>
                                      </div>
                                    </li>
                                  </ul>
                                </Card>
                              </div>
                            </div>
                          </template>
                          <!-- 나머지 2뎁스 항목들은 아코디언 없이 체크박스와 화살표만 -->
                          <template v-else>
                            <div class="agree-item agree-item__sub">
                              <Checkbox
                                :value="depth2Item.value"
                                variant="mark"
                                align="left"
                                :model-value="
                                  subAgrees.includes(depth2Item.value)
                                "
                                class="agree-item__checkbox item-checkbox__sub"
                                @update:model-value="
                                  onToggleSub(depth2Item.value, $event)
                                "
                                @click.stop
                              >
                                <template #label>
                                  <span class="column-line">
                                    <span
                                      class="agree-item__label item-label__sub"
                                      >{{ depth2Item.label }}</span
                                    >
                                    <small
                                      v-if="depth2Item.grade"
                                      class="agree-item-label__description"
                                    >
                                      <SolidLabel
                                        :color="depth2Item.grade"
                                        :title="
                                          depth2Item.grade === 'yellow'
                                            ? '보통'
                                            : depth2Item.grade === 'orange'
                                              ? '신중'
                                              : depth2Item.grade === 'green'
                                                ? '다소안심'
                                                : ''
                                        "
                                        :aria-label="`동의등급제 ${
                                          depth2Item.grade === 'yellow'
                                            ? '보통'
                                            : depth2Item.grade === 'orange'
                                              ? '신중'
                                              : depth2Item.grade === 'green'
                                                ? '다소안심'
                                                : ''
                                        }`"
                                      />
                                    </small>
                                  </span>
                                </template>
                              </Checkbox>
                              <IconButton
                                iconName="Chevron_right"
                                size="small"
                                :aria-label="`${depth2Item.label} 상세 보기`"
                                class="agree-subitem__trigger"
                              />
                            </div>
                          </template>
                        </li>
                      </ul>

                      <!-- 개인정보 처리방침 링크 -->
                      <div class="agree-depth__link">
                        <TextButton
                          class="agree-depth__link"
                          color="secondary"
                          size="small"
                          text="개인정보 처리방침"
                          showGoTo
                        />
                      </div>
                    </div>
                  </div>
                </SolidListAccordion>
              </template>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <BottomActionContainer :scrollDim="true">
    <BoxButtonGroup size="xlarge" variant="100">
      <BoxButton text="확인" :disabled="!basicAgree" />
    </BoxButtonGroup>
  </BottomActionContainer>
</template>

<script setup>
import {
  BottomActionContainer,
  BoxButton,
  BoxButtonGroup,
  Card,
  Checkbox,
  Divider,
  IconButton,
  Infobox,
  SelectBoxGroup,
  SolidLabel,
  SolidListAccordion,
  TextButton,
  Tooltip,
  UnorderedList,
  UnorderedListItem,
} from "@shc-nss/ui/solid";
import { reactive, ref, watch } from "vue";

const selected = ref("1");
const items = [
  {
    label: "요약 동의서",
    value: "1",
  },
  {
    label: "전체 동의서",
    value: "2",
  },
];

const basicItem = {
  label: "약관 전체 동의",
};

// 1뎁스 항목들
const subItems = [
  {
    label: "[선택] 개인(신용)정보의 수집 및 이용동의",
    value: "depth1",
    accordion: true,
  },
];

// 2뎁스 항목들
const subItemsDepth2 = [
  {
    label: "카드 및 금융상품서비스 안내 및 이용권유를 위한 수집·이용",
    value: "depth2-1",
    grade: "yellow", // 보통
  },
  {
    label: "카드 및 금융상품서비스 이외의 부수서비스 안내 등을 위한 수집·이용",
    value: "depth2-2",
    grade: "orange", // 신중
  },
  {
    label: "혁신금융 서비스 이용동의",
    value: "depth2-3",
    grade: "green", // 다소안심
  },
  {
    label: "마케팅 정보 수신 동의",
    value: "depth2-marketing",
  },
];

// 마케팅 정보 수신 동의 항목들
const marketingItems = [
  { label: "전화", value: "depth2-marketing-1" },
  { label: "문자메시지", value: "depth2-marketing-2" },
  { label: "이메일", value: "depth2-marketing-3" },
  { label: "앱 푸시", value: "depth2-marketing-4" },
];

const basicAgree = ref(false);
const subAgrees = ref([]);
const subAccordionState = reactive({
  depth1: true, // 개인(신용)정보 선택적 동의 - 처음에 펼침 상태
});

/**
 * 동작 로직
 */
function onToggleSub(value, checked) {
  const set = new Set(subAgrees.value);

  // 마케팅 정보 수신 동의 체크/해제 시 하위 항목들도 함께 처리
  if (value === "depth2-marketing") {
    if (checked) {
      set.add(value);
      // 하위 항목들도 모두 체크
      marketingItems.forEach((item) => set.add(item.value));
    } else {
      set.delete(value);
      // 하위 항목들도 모두 해제
      marketingItems.forEach((item) => set.delete(item.value));
    }
  } else {
    if (checked) set.add(value);
    else set.delete(value);
  }

  subAgrees.value = Array.from(set);

  // 전체 항목 수 계산 (1뎁스 + 2뎁스 + 마케팅)
  const totalItems =
    subItems.length + subItemsDepth2.length + marketingItems.length + 1; // 마케팅 정보 수신 동의
  basicAgree.value = set.size === totalItems;
}

watch(basicAgree, (checked) => {
  if (checked) {
    // 1뎁스 항목들 + 2뎁스 항목들 + 마케팅
    const allItems = [
      ...subItems.map((item) => item.value),
      ...subItemsDepth2.map((item) => item.value),
      "depth2-marketing", // 마케팅 정보 수신 동의
      ...marketingItems.map((item) => item.value),
    ];
    subAgrees.value = allItems;
  } else {
    subAgrees.value = [];
  }
});
</script>
