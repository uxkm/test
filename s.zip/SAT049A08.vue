<route lang="yaml">
meta:
  id: SAT049A08
  title: 약관동의 (선택약관)
  menu: 자산 > 금융추천 > 대출 > 정보계좌 관리 > 금융사 연결현황 > 선택약관(BS) > 약관상세 (FP)
  layout: SubLayout
  category: 자산
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  header:
    fixed: true
    back: true
    home: true
</route>
<template>
  <FullPopup
    v-model="isOpen"
    title="동의등급제 선택 약관"
    class="sc-terms__popup"
  >
    <div class="terms-content" style="height:100%;background-color: var(--gray-50)">
      <!-- 약관 내용, 개발 시 style="background-color는 제거" -->
    </div>
    <!-- footer -->
    <template #footer>
      <div class="sc-pagination__container">
        <NumberPagination color="fixedBlack" :current="1" size="small" :total="5" />
      </div>
      <BottomActionContainer :scrollDim="true">
        <BoxButtonGroup
          size="xlarge"
          variant="50:50"
        >
          <BoxButton
            text="닫기"
            color="secondary"
          />
          <BoxButton
            text="확인"
          />
        </BoxButtonGroup>
      </BottomActionContainer>
    </template>
  </FullPopup>
</template>

<script setup>
import { 
  BottomActionContainer,
  BoxButton,
  BoxButtonGroup,
  FullPopup,
  NumberPagination, 
} from "@shc-nss/ui/solid";
const isOpen = defineModel({ default: true });
</script>
