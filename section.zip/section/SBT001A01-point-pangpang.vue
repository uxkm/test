<template>
  <section class="bf-point-pangpang" aria-label="포인트팡팡">
    <!-- S: 로딩 스켈레톤-->
    <div class="bf-point-pangpang__inner" aria-label="로딩중" tabindex="0">
      <div class="bf-point-pangpang__contents" aria-hidden="true">
        <div class="bf-point-pangpang__title">
          <LoadingSkeleton :width="242" :height="48" rounded="small" />
        </div>
        <div class="bf-point-pangpang__button">
          <LoadingSkeleton :width="120" :height="32" rounded="small" />
        </div>
      </div>
    </div>
    <!-- E: 로딩 스켈레톤-->

    <div class="bf-point-pangpang__inner" aria-label="로딩중" tabindex="0">
      <ScLottie
        :animation-link="$cdnURL + '/images/lottie/pay/benefit_lottie.json'"
        :width="80"
        :height="80"
        class="bf-point-pangpang__lottie-item"
        aria-hidden="true"
      />
      <ScLottie
        :animation-link="$cdnURL + '/images/lottie/pay/benefit_lottie.json'"
        :width="80"
        :height="80"
        class="bf-point-pangpang__lottie-item"
        aria-hidden="true"
      />
      <div class="bf-point-pangpang__contents">
        <h2 class="bf-point-pangpang__title">
          <!-- 포인트 팡팡 -->
          <span>매일매일 출석체크,<br />오늘이 지나면 포인트가 사라져요!</span>
          <!-- 머니박스 -->
          <span>오늘의 머니박스,<br />열기만 해도 포인트가 와르르!</span>
          <!-- 운세 -->
          <span>오늘의 운세 보고<br />행운 포인트 놓치지 마세요!</span>
          <!-- 가위바위보 -->
          <span>가위바위보 한 판!<br />이기면 포인트가 쏟아져요!</span>
        </h2>
        <BoxButton text="포인트 받기" color="primary" size="small" />
      </div>
    </div>
  </section>
</template>

<script setup>
import { inject } from "vue";
import { AppContextKey } from "@/configs/inject/appContext";
import { ScLottie } from "@shc-nss/ui/shc";
import { BoxButton, LoadingSkeleton } from "@shc-nss/ui/solid";

const { $cdnURL } = inject(AppContextKey);
</script>
