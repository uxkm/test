<template>
  <!-- S: 앱테크 -->
  <section class="bf-apptech">
    <!-- S : 데일리 포인트 로딩중 스켈레톤 -->
    <article class="bf-apptech__list" aria-label="로딩중">
      <div class="bf-section__header px-5" aria-hidden="true">
        <div class="description">
          <LoadingSkeleton :width="200" :height="22" rounded="small" />
        </div>
        <h2 class="title-sub">SOL쏠하게 모이는 데일리 포인트</h2>
      </div>
      <ul class="webzine-list skeleton" aria-hidden="true">
        <li v-for="n in 3" :key="n" class="webzine-item">
          <div class="webzine-item__thumbnail">
            <LoadingSkeleton :width="48" :height="48" rounded="medium" />
          </div>
          <div class="webzine-item__content">
            <LoadingSkeleton width="90%" :height="22" rounded="small" />
            <LoadingSkeleton width="100%" :height="22" rounded="small" />
          </div>
        </li>
      </ul>

      <div class="bf-section__footer">
        <CapsuleButton
          text="앱테크 전체보기"
          color="primary"
          variant="outline"
          size="medium"
          :rightIcon="{ iconName: 'Chevron_right' }"
        />
      </div>
    </article>
    <article aria-label="로딩중">
      <LoadingSkeleton width="100%" :height="93" rounded="small" />
    </article>
    <!-- E : 데일리 포인트 로딩중 스켈레톤 -->

    <!--
      추천 앱테크 목록 영역
      1-1. 실시간 참여자 수 
        - 앱테크 메인 페이지의 당일 누적 조회수(page View)를 기반
        - 카운팅 데이터는 실시간 반영이 아닌 지정된 시간에 배치 처리 방식으로 집계
          - 지정 시간 : 07시 / 10시 / 13시 / 16시 / 20시 / 23시
          - 집계 시 누적 조회수가 100이하인 경우 실시간 참여자 수 표시가 아닌 지정 문구 노출
        - 1조회수를 1명 단위로 표기
          - 0~999 : 숫자 그대로 표기
          - 1,000~9,999 : 천단위 쉼표 표시하여 숫자로 표기
          - 10,000 이상 : 만 단위 적용하여 한글 숫자 단위로 표기
          (ex.24,000명 → 2만 4,000명)- 100,000 이상 : 만 단위 + 천단위까지 표기 (ex.153,500명 → 15만 3,500명)
      1-2. 앱테크 리스트 
        앱테크 리스트 3개 노출 (순서대로 노출)
          - 라이브 방송
          - 사다리 타기
          - 룰렛 돌리기
        앱테크 리스트 Tap > 해당 앱테크 상세 화면으로 이동
        (TBD) 리스트형 AD사용하는 경우, 앱테크 리스트 3개 중 마지막 목록에 리스트형 AD노출 (리스트형 AD는 향후 운영에서 반영 예정)
      1-3. '앱테크 전체보기' Tap > [SBT068A01_앱테크 메인] 화면으로 이동 
    -->
    <!-- S: 앱테크 리스트 -->
    <article class="bf-apptech__list">
      <div class="bf-section__header px-5">
        <p class="description">지금 2만 4,000명이 참여 중</p>
        <p class="description">오늘 받을 수 있는 포인트 놓치지 마세요!</p>
        <h2 class="title-sub">SOL쏠하게 모이는 데일리 포인트</h2>
      </div>
      <ul class="sc-point-more__list">
        <li v-for="(item, index) in pointMoreList" :key="index">
          <a
            role="link"
            tabindex="0"
            :aria-label="[item.label, item.sub].filter(Boolean).join(', ')"
            class="point-more__item"
          >
            <ListItem align="centered" aria-hidden="true">
              <template #leftIcon>
                <div class="point-icon">
                  <ScImage :src="item.icon" alt="" aria-hidden="true" />
                </div>
              </template>
              <template #leftMainText>
                <span>{{ item.label }}</span>
              </template>
              <template #leftSubText>
                <span>{{ item.sub }}</span>
              </template>
            </ListItem>
          </a>
        </li>
      </ul>

      <div class="bf-section__footer">
        <CapsuleButton
          text="앱테크 전체보기"
          color="primary"
          variant="outline"
          size="medium"
          :rightIcon="{ iconName: 'Chevron_right' }"
        />
      </div>
    </article>
    <!-- E: 앱테크 리스트 -->

    <!--
      외부 광고 영역 
      - 외부 광고 배너 노출 
        - 웹 SDK 사용
        - 랜덤 AD 노출
        - 앱 추적 허용(iOS) 미설정 사용자에게는 해당 영역 미노출
      - 게시중인 광고 없는 경우 영역 히든
    -->
    <!-- S: 외부 광고 배너 -->
    <article aria-label="외부 광고 배너">
      <a
        role="link"
        tabindex="0"
        aria-label="익시오 앱 무료 다운로드 이동"
        class="export-banner__link"
      >
        <img
          :src="`${$cdnURL}/images/pages/benefits/main/img_export.png`"
          alt="익시오 앱 무료 다운로드 - 통화녹음&요약 AI앱 익시오 AD Moloco 광고입니다."
          class="export-banner"
        />
      </a>
    </article>
    <!-- E: 외부 광고 배너 -->

    <!-- S : 할인·쿠폰 IF 오류시 노출 -->
    <div class="bf-if__error">
      <div class="bf-if__error-inner">
        <div class="bf-if__error-icon">
          <ScImage
            :src="`${$cdnURL}/images/pages/benefits/main/result_icon.png`"
            alt="IF 오류"
          />
        </div>
        <div class="bf-if__error-text">정보를 불러오지 못했어요</div>
        <CapsuleButton
          text="다른 앱테크 확인하기"
          color="primary"
          variant="outline"
          size="small"
        />
      </div>
    </div>
    <!-- E : 할인·쿠폰 IF 오류시 노출 -->
  </section>
  <!-- E: 앱테크 -->
</template>

<script setup>
import { inject } from "vue";
import { AppContextKey } from "@/configs/inject/appContext";
import { ScImage } from "@shc-nss/ui/shc";
import {
  CapsuleButton,
  ListItem,
  LoadingSkeleton,
} from "@shc-nss/ui/solid";

const { $cdnURL } = inject(AppContextKey);

const pointMoreList = [
  {
    label: "라이브 방송",
    sub: "방송 알림 신청하고 시청한 후 포인트 받아가세요.",
    icon: `${$cdnURL}/images/pages/benefits/main/icon_point_list01.png`,
    link: "#",
  },
  {
    label: "사다리 타기",
    sub: "사다리 타고 최대 5,000P 받아가세요.",
    icon: `${$cdnURL}/images/pages/benefits/main/icon_point_list02.png`,
    link: "#",
  },
  {
    label: "룰렛 돌리기",
    sub: "룰렛 돌리고 최대 1만P 받아가세요.",
    icon: `${$cdnURL}/images/pages/benefits/main/icon_point_list03.png`,
    link: "#",
  },
];
</script>

