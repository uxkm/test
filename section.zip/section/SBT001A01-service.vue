<template>
  <!-- S: 혜택 서비스 -->
  <section class="section bf-service bg-gray">
    <div class="bf-section__header">
      <h2 class="title-sub">일상의 즐거움을 더하는 혜택 서비스</h2>
    </div>
    <ul class="bf-service__list">
      <li v-for="(item, index) in serviceList" :key="index">
        <TextButton :text="item.label" color="secondary" class="bf-service__item">
          <template #leftIcon>
            <div class="bf-service__icon">
              <LoadingSkeleton
                v-if="!imageLoaded[index]"
                width="100%"
                height="100%"
                rounded="small"
              />
              <img
                :src="item.image"
                :alt="item.label"
                :style="{ display: imageLoaded[index] ? 'block' : 'none' }"
                @load="imageLoaded[index] = true"
                @error="imageLoaded[index] = true"
              />
            </div>
          </template>
        </TextButton>
      </li>
    </ul>
  </section>
  <!-- E: 혜택 서비스 -->
</template>

<script setup>
import { inject, reactive } from "vue";
import { AppContextKey } from "@/configs/inject/appContext";
import { LoadingSkeleton, TextButton } from "@shc-nss/ui/solid";

const { $cdnURL } = inject(AppContextKey);

// 서비스 리스트 데이터
const serviceList = [
  {
    image: `${$cdnURL}/images/pages/benefits/main/icon_service_app1.png`,
    label: "탑스쿠폰",
  },
  {
    image: `${$cdnURL}/images/pages/benefits/main/icon_service_app2.png`,
    label: "마이샵",
  },
  {
    image: `${$cdnURL}/images/pages/benefits/main/icon_service_app3.png`,
    label: "기프트샵",
  },
  {
    image: `${$cdnURL}/images/pages/benefits/main/icon_service_app4.png`,
    label: "땡겨요",
  },
];

// 이미지 로딩 상태 관리
const imageLoaded = reactive({});
</script>
