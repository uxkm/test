<template>
  <!-- S: 할인·쿠폰 -->
  <section class="section bf-discount">
    <div class="bf-section__header">
      <h2 class="title-sub">놓치면 아까운 할인·쿠폰</h2>
    </div>
    <!-- S : 할인·쿠폰 로딩중 스켈레톤 -->
    <div class="cupon-list__body" aria-label="로딩중" tabindex="0">
      <div
        v-for="n in 5"
        :key="n"
        class="cupon-item outline skeleton"
        aria-hidden="true"
      >
        <div class="label">
          <LoadingSkeleton width="40%" :height="22" rounded="small" />
        </div>
        <div class="content">
          <div class="left">
            <LoadingSkeleton width="25%" :height="22" rounded="small" />
            <LoadingSkeleton width="100%" :height="26" rounded="small" />
          </div>
          <div class="right">
            <LoadingSkeleton :width="48" :height="48" rounded="medium" />
          </div>
        </div>
      </div>
    </div>
    <!-- E : 할인·쿠폰 로딩중 스켈레톤 -->

    <div class="cupon-list__body">
      <!-- 링크인 경우에만 role="link" tabindex="0" aria-label="쿠폰 정보" 추가 -->
      <div
        v-for="coupon in filteredCoupons"
        :key="coupon.id"
        :class="[
          'cupon-item outline',
          { 'is-label': coupon.label || coupon.expiryDate },
        ]"
        role="link"
        :aria-label="
          [
            coupon.label ? `쿠폰 상태: ${coupon.label}` : null,
            coupon.expiryDate ? `만료일: ${coupon.expiryDate}` : null,
            coupon.sub,
            coupon.main,
          ]
            .filter(Boolean)
            .join(', ')
        "
      >
        <ListItem align="centered" :left="{ direction: 'reverse' }">
          <template #label v-if="coupon.label || coupon.expiryDate">
            <div class="flex gap-4">
              <!-- 쿠폰 상태 -->
              <SolidLabel
                v-if="coupon.label"
                :title="coupon.label"
                :color="coupon.labelColor || 'blue'"
                class="inline-flex"
              />
              <!-- 만료일 -->
              <TintLabel
                v-if="coupon.expiryDate"
                :title="coupon.expiryDate"
                :color="coupon.expiryDateColor || 'blue'"
              />
            </div>
          </template>
          <template #leftSubText>
            <span aria-hidden="true">{{ coupon.sub }}</span>
          </template>
          <template #leftMainText>
            <strong aria-hidden="true">{{ coupon.main }}</strong>
          </template>
          <template #rightIcon>
            <img
              :src="coupon.icon.src"
              :alt="coupon.icon.alt"
              class="cupon-icon"
              aria-hidden="true"
            />
          </template>
        </ListItem>
      </div>
    </div>

    <div class="bf-section__footer">
      <CapsuleButton
        text="할인·쿠폰 전체보기"
        color="primary"
        variant="outline"
        size="medium"
        :rightIcon="{ iconName: 'Chevron_right' }"
      />
    </div>

    <!-- S : 할인·쿠폰 IF 오류시 노출 -->
    <div class="bf-if__error">
      <div class="bf-if__error-inner">
        <div class="bf-if__error-icon">
          <ScImage
            :src="`${$cdnURL}/images/pages/benefits/main/result_icon.png`"
            alt="IF 오류"
          />
        </div>
        <div class="bf-if__error-text">정보를 불러오지 못했어요</div>
        <CapsuleButton
          text="다른 할인·쿠폰 확인하기"
          color="primary"
          variant="outline"
          size="small"
        />
      </div>
    </div>
    <!-- E : 할인·쿠폰 IF 오류시 노출 -->
  </section>
  <!-- E: 할인·쿠폰 -->
</template>

<script setup>
import { computed, inject } from "vue";
import { AppContextKey } from "@/configs/inject/appContext";
import { ScImage } from "@shc-nss/ui/shc";
import {
  CapsuleButton,
  ListItem,
  LoadingSkeleton,
  SolidLabel,
  TintLabel,
} from "@shc-nss/ui/solid";

const { $cdnURL } = inject(AppContextKey);

// 쿠폰 리스트 데이터
const couponItems = [
  {
    id: 1,
    icon: {
      src: `${$cdnURL}/images/dummy/img_coupon_symbol01.png`,
      alt: "",
    },
    label: "보유중",
    labelColor: "blue",
    expiryDate: "D-3",
    expiryDateColor: "blue",
    main: "5,000원 캐시백",
    sub: "그리팅몰",
  },
  {
    id: 2,
    icon: {
      src: `${$cdnURL}/images/dummy/img_coupon_symbol02.png`,
      alt: "",
    },
    main: "10,000원 캐시백",
    sub: "CJ더마켓",
  },
  {
    id: 3,
    icon: {
      src: `${$cdnURL}/images/dummy/img_coupon_symbol03.png`,
      alt: "",
    },
    label: "보유중",
    labelColor: "blue",
    expiryDate: "D-3",
    expiryDateColor: "blue",
    main: "5% 캐시백",
    sub: "크록스",
  },
  {
    id: 4,
    icon: {
      src: `${$cdnURL}/images/dummy/img_coupon_symbol04.png`,
      alt: "",
    },
    main: "1,000원 캐시백",
    sub: "파리바게뜨",
  },
  {
    id: 5,
    icon: {
      src: `${$cdnURL}/images/dummy/img_coupon_symbol05.png`,
      alt: "",
    },
    expiryDate: "D-1",
    expiryDateColor: "blue",
    main: "3% 캐시백",
    sub: "구구스",
  },
];

// 필터링된 쿠폰 리스트
const filteredCoupons = computed(() => {
  return couponItems;
});
</script>

