<template>
  <section class="bf-recommend-benefit" aria-label="추천 혜택">
    <!-- S : 로딩 스켈레톤-->
    <div class="bf-recommend-benefit__inner skeleton">
      <LoadingSkeleton :width="290" :height="29" rounded="small" />
      <div class="bf-recommend-benefit__intro">
        <LoadingSkeleton width="100%" :height="162" rounded="small" />
      </div>
    </div>
    <!-- E : 로딩 스켈레톤-->

    <div class="bf-recommend-benefit__inner">
      <h2 class="title-sub px-2xl">출근길 혜택 패키지 도착!</h2>
      <div class="bf-recommend-benefit__intro" :hidden="isBodyVisible">
        <div
          class="bf-recommend-benefit__button"
          role="button"
          tabindex="0"
          @click="handleButtonClick"
          @keydown.enter="handleButtonClick"
          @keydown.space.prevent="handleButtonClick"
        >
          <ScImage
            :src="`${$cdnURL}/images/pages/benefits/main/img_goods.png`"
            alt="추천 혜택"
          />
          <div class="tooltip-recommend-benefit">
            <ScImageIcon
              iconName="bg_tooltip"
              size="128"
              height="66"
              class="bg-tooltip"
              aria-hidden="true"
            />
            <span class="tooltip-custom__text">터치해보세요!</span>
          </div>
        </div>
      </div>
      <div
        class="bf-recommend-benefit__body"
        :class="{ 'is-visible': isBodyVisible }"
        :hidden="!isBodyVisible"
      >
        <ul
          ref="webzineListRef"
          class="webzine-list vertical"
          :tabindex="shouldShowPagination ? 0 : undefined"
          :aria-label="webzineListAriaLabel"
        >
          <li
            v-for="(item, index) in displayedItems"
            :key="`${paginationCurrent}-${index}`"
            :class="{ 'is-visible': isBodyVisible }"
          >
            <BasicList
              as="button"
              class="webzine-item"
              :data-color="item.color"
            >
              <div class="webzine-item__before circle">
                <ScImage :src="item.image" alt="" />
              </div>
              <div class="webzine-item__contents">
                <strong class="webzine-item__label">
                  {{ item.label }}
                </strong>
              </div>
              <div class="webzine-item__after">
                <TextBadge
                  v-if="item.badge"
                  variant="tint"
                  color="gray"
                  :text="item.badge"
                />
              </div>
            </BasicList>
          </li>
        </ul>
        <!-- 
          등록한 혜택 개수에 따라 다른 혜택보기 버튼 노출 
          - 혜택 3개 등록 케이스 : 다른 혜택 보기 버튼 미노출
          - 혜택 6개 등록 케이스 : 다른 헤택 보기 버튼 1/2으로 노출
          - 혜택 9개 등록 케이스 : 다른 혜택 보기 버튼 1/3으로 노출
        -->
        <ButtonPagination
          v-if="shouldShowPagination"
          :total="paginationTotal"
          :current="paginationCurrent"
          iconName="Arrow_refresh"
          title="다른 혜택 보기"
          :class="{ 'is-visible': isBodyVisible && isPaginationVisible }"
          @click="handlePaginationClick"
        />
      </div>
    </div>

    <!-- S : 추천 혜택 IF 오류시 노출 -->
    <div class="bf-if__error">
      <div class="bf-if__error-inner">
        <div class="bf-if__error-icon">
          <ScImage
            :src="`${$cdnURL}/images/pages/benefits/main/result_icon.png`"
            alt="IF 오류"
          />
        </div>
        <div class="bf-if__error-text">정보를 불러오지 못했어요</div>
        <CapsuleButton
          text="다른 혜택 확인하기"
          color="primary"
          variant="outline"
          size="small"
        />
      </div>
    </div>
    <!-- E : 추천 혜택 IF 오류시 노출 -->
  </section>
</template>

<script setup>
import { computed, inject, nextTick, ref } from "vue";
import { AppContextKey } from "@/configs/inject/appContext";
import { ScImage, ScImageIcon } from "@shc-nss/ui/shc";
import {
  BasicList,
  ButtonPagination,
  CapsuleButton,
  IconButton,
  LoadingSkeleton,
  TextBadge,
} from "@shc-nss/ui/solid";

const { $cdnURL } = inject(AppContextKey);

// 상태 관리
const isBodyVisible = ref(false);
const isPaginationVisible = ref(false);

// 전체 혜택 아이템 데이터
const allBenefitItems = ref([
  {
    id: 1,
    image: `${$cdnURL}/images/dummy/img_coupon_symbol04.png`,
    label: "파리바케트 아메리카노",
    badge: "34% 할인",
  },
  {
    id: 2,
    image: `${$cdnURL}/images/dummy/img_dummy_car.png`,
    label: "하이팻 이용하기",
    badge: "최대 2만원 캐시백",
  },
  {
    id: 3,
    image: `${$cdnURL}/images/dummy/img_dummy_giftbox.png`,
    label: "버튼 누르기",
    badge: "최대 10포인트",
  },
  {
    id: 4,
    image: `${$cdnURL}/images/dummy/img_coupon_symbol04.png`,
    label: "파리바케트 아메리카노",
    badge: "34% 할인",
  },
  {
    id: 5,
    image: `${$cdnURL}/images/dummy/img_dummy_car.png`,
    label: "하이팻 이용하기",
    badge: "최대 2만원 캐시백",
  },
  {
    id: 6,
    image: `${$cdnURL}/images/dummy/img_dummy_giftbox.png`,
    label: "버튼 누르기",
    badge: "최대 10포인트",
  },
  {
    id: 7,
    image: `${$cdnURL}/images/dummy/img_coupon_symbol04.png`,
    label: "파리바케트 아메리카노",
    badge: "34% 할인",
  },
  {
    id: 8,
    image: `${$cdnURL}/images/dummy/img_dummy_car.png`,
    label: "하이팻 이용하기",
    badge: "최대 2만원 캐시백",
  },
  {
    id: 9,
    image: `${$cdnURL}/images/dummy/img_dummy_giftbox.png`,
    label: "버튼 누르기",
    badge: "최대 10포인트",
  },
]);

// 고정 컬러 순서
const fixedColors = [
  "--palette-blue-100",
  "--palette-monotone-100",
  "--palette-indigo-100",
];

// 전체 항목을 3개씩 그룹화한 배열
const groupedItems = ref([]);

// 항목을 순서대로 3개씩 그룹화하는 함수 (color는 고정)
const initializeItems = () => {
  const groups = [];
  const items = [...allBenefitItems.value];

  // 순서대로 3개씩 그룹화하고 각 그룹의 color를 고정 순서로 할당
  for (let i = 0; i < items.length; i += 3) {
    const group = items.slice(i, i + 3).map((item, index) => ({
      ...item,
      color: fixedColors[index], // color는 고정 순서로 할당
    }));
    groups.push(group);
  }

  groupedItems.value = groups;
};

// 항목을 랜덤으로 섞고 3개씩 그룹화하는 함수 (color는 고정)
const shuffleAndGroupItems = () => {
  const groups = [];
  const items = [...allBenefitItems.value];

  // 데이터만 랜덤으로 섞기 (color 제외)
  const shuffled = items.sort(() => Math.random() - 0.5);

  // 3개씩 그룹화하고 각 그룹의 color를 고정 순서로 할당
  for (let i = 0; i < shuffled.length; i += 3) {
    const group = shuffled.slice(i, i + 3).map((item, index) => ({
      ...item,
      color: fixedColors[index], // color는 고정 순서로 할당
    }));
    groups.push(group);
  }

  groupedItems.value = groups;
};

// 현재 표시할 항목들 (현재 페이지의 3개)
const displayedItems = computed(() => {
  const currentPage = paginationCurrent.value - 1;
  if (currentPage >= 0 && currentPage < groupedItems.value.length) {
    return groupedItems.value[currentPage];
  }
  return [];
});

// 혜택 개수
const totalBenefits = computed(() => allBenefitItems.value.length);

// 페이지네이션 표시 여부 (3개일 때는 미노출)
const shouldShowPagination = computed(() => totalBenefits.value > 3);

// 페이지네이션 total 계산 (3개씩 묶어서 표시)
const paginationTotal = computed(() => {
  if (totalBenefits.value <= 3) return 0;
  return Math.ceil(totalBenefits.value / 3);
});

// 페이지네이션 current (현재 페이지)
const paginationCurrent = ref(1);

// webzine-list ref
const webzineListRef = ref(null);

// webzine-list aria-label (6개 이상일 때만)
const webzineListAriaLabel = computed(() => {
  if (!shouldShowPagination.value) return undefined;

  const total = paginationTotal.value;
  const current = paginationCurrent.value;
  const currentText =
    current === 1 ? "1번째" : current === 2 ? "2번째" : "3번째";

  return `혜택 리스트 총 ${total}개 페이지 중 현재 페이지 ${currentText}`;
});

// 버튼 클릭 핸들러
const handleButtonClick = async () => {
  if (isBodyVisible.value) return; // 이미 열려있으면 무시

  // 처음 로드 시 순서대로 그룹화 (첫 3개는 순서대로)
  initializeItems();

  // 첫 페이지로 초기화
  paginationCurrent.value = 1;

  // body 표시 (CSS에서 타이밍 제어)
  isBodyVisible.value = true;

  // 6개 이상일 때 webzine-list에 포커스 (첫 그룹 진입 시)
  if (shouldShowPagination.value) {
    await nextTick();
    setTimeout(() => {
      webzineListRef.value?.focus();
    }, 100); // DOM 렌더링 대기
  }

  // pagination 타이밍 계산
  setTimeout(() => {
    isPaginationVisible.value = true;
  }, 3000);
};

// 페이지네이션 클릭 핸들러
const handlePaginationClick = async () => {
  // 다음 페이지로 이동 (총 페이지 수를 넘지 않도록)
  if (paginationCurrent.value < paginationTotal.value) {
    paginationCurrent.value += 1;
  } else {
    // 마지막 페이지에서 다시 클릭하면 첫 페이지로 돌아가고 랜덤 재섞기
    shuffleAndGroupItems();
    paginationCurrent.value = 1;
  }

  // isBodyVisible은 한 번 true가 되면 계속 유지 (클릭 시 추가/제거 안 함)
  await nextTick();
  // webzine-list에 포커스 (6개 이상일 때만)
  if (shouldShowPagination.value && webzineListRef.value) {
    setTimeout(() => {
      webzineListRef.value?.focus();
    }, 100); // DOM 렌더링 대기
  }
};
</script>
