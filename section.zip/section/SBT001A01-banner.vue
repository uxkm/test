<template>
  <section class="bf-banner-group">
    <!--
      인라인 배너 영역
      사용자 케이스에 따라 배너 노출

      - 신규 리워드 대상자 또는 혜택 정보 수신 미동의 사용자가 아닌 경우 해당 영역 미노출
      - 신규 리워드 배너 간 노출 우선순위: 반갑꾸러미 > 웰컴 체크인
      - 화면 재진입 시에는 처음부터 다시 노출
      - 신규 리워드 대상자이면서 혜택 정보 수신 동의한 사용자의 경우: 신규 리워드 배너 닫기 시 인라인 배너 미노출
      - 신규 리워드 대상자이면서 혜택 정보 수신 미동의 사용자의 경우: 신규 리워드 배너 닫기 시 혜택 정보 수신 동의 배너 노출

      <인라인 배너 노출 프로세스 참고>
      1) 신규 리워드 대상자
        - 반갑꾸러미, 웰컴체크인 혜택 대상자의 경우 신규 리워드 배너 노출
        - 반갑꾸러미와 웰컴체크인 혜택 둘 다 대상자인 경우 반갑꾸러미 배너를 노출
        - 반갑꾸러미 배너 Tap > [SBT010A01_반갑꾸러미](현행화) 화면으로 이동
        - 웰컴체크인 배너 Tap > [SBT157A01_웰컴 체크인](현행화) 화면으로 이동
        - [X] 버튼 Tap > 배너 제거, 해당 화면 재진입 시 배너 다시 노출

      2) 혜택 정보 수신 미동의 사용자
        - 신규 리워드 대상자가 아니면서 혜택 정보 수신 미동의한 경우 노출
        - 배너 Tap > 홈페이지 [TMP585_혜택정보 수신동의] 화면으로 이동
        - [X] 버튼 Tap > 배너 제거, 해당 화면 재진입 시 배너 다시 노출
    -->
    <article
      v-if="visibleItems.some((item) => item)"
      ref="inlineBannerRef"
      class="bf-inline-banner"
      aria-label="인라인 배너"
    >
      <!-- S : 로딩 스켈레톤-->
      <LoadingSkeleton width="100%" :height="48" rounded="small" />
      <!-- E : 로딩 스켈레톤-->

      <!-- 혜택 정보 수신 미동의 사용자 배너 -->
      <div v-if="visibleItems[0]" class="bf-inline-banner__item">
        <a
          ref="linkRef0"
          role="link"
          tabindex="0"
          class="bf-inline-banner__link"
        >
          <Infobox
            title="내계 꼭 필요한 혜택만 받으려면?"
            color="info"
            size="small"
            :icon="false"
            class="infobox-bell"
          />
        </a>
        <IconButton
          icon-name="X"
          size="small"
          aria-label="삭제"
          class="bf-inline-banner__close"
          @click="handleClose(0)"
        />
      </div>

      <!-- 반갑꾸러미 리워드 배너 -->
      <div v-if="visibleItems[1]" class="bf-inline-banner__item">
        <a
          ref="linkRef1"
          role="link"
          tabindex="0"
          class="bf-inline-banner__link"
        >
          <Infobox
            title="오늘도 반갑꾸러미 혜택 받아가세요!"
            color="info"
            size="small"
            :icon="false"
            class="infobox-gift"
          />
        </a>
        <IconButton
          icon-name="X"
          size="small"
          aria-label="삭제"
          class="bf-inline-banner__close"
          @click="handleClose(1)"
        />
      </div>

      <!-- 웰컴 체크인 리워드 배너 -->
      <div v-if="visibleItems[2]" class="bf-inline-banner__item">
        <a
          ref="linkRef2"
          role="link"
          tabindex="0"
          class="bf-inline-banner__link"
        >
          <Infobox
            title="지금만 받을 수 있는 웰컴 체크인 혜택 도착!"
            color="info"
            size="small"
            :icon="false"
            class="infobox-gift"
          />
        </a>
        <IconButton
          icon-name="X"
          size="small"
          aria-label="삭제"
          class="bf-inline-banner__close"
          @click="handleClose(2)"
        />
      </div>
    </article>

    <!--
      추천 배너 영역
      투데이 배너, 신규 가입자 리워드 배너 노출

      - 신규 가입자 리워드 대상군에 해당하지 않는 사용자의 경우 투데이 배너만 노출
        (신규 가입자 별 대상군은 하기 정의 참고)
      - 신규 가입자 리워드 배너 > 투데이 배너 순으로 노출
        : 웰컴 체크인 배너와 반갑꾸러미 배너 둘 다 노출해야하는 대상자의 경우
          반갑꾸러미 배너 > 웰컴 체크인 배너 순으로 노출
        <신규 가입 리워드 제공 대상자 배너 노출 순서> 참고
      - 투데이 배너, 신규 가입자 리워드 배너 모두 없는 경우 영역 히든
      - 배너 루프 적용, 재생/일시정지+숫자형 인디케이터 제공

      투데이 배너
      - 어드민에서 등록한 배너 노출 (*기존 투데이 배너가 노출되는 형태만 달라짐)
      - 투데이 배너 Tap > 어드민에서 입력된 URL주소 및 URL연결 타입 정의에 따름
        : 내부페이지일 경우 내부 헤더 적용된 상태로 URL 웹페이지 호출
        : 인앱브라우저일 경우 인앱브라우저 내에서 URL 웹페이지 호출
        : 아웃링크일 경우 앱 빠져나가 외부 브라우저로 URL 웹페이지 호출

      신규 가입자 리워드 배너
      - 신규 가입 케이스 별 배너 노출
      - [SBT157A01_웰컴 체크인 화면](현행화)에 노출되는 웰컴 라운지 제공일을
        NN일 뒤 혜택이 사라져요 부분에 동일하게 노출
      - asis 혜택 대시보드 반갑꾸러미 영역에 노출되는 D-Day를
        NN일 뒤 혜택이 사라져요 부분에 동일하게 배너에 노출
      - 신규 가입자 리워드 배너 Tap >
        1) 웰컴 체크인 배너: [SBT157A01_웰컴 체크인](현행화) 화면으로 이동
          * 대상군: 체크카드 최소 신규, 12개월 휴면 후 발급 고객, 선불카드 최초 신규 고객
        2) 반갑꾸러미 배너: [SBT010A01_반갑꾸러미](현행화) 화면으로 이동
          * 대상군: 본인 신용 신규 발급 고객 판촉유형군 WG7
    -->
    <article
      ref="recommendBannerRef"
      class="bf-recommend-banner"
      aria-label="추천 배너"
    >
      <!-- S : 로딩 스켈레톤-->
      <div class="bf-recommend-banner__inner skeleton">
        <LoadingSkeleton width="100%" :height="136" rounded="small" />
        <LoadingSkeleton :width="89" :height="20" rounded="small" />
      </div>
      <!-- E : 로딩 스켈레톤-->

      <Carousel
        v-if="bannerItems.length > 0"
        :loop="bannerItems.length > 1"
        slides-per-view="1"
        :space-between="0"
        root-class="bf-recommend-banner-carousel"
        :pagination="bannerItems.length > 1"
        pagination-type="fraction"
        pagination-placement="outside-center"
        :navigation="bannerItems.length > 1"
        :autoplay="bannerItems.length > 1"
        :autoplay-delay="3000"
        :show-autoplay-control="bannerItems.length > 1"
      >
        <CarouselItem v-for="(item, index) in bannerItems" :key="index">
          <a
            :href="item.url || 'javascript:;'"
            class="bf-recommend-banner__slide"
            @click="handleBannerClick(item, $event)"
          >
            <div class="bf-recommend-banner__content" :data-color="item.color">
              <div class="bf-recommend-banner__text">
                <p class="bf-recommend-banner__title">
                  {{ item.title }}
                </p>
                <p class="bf-recommend-banner__subtitle">
                  <em v-if="item.days" class="days">
                    {{ item.days }}
                  </em>
                  {{ item.subtitle }}
                </p>
              </div>
              <div class="bf-recommend-banner__image" aria-hidden="true">
                <img :src="item.image" alt="" />
              </div>
            </div>
          </a>
        </CarouselItem>
      </Carousel>
    </article>
  </section>
</template>

<script setup>
import { inject, nextTick, ref } from "vue";
import { AppContextKey } from "@/configs/inject/appContext";
import {
  Carousel,
  CarouselItem,
  IconButton,
  Infobox,
  LoadingSkeleton,
} from "@shc-nss/ui/solid";

const { $cdnURL } = inject(AppContextKey);

// 인라인 배너 아이템 표시 여부 관리
const visibleItems = ref([true, true, true]);

// refs
const inlineBannerRef = ref(null);
const recommendBannerRef = ref(null);
const linkRef0 = ref(null);
const linkRef1 = ref(null);
const linkRef2 = ref(null);

// 링크 ref 배열
const linkRefs = [linkRef0, linkRef1, linkRef2];

// 추천 배너 아이템 데이터
const bannerItems = ref([
  // 반갑꾸러미 배너
  {
    title: "신용카드로 결제하고\n반갑꾸러미 혜택 받기",
    days: "99",
    subtitle: "일 뒤 혜택이 사라져요",
    image: `${$cdnURL}/images/pages/benefits/main/img_banner_daily_main.png`,
    color: "bg-banner_indigo_solid-same",
    url: "javascript:;",
  },
  // 웰컴 체크인 배너
  {
    title: "SOL 페이로 결제하고\n웰컴 체크인 혜택 받기",
    days: "7",
    subtitle: "일 뒤 혜택이 사라져요",
    image: `${$cdnURL}/images/pages/benefits/main/img_banner_checkin_main.png`,
    color: "bg-banner_gray-solid-same",
    url: "javascript:;",
  },
  // 투데이 배너
  {
    title: "5만원 상당 경품 받으세요!",
    subtitle: "운세알림 신청하세요",
    image: `${$cdnURL}/images/pages/benefits/main/img_banner_today_main.png`,
    color: "bg-banner_brand_solid",
    url: "javascript:;",
  },
]);

// 아이템 닫기 핸들러
const handleClose = async (index) => {
  // 해당 아이템 제거
  visibleItems.value[index] = false;

  // 남은 아이템 개수 확인
  const remainingCount = visibleItems.value.filter((item) => item).length;

  await nextTick();

  // 여러 개일 때 남은 첫 번째 아이템에 포커스 이동
  if (remainingCount > 0) {
    // 남은 첫 번째 아이템의 인덱스 찾기
    const firstVisibleIndex = visibleItems.value.findIndex((item) => item);
    if (firstVisibleIndex !== -1 && linkRefs[firstVisibleIndex]) {
      setTimeout(() => {
        const targetLink = linkRefs[firstVisibleIndex].value;
        if (targetLink) {
          targetLink.focus();
        }
      }, 100);
    }
  } else {
    // 전체 영역이 사라지면 다음 영역에 포커스 이동
    setTimeout(() => {
      recommendBannerRef.value?.focus();
    }, 100);
  }
};

// 배너 클릭 핸들러
const handleBannerClick = (item, event) => {
  // URL 타입에 따른 처리 로직
  // 내부페이지, 인앱브라우저, 아웃링크 등
  if (item.urlType === "internal") {
    // 내부페이지 처리
  } else if (item.urlType === "inapp") {
    // 인앱브라우저 처리
  } else if (item.urlType === "external") {
    // 아웃링크 처리
  }
};
</script>
