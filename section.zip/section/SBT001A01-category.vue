<template>
  <!-- 앱테크, 이벤트, 할인/쿠폰 2뎁스 진입점 -->
  <section class="section bf-category">
    <ul class="category-list">
      <li
        v-for="item in categoryList"
        :key="item.text"
        class="category-list__item"
      >
        <TextButton
          :text="item.text"
          :aria-label="item.ariaLabel"
          color="secondary"
          size="small"
          class="category-list__link"
        >
          <template #leftIcon>
            <div class="category-list__icon" aria-hidden="true">
              <LoadingSkeleton
                v-if="!imageLoaded[item.text]"
                :width="36"
                :height="36"
                rounded="small"
              />
              <img
                :src="item.iconUrl"
                alt=""
                :style="{
                  display: imageLoaded[item.text] ? 'block' : 'none',
                }"
                @load="imageLoaded[item.text] = true"
                @error="imageLoaded[item.text] = true"
              />
            </div>
          </template>
        </TextButton>
      </li>
    </ul>
  </section>
</template>

<script setup>
import { inject, reactive } from "vue";
import { AppContextKey } from "@/configs/inject/appContext";
import { LoadingSkeleton, TextButton } from "@shc-nss/ui/solid";

const { $cdnURL } = inject(AppContextKey);

// 이미지 로딩 상태 관리
const imageLoaded = reactive({});

// 카테고리 리스트 데이터
const categoryList = [
  {
    text: "앱테크",
    ariaLabel: "앱테크",
    iconUrl: `${$cdnURL}/images/pages/benefits/main/Coin_Point.png`,
  },
  {
    text: "이벤트",
    ariaLabel: "이벤트",
    iconUrl: `${$cdnURL}/images/pages/benefits/main/Gift.png`,
  },
  {
    text: "할인・쿠폰",
    ariaLabel: "할인・쿠폰",
    iconUrl: `${$cdnURL}/images/pages/benefits/main/Coupon_Star.png`,
  },
];
</script>

