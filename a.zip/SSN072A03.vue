<route lang="yaml">
meta:
  id: SSN072A03
  title: "약관동의"
  menu: Sign in/up > 마이데이터 금융기관 연결안내 > 자산 연결 동의 안내 > 마이데이터 서비스 개인(신용)정보의 수집 및 이용동의
  layout: SubLayout
  category: Sign in/up
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  header:
    fixed: true
    close: true
    back: false
</route>
<template>
  <FullPopup
    v-model="isOpen"
    title="마이데이터 서비스 개인(신용)정보의 수집 및 이용동의"
    class="sc-terms__popup"
  >
    <div class="terms-content" style="height:100%;background-color: var(--gray-50)">
      <!-- 약관 내용, 개발 시 style="background-color는 제거" -->
    </div>
    <!-- footer -->
    <template #footer>
      <BottomActionContainer :scrollDim="true">
        <BoxButtonGroup
          size="xlarge"
          variant="100"
        >
          <BoxButton
            text="확인"
          />
        </BoxButtonGroup>
      </BottomActionContainer>
    </template>
  </FullPopup>
</template>

<script setup>
import { 
  BottomActionContainer,
  BoxButton,
  BoxButtonGroup,
  FullPopup,
  NumberPagination, 
} from "@shc-nss/ui/solid";
const isOpen = defineModel({ default: true });
</script>
