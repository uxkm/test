<route lang="yaml">
meta:
  id: SSN072A01
  title: ""
  menu: Sign in/up > 마이데이터 금융기관 연결안내 > 자산 연결 동의 안내
  layout: SubLayout
  category: Sign in/up
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  header:
    fixed: false
    close: false
    back: false
</route>

<template>
  <ModalPopup
    title=""
    v-model="isOpen"
  >
    <p class="sc-preline">{{ message }}</p>
    <template #footer>
      <BoxButton
        @click="isOpen = false"
        text="아니요"
        color="secondary"
      />
      <BoxButton
        @click="isOpen = false"
        text="예"
      />
    </template>
  </ModalPopup>
</template>

<script setup>
import { ModalPopup, BoxButton } from "@shc-nss/ui/solid";
// import { ScIcon } from "@shc-nss/ui/shc";

// 팝업 상태 관리
const isOpen = defineModel({ default: true });

const message = '지금 중단하면 자산 연결이 취소 되고 처음 화면으로 돌아갑니다. 정말 종료하시겠어요?';
</script>
