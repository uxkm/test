<route lang="yaml">
meta:
  id: SBT157A01
  title: 이벤트
  menu: 혜택 > 웰컴 체크인
  layout: SubLayout
  category: 혜택
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  header:
    variant: sub
    fixed: true
    showBack: true
    close: false
    home: true
  mainClassList: pt-none
</route>
<template>
  <!-- 콘텐츠 영역 -->
  <div class="sc-contents__body welcome-checkin">
    <div class="welcome-checkin__head">
      <h2
        class="welcome-checkin__title"
        tabindex="0"
        aria-label="웰컴 체크인"
      >
        <ScImageIcon
          :colorize="false"
          width="auto"
          height="auto"
          iconName="benefis_welcome_checkin_text01"
          aria-label="웰컴 체크인"
          aria-hidden="true"
          class="checkin-text-icon"
        />
      </h2>
      <p class="welcome-checkin__description">NN일 뒤<br />혜택이 사라져요.</p>
    </div>
    <div class="welcome-checkin__body">
      <section class="welcome-checkin__section">
        <h3
          class="welcome-checkin__subtitle"
          tabindex="0"
          aria-label="설레는 시작을 위한 특별 혜택"
        >
          <ScImageIcon
            :colorize="false"
            width="auto"
            height="auto"
            iconName="benefis_welcome_checkin_text02"
            aria-label="설레는 시작을 위한 특별 혜택"
            aria-hidden="true"
            class="checkin-text-icon"
          />
        </h3>
        <h4 class="welcome-checkin__label">혜택 1 & 2</h4>
        <ul class="welcome-checkin__list">
          <li
            v-for="(item, index) in benefit12Items"
            :key="`benefit12-${index}`"
            class="welcome-checkin__item"
          >
            <a
              role="button"
              class="welcome-checkin__item-link"
              :aria-label="item.ariaLabel"
            >
              <div
                class="welcome-checkin__item-content"
                aria-hidden="true"
              >
                <img
                  v-if="item.dealImage"
                  :src="`${$cdnURL}/images/pages/benefits/welcome/${item.dealImage}`"
                  alt=""
                />
                <div class="welcome-checkin__item-info">
                  <SolidLabel
                    v-if="item.labelTitle"
                    color="red"
                    :title="item.labelTitle"
                  />
                  <span class="welcome-checkin__item-info-text">
                    <ScImageIcon
                      :colorize="false"
                      width="auto"
                      height="auto"
                      :iconName="item.textIconName"
                      :aria-label="item.textIconLabel"
                      aria-hidden="true"
                      class="checkin-text-icon"
                    />
                  </span>
                  <span
                    v-if="item.description"
                    class="welcome-checkin__item-info-description"
                  >
                    {{ item.description }}
                  </span>
                </div>
              </div>
              <div
                class="welcome-checkin__item-btn"
                aria-hidden="true"
              >
                <ScImageIcon
                  :colorize="false"
                  width="auto"
                  height="auto"
                  iconName="icon_pickup"
                  aria-hidden="true"
                  class="checkin-text-icon"
                />
                <span class="welcome-checkin__item-btn-text">{{ item.btnText }}</span>
              </div>
            </a>
          </li>
        </ul>
      </section>

      <div
        class="welcome-checkin__divider"
        tabindex="0"
        aria-label="다음 혜택"
      >
        <ScImageIcon
          :colorize="false"
          width="auto"
          height="auto"
          iconName="benefits_welcome_plus"
          aria-label="다음 혜택"
          aria-hidden="true"
          class="checkin-text-icon"
        />
      </div>

      <section class="welcome-checkin__section">
        <h3
          class="welcome-checkin__subtitle"
          tabindex="0"
          aria-label="고객님께만 드리는 보너스 혜택!"
        >
          <ScImageIcon
            :colorize="false"
            width="auto"
            height="auto"
            iconName="benefis_welcome_checkin_text03"
            aria-label="고객님께만 드리는 보너스 혜택!"
            aria-hidden="true"
            class="checkin-text-icon"
          />
        </h3>
        <h4 class="welcome-checkin__label">혜택 3</h4>
        <p
          class="welcome-checkin__description"
          tabindex="0"
          aria-label="최대 3천원 상당의 편의점 금액권 구매 혜택"
        >
          <ScImageIcon
            :colorize="false"
            width="auto"
            height="auto"
            iconName="benefis_welcome_checkin_text04"
            aria-label="최대 3천원 상당의 편의점 금액권 구매 혜택"
            aria-hidden="true"
            class="checkin-text-icon"
          />
        </p>
        <ul class="welcome-checkin__list">
          <li
            v-for="(item, index) in benefit3Items"
            :key="`benefit3-${index}`"
            class="welcome-checkin__item"
          >
            <a
              role="button"
              class="welcome-checkin__item-link"
              :aria-label="item.ariaLabel"
            >
              <div
                class="welcome-checkin__item-content"
                aria-hidden="true"
              >
                <img
                  v-if="item.dealImage"
                  :src="`${$cdnURL}/images/pages/benefits/welcome/${item.dealImage}`"
                  alt=""
                />
                <div class="welcome-checkin__item-info">
                  <SolidLabel
                    v-if="item.labelTitle"
                    color="red"
                    :title="item.labelTitle"
                  />
                  <span class="welcome-checkin__item-info-text">
                    <ScImageIcon
                      :colorize="false"
                      width="auto"
                      height="auto"
                      :iconName="item.textIconName"
                      :aria-label="item.textIconLabel"
                      aria-hidden="true"
                      class="checkin-text-icon"
                    />
                  </span>
                  <span
                    v-if="item.description"
                    class="welcome-checkin__item-info-description"
                  >
                    {{ item.description }}
                  </span>
                </div>
              </div>
              <div
                class="welcome-checkin__item-btn"
                aria-hidden="true"
              >
                <ScImageIcon
                  :colorize="false"
                  width="auto"
                  height="auto"
                  iconName="icon_pickup"
                  aria-hidden="true"
                  class="checkin-text-icon"
                />
                <span class="welcome-checkin__item-btn-text">{{ item.btnText }}</span>
              </div>
            </a>
          </li>
        </ul>

        <h4 class="welcome-checkin__label">혜택 4</h4>
        <p
          class="welcome-checkin__description"
          tabindex="0"
          aria-label="간편하게 신한 SOL페이 결제하고 캐시백 혜택 받으세요!"
        >
          <ScImageIcon
            :colorize="false"
            width="auto"
            height="auto"
            iconName="benefis_welcome_checkin_text05"
            aria-label="간편하게 신한 SOL페이 결제하고 캐시백 혜택 받으세요!"
            aria-hidden="true"
            class="checkin-text-icon"
          />
        </p>
        <ul class="welcome-checkin__list">
          <li
            v-for="(item, index) in benefit4Items"
            :key="`benefit4-${index}`"
            class="welcome-checkin__item"
          >
            <a
              role="button"
              class="welcome-checkin__item-link"
              :aria-label="item.ariaLabel"
            >
              <div
                class="welcome-checkin__item-content"
                aria-hidden="true"
              >
                <img
                  v-if="item.dealImage"
                  :src="`${$cdnURL}/images/pages/benefits/welcome/${item.dealImage}`"
                  alt=""
                />
                <div class="welcome-checkin__item-info">
                  <SolidLabel
                    v-if="item.labelTitle"
                    color="red"
                    :title="item.labelTitle"
                  />
                  <span class="welcome-checkin__item-info-text">
                    <ScImageIcon
                      :colorize="false"
                      width="auto"
                      height="auto"
                      :iconName="item.textIconName"
                      :aria-label="item.textIconLabel"
                      aria-hidden="true"
                      class="checkin-text-icon"
                    />
                  </span>
                  <span
                    v-if="item.description"
                    class="welcome-checkin__item-info-description"
                    v-html="item.description"
                  >
                  </span>
                </div>
              </div>
              <div
                class="welcome-checkin__item-btn"
                aria-hidden="true"
              >
                <ScImageIcon
                  :colorize="false"
                  width="auto"
                  height="auto"
                  iconName="icon_pickup"
                  aria-hidden="true"
                  class="checkin-text-icon"
                />
                <span class="welcome-checkin__item-btn-text">{{ item.btnText }}</span>
              </div>
            </a>
          </li>
        </ul>
      </section>
    </div>
    <div class="foot-notice">
      <h3 class="foot-notice__title">꼭! 알아두세요</h3>
      <article
        v-for="(article, index) in noticeArticles"
        :key="`notice-${index}`"
      >
        <h4 class="foot-notice__subtitle">{{ article.subtitle }}</h4>
        <UnorderedList>
          <UnorderedListItem
            v-for="(item, itemIndex) in article.items"
            :key="`notice-item-${index}-${itemIndex}`"
          >
            <span v-if="!item.isStrong">{{ item.text }}</span>
            <strong v-if="item.isStrong">{{ item.text }}</strong>

            <UnorderedList v-if="item.subItems">
              <UnorderedListItem
                v-for="(subItem, subIndex) in item.subItems"
                :key="`notice-sub-${index}-${itemIndex}-${subIndex}`"
                :variant="subItem.variant"
              >
                {{ subItem.text }}
              </UnorderedListItem>
            </UnorderedList>
          </UnorderedListItem>
        </UnorderedList>

        <UnorderedList v-if="article.additionalItems">
          <UnorderedListItem
            v-for="(item, itemIndex) in article.additionalItems"
            :key="`notice-additional-${index}-${itemIndex}`"
          >
            <span v-if="!item.isStrong">{{ item.text }}</span>
            <strong v-if="item.isStrong">{{ item.text }}</strong>
          </UnorderedListItem>
        </UnorderedList>
      </article>
    </div>

    <Divider
      variant="basic"
      color="secondary"
      size="full"
      orientation="horizontal"
    />

    <div class="sc-bottom-info__card">
      <p>준법감시 심의필 제20241016-Cpi-011호<br />(2024.10.16~2025.10.15)</p>
    </div>
  </div>
</template>

<script setup>
import { AppContextKey } from "@/configs/inject/appContext";
import { ScImageIcon } from "@shc-nss/ui/shc";
import { Divider, SolidLabel, UnorderedList, UnorderedListItem } from "@shc-nss/ui/solid";
import { inject } from "vue";

const { $cdnURL } = inject(AppContextKey);

// 혜택 1 & 2
const benefit12Items = [
  {
    ariaLabel: "100원 딜 아메리카노 쿠폰 받으러가기 제휴사페이지 이동",
    dealImage: "img_deal01.png",
    labelTitle: "100원 딜",
    textIconName: "benefis_welcome_checkin_text07",
    textIconLabel: "아메리카노 쿠폰",
    description: "",
    btnText: "받으러가기",
  },
  {
    ariaLabel: "반값 딜 5,000원 금액권 받으러가기 제휴사페이지 이동",
    dealImage: "img_deal02.png",
    labelTitle: "반값 딜",
    textIconName: "benefis_welcome_checkin_text06",
    textIconLabel: "5,000원 금액권",
    description: "",
    btnText: "받으러가기",
  },
];

// 혜택 3
const benefit3Items = [
  {
    ariaLabel:
      "1원 딜 1,000원 딜 편의점 금액권 위치기반서비스 동의 시 받으러가기 제휴사페이지 이동",
    dealImage: "",
    labelTitle: "1원 딜",
    textIconName: "benefis_welcome_checkin_text08",
    textIconLabel: "1,000원 편의점 금액권",
    description: "위치기반서비스 동의 시",
    btnText: "받으러가기",
  },
  {
    ariaLabel:
      "1원 딜 2,000원 편의점 금액권 신한 SOL페이 카드사용알림 동의 시 받으러가기 제휴사페이지 이동",
    dealImage: "",
    labelTitle: "1원 딜",
    textIconName: "benefis_welcome_checkin_text09",
    textIconLabel: "2,000원 편의점 금액권",
    description: "신한 SOL페이 카드사용알림 동의 시",
    btnText: "받으러가기",
  },
];

// 혜택 4
const benefit4Items = [
  {
    ariaLabel: "2,000원 캐시백 신한 SOL페이 1만원 이상 결제 시(온/오프라인) 자세히 보기",
    dealImage: "",
    labelTitle: "",
    textIconName: "benefis_welcome_checkin_text10",
    textIconLabel: "2,000원 캐시백",
    description: "신한 SOL페이 1만원 이상 결제 시<br />(온/오프라인)",
    btnText: "자세히 보기",
  },
];

// 꼭! 알아두세요 (foot-notice)
const noticeArticles = [
  {
    subtitle: "혜택1,2",
    items: [
      { text: "혜택당 1개 상품만 선택 가능합니다.", isStrong: false },
      {
        text: "쿠폰 사용에 대한 유의사항 및 조건은 상품 상세 페이지에서 확인 가능합니다.",
        isStrong: false,
      },
    ],
  },
  {
    subtitle: "혜택3",
    items: [
      {
        text: "편의점 2,000원 금액권 혜택의 경우, 카드 결제 수신방법을 '신한 SOL페이 알림'으로 선택하셔야 구매 가능합니다.",
        isStrong: false,
      },
      {
        text: "쿠폰 사용에 대한 유의사항 및 조건은 상품 상세 페이지에서 확인 가능합니다.",
        isStrong: false,
      },
    ],
  },
  {
    subtitle: "혜택4",
    items: [
      {
        text: "신한 SOL페이 온라인 결제란?",
        isStrong: false,
        subItems: [
          {
            text: "PC에서 신한 SOL페이 앱을 통해 QR코드 스캔 또는 결제코드를 입력하여 결제하거나, 모바일에서 신한 SOL페이로 결제하는 방식",
            variant: "dash",
          },
        ],
      },
      {
        text: "신한 SOL페이 오프라인 결제란?",
        isStrong: false,
        subItems: [
          {
            text: "매장에서 신한 SOL페이의 터치결제, QR/바코드, NFC로 결제하는 방식",
            variant: "dash",
          },
          {
            text: "버튼 클릭 시 마이샵 페이지로 이동되며, 『신한 SOL페이 앱 결제(온라인/오프라인)』 마이샵 혜택을 실행(ON)하셔야 혜택이 적용됩니다.",
            variant: "dash",
          },
          {
            text: "혜택을 실행하지 않은 채 SOL페이를 이용할 경우 혜택이 제공되지 않습니다.",
            variant: "dash",
          },
        ],
      },
    ],
    additionalItems: [
      {
        text: "혜택 제공 기간은 페이지 상단에 표기된 기한까지이며, 기간 경과 후에는 해당 페이지 접속이 불가합니다.",
        isStrong: true,
      },
      {
        text: "해당 이벤트는 신한카드의 사정에 따라 변경 또는 중단될 수 있습니다.",
        isStrong: true,
      },
      {
        text: "이 이벤트는 신한 SOL페이 전용 이벤트로, 최신 버전으로 앱 업데이트가 필요합니다.",
        isStrong: true,
      },
      {
        text: "사용하는 휴대폰 기종 및 인터넷 환경에 따라 이벤트 참여가 원활하지 않을 수 있습니다.",
        isStrong: true,
      },
    ],
  },
];
</script>
