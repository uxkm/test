<route lang="yaml">
meta:
  id: SBT117A01
  title: 참여한 이벤트
  menu: "혜택 > 이벤트 메인화면 > 이벤트 전체보기 > 응모이력: 참여한이벤트"
  layout: SubLayout
  category: 혜택
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  etc: "SBT118A01 응모한 이벤트 조회 월 선택 (BS), SBT163A01 당첨정보 (BS)"
  header:
    variant: sub
    fixed: true
    back: true
    close: false
    home: false
</route>
<template>
  <div class="sc-category__group event-applied">
    <div class="category-filter__ended">
      <InlineDropdown
        ref="monthDropdownRef"
        class="sc-card__dropdown usage-history__dropdown"
        @click="openMonthSheet"
      >
        <template #value>
          <span class="card-display">
            <span class="card-info">
              <span class="card-title">{{ selectedMonthLabel }}</span>
            </span>
          </span>
        </template>
      </InlineDropdown>
    </div>
  </div>

  <div class="sc-contents__body usage-history">
    <div class="section usage-history__body event-applied__body">
      <section
        v-for="(dateGroup, dateKey) in groupedEventsByDate"
        :key="dateKey"
        class="usage-history__section"
      >
        <h2
          class="usage-date__title"
          tabindex="0"
          :aria-label="`${formatDateLabel(dateKey)} 응모 내역`"
        >
          <span aria-hidden="true">{{ formatDateDisplay(dateKey) }} 응모</span>
        </h2>
        <div class="usage-history__list">
          <!-- 
          상태값 벳지 표시 규칙:
          1. 진행중: 이벤트가 진행 중일 때 [진행중]
          2. 추첨중: 이벤트 종료 후, 당첨정보 개시일 이전까지 [추첨중]
          3. 당첨: 이벤트 종료 후, 당첨되었을 경우 당첨정보 개시일에 [당첨]
          4. 미당첨: 이벤트 종료 후, 낙첨되었을 경우 당첨정보 개시일에 [미당첨]
          -->
          <div class="category-list__body">
            <div v-for="item in dateGroup" :key="item.id" class="category-item">
              <ListItem
                align="centered"
                :left="{ direction: 'reverse' }"
                :class="{
                  'ended-event-item': item.categoryType === '종료 이벤트',
                }"
              >
                <template #leftIcon>
                  <ScImage
                    :src="item.icon.src"
                    :alt="item.icon.alt"
                    class="category-icon"
                    :aria-label="
                      item.categoryType === '진행 중 이벤트'
                        ? '진행중 이벤트'
                        : '종료 이벤트'
                    "
                  />
                  <span
                    v-if="item.categoryType === '종료 이벤트'"
                    class="ended-event-badge"
                  >
                    종료
                  </span>
                </template>
                <template #leftSubText>
                  <span class="text" aria-hidden="true">{{ item.sub }}</span>
                </template>
                <template #leftMainText>
                  <!-- 이벤트 제목에 aria-label 제공, 링크 추가 href 제공을 안하는 경우 role="link" 추가 -->
                  <a
                    role="link"
                    tabindex="0"
                    :aria-label="`이벤트 제목: ${item.sub}, ${item.main}`"
                    @click="handleEventClick(item)"
                    @keydown.enter="handleEventClick(item)"
                    @keydown.space.prevent="handleEventClick(item)"
                  >
                    {{ item.main }}
                  </a>
                  <span
                    v-if="item.date"
                    class="text event-date"
                    :aria-label="formatDateRangeLabel(item.date)"
                  >
                    {{ item.date }}
                  </span>
                  <!-- 
                    당첨 내역 보기 버튼 or 설정된 문구
                    - 당첨 내역 보기 버튼 : 해당 이벤트의 당첨 유형이 2개 이상 등록되어 있을 경우 버튼 노출
                    - 버튼 선택시 당첨정보 BS 제공 . 이벤트 제목 영역 선택 시 이벤트 상세 화면으로 이동
                    - 설정된 문구 : 당첨 유형이 1개 인 경우 아래 경로에서 설정한 문구 노출(버튼 노출 X)
                    디채관 > 이벤트 관리 > 당첨결과관리 > 당첨자관리 > 당첨결과기본등록 > 당첨결과명에 기재된 문구
                  -->
                  <!-- 당첨 유형이 2개 이상인 경우: 당첨 내역 보기 버튼 표시 -->
                  <TextButton
                    v-if="
                      getEventStatus(item).label === '당첨' &&
                      item.winnerTypeCount >= 2
                    "
                    text="당첨내역 보기"
                    color="secondary"
                    size="xsmall"
                    class="ev-detail-btn"
                    show-go-to
                    @click="handleWinnerDetailClick(item)"
                  />
                  <!-- 당첨 유형이 1개인 경우: 설정된 문구만 표시 (버튼 없음) -->
                  <span
                    v-if="
                      getEventStatus(item).label === '당첨' &&
                      item.winnerTypeCount === 1 &&
                      item.description
                    "
                    class="event-description"
                  >
                    {{ item.description }}
                  </span>
                </template>
                <template #rightControl>
                  <TintLabel
                    v-if="getEventStatus(item).label"
                    :title="getEventStatus(item).label"
                    :color="getEventStatus(item).color"
                    :class="getEventStatus(item).className"
                  />
                </template>
              </ListItem>
            </div>
          </div>
        </div>
      </section>
    </div>

    <!-- 참여한 이벤트가 없을 경우 -->
    <NoData
      v-if="showEndedNoData"
      mainText="아직 응모한 이벤트가 없어요."
      subText="진행중 이벤트로 가셔서<br />다양한 이벤트에 참여해보세요."
    />
  </div>

  <!-- 조회기간 월 선택 바텀시트 SBT118A01 -->
  <BottomSheet
    closableDimm
    dimmed
    title="조회 기간을 선택해주세요 (최근 9개월)"
    v-model="isMonthSheetOpen"
    class="not-padding-t"
  >
    <div class="sc-list sc-select__list mark full">
      <div class="select-list__group">
        <div
          v-for="(item, i) in monthSelectItems"
          :key="`check-${i}`"
          class="select-list__item"
        >
          <BasicCard
            class="select-card select-card__check"
            variant="white"
            :disabled="item.disabled"
            @contentClick="toggleMonthMark(item)"
            :selected="setMonthMark(item)"
          >
            <ListItem
              class="select-cardlist__item"
              align="centered"
              :left="{ mainText: item.main }"
              :class="{ 'disabled-item': item.disabled }"
            >
              <template #rightControl>
                <Checkbox
                  :value="item.value"
                  :disabled="item.disabled"
                  variant="mark"
                  align="left"
                  class="select-card__checkbox"
                  :model-value="setMonthMark(item)"
                  @update:model-value="onMonthMark(item.value, $event)"
                  @click.stop
                />
              </template>
            </ListItem>
          </BasicCard>
        </div>
      </div>
    </div>
  </BottomSheet>

  <!-- 당첨 정보 바텀시트 SBT163A01 -->
  <BottomSheet
    closableDimm
    dimmed
    title="[$사용자명$]님의 당첨 내역입니다."
    v-model="isWinnerSheetOpen"
    class="not-padding-t"
  >
    <div class="sc-data__list">
      <div class="data-list__group">
        <DataList
          align="spaceBetween"
          v-for="(item, index) in winnerItems"
          :key="index"
        >
          <template #title>
            <span class="data-list__text">{{ item.date }}</span>
          </template>
          <template #content>
            <span class="data-list__text">{{ item.points }}</span>
          </template>
        </DataList>
      </div>
    </div>
    <template #footer>
      <BoxButton
        text="확인"
        color="primary"
        size="xlarge"
        @click="isWinnerSheetOpen = false"
      />
    </template>
  </BottomSheet>
</template>

<script setup>
// ==========================================
// Import
// ==========================================
import { AppContextKey } from "@/configs/inject/appContext";
import { ScIcon, ScImage } from "@shc-nss/ui/shc";
import {
  BottomSheet,
  Checkbox,
  ListItem,
  TintLabel,
  BasicCard,
  InlineDropdown,
  TextButton,
  DataList,
  BoxButton,
} from "@shc-nss/ui/solid";
import { computed, inject, ref, nextTick } from "vue";
import { getYear, format } from "date-fns";
import { ko } from "date-fns/locale";

import NoData from "../../_module/NoData.vue";

// ==========================================
// Inject
// ==========================================
// CDN URL 주입
const { $cdnURL } = inject(AppContextKey);

// 월 선택 바텀시트 열림/닫힘 상태
const isMonthSheetOpen = ref(false);
// 당첨 내역 바텀시트 열림/닫힘 상태
const isWinnerSheetOpen = ref(false);
// 당첨 내역 데이터
const winnerItems = ref([
  { date: "2025.05.01", points: "마이 신한 포인트 1,000p" },
  { date: "2025.05.02", points: "마이 신한 포인트 500p" },
  { date: "2025.05.03", points: "마이 신한 포인트 10,000" },
  { date: "2025.05.03", points: "마이 신한 포인트 800p" },
  { date: "2025.05.03", points: "마이 신한 포인트 2,000p" },
]);
// 선택된 월 값 (적용됨)
const selectedMonthValue = ref("5");
// DatePicker 관련 상태 (월 라벨 표시용)
const viewDate = ref(new Date());
// 월 선택 바텀시트 아이템 (최근 9개월)
const monthSelectItems = ref([
  {
    value: "1",
    main: "2025년 5월",
    year: 2025,
    month: 5,
    selected: true,
  },
  {
    value: "2",
    main: "2025년 4월",
    year: 2025,
    month: 4,
    selected: false,
  },
  {
    value: "3",
    main: "2025년 3월",
    year: 2025,
    month: 3,
    selected: false,
  },
  {
    value: "4",
    main: "2025년 2월",
    year: 2025,
    month: 2,
    selected: false,
  },
  {
    value: "5",
    main: "2025년 1월",
    year: 2025,
    month: 1,
    selected: false,
  },
  {
    value: "6",
    main: "2024년 12월",
    year: 2024,
    month: 12,
    selected: false,
  },
  {
    value: "7",
    main: "2024년 11월",
    year: 2024,
    month: 11,
    selected: false,
  },
  {
    value: "8",
    main: "2024년 10월",
    year: 2024,
    month: 10,
    selected: false,
  },
  {
    value: "9",
    main: "2024년 9월",
    year: 2024,
    month: 9,
    selected: false,
  },
]);
// 월 선택 마크 값
const monthMarks = ref("1");
// 선택된 월의 년도
const selectedYear = ref(2025);
// 월 선택 드롭다운 DOM 참조
const monthDropdownRef = ref(null);

// ==========================================
// Computed Properties
// ==========================================
/**
 * 선택된 월에 해당하는 이벤트 목록 필터링
 */
const filteredEventsByMonth = computed(() => {
  // 선택된 월 아이템 찾기
  const selectedItem = monthSelectItems.value.find(
    (item) => item.value === monthMarks.value
  );

  if (!selectedItem) {
    return [];
  }

  const year = selectedItem.year;
  const month = selectedItem.month;

  return eventAppliedItems.filter((item) => {
    if (!item.eventDate) return false;

    try {
      const eventDate = new Date(item.eventDate);
      const eventYear = eventDate.getFullYear();
      const eventMonth = eventDate.getMonth() + 1; // getMonth()는 0부터 시작

      return eventYear === year && eventMonth === month;
    } catch {
      return false;
    }
  });
});

/**
 * 날짜별로 그룹화된 이벤트 목록
 */
const groupedEventsByDate = computed(() => {
  const grouped = {};
  filteredEventsByMonth.value.forEach((item) => {
    const dateKey = item.eventDate || new Date().toISOString().split("T")[0];
    if (!grouped[dateKey]) {
      grouped[dateKey] = [];
    }
    grouped[dateKey].push(item);
  });
  // 날짜순으로 정렬 (최신순)
  const sortedKeys = Object.keys(grouped).sort((a, b) => {
    return new Date(b) - new Date(a);
  });
  const sortedGrouped = {};
  sortedKeys.forEach((key) => {
    sortedGrouped[key] = grouped[key];
  });
  return sortedGrouped;
});

/**
 * 참여한 이벤트 없음 데이터 표시 여부
 */
const showEndedNoData = computed(() => {
  return filteredEventsByMonth.value.length === 0;
});

/**
 * 날짜 라벨 포맷팅 (aria-label용)
 * @param dateKey - YYYY-MM-DD 형식의 날짜 문자열
 */
function formatDateLabel(dateKey) {
  try {
    const date = new Date(dateKey);
    return format(date, "yyyy년 M월 d일", { locale: ko });
  } catch {
    return dateKey;
  }
}

/**
 * 날짜 표시 포맷팅 (화면 표시용)
 * @param dateKey - YYYY-MM-DD 형식의 날짜 문자열
 */
function formatDateDisplay(dateKey) {
  try {
    const date = new Date(dateKey);
    return format(date, "yyyy.MM.dd", { locale: ko });
  } catch {
    return dateKey;
  }
}

/**
 * 날짜 범위를 aria-label용으로 포맷팅
 * @param dateRange - "YYYY-MM-DD ~ YYYY-MM-DD" 형식의 날짜 범위 문자열
 */
function formatDateRangeLabel(dateRange) {
  if (!dateRange) return "";
  try {
    const [startDate, endDate] = dateRange.split(" ~ ");
    if (startDate && endDate) {
      const start = format(new Date(startDate), "yyyy년 M월 d일", {
        locale: ko,
      });
      const end = format(new Date(endDate), "yyyy년 M월 d일", { locale: ko });
      return `이벤트 기간: ${start}부터 ${end}까지`;
    }
    return `이벤트 기간: ${dateRange}`;
  } catch {
    return `이벤트 기간: ${dateRange}`;
  }
}

// ==========================================
// 월 선택 바텀시트 관련
// ==========================================
/**
 * 선택된 월 라벨
 */
const selectedMonthLabel = computed(() => {
  const selectedItem = monthSelectItems.value.find(
    (item) => item.value === monthMarks.value
  );
  return selectedItem ? selectedItem.main : "2025년 5월";
});

/**
 * 월 선택 바텀시트 열기
 */
function openMonthSheet() {
  isMonthSheetOpen.value = true;
}

/**
 * 월 선택 마크 업데이트
 */
async function onMonthMark(value, checked) {
  if (checked) {
    monthMarks.value = value;
    const selectedItem = monthSelectItems.value.find(
      (item) => item.value === value
    );
    if (selectedItem) {
      selectedYear.value = selectedItem.year;
      selectedMonthValue.value = selectedItem.month.toString();
      viewDate.value = new Date(selectedItem.year, selectedItem.month - 1, 1);
    }
    isMonthSheetOpen.value = false;
    // 바텀시트가 닫힌 후 InlineDropdown으로 초점 이동
    await nextTick();
    if (monthDropdownRef.value) {
      const button =
        monthDropdownRef.value.$el?.querySelector("button") ||
        monthDropdownRef.value.$el?.querySelector("[role='button']") ||
        monthDropdownRef.value.$el;
      if (button instanceof HTMLElement) {
        button.focus();
      }
    }
  } else if (monthMarks.value === value) {
    monthMarks.value = null;
  }
}

/**
 * 월 선택 카드 클릭
 */
async function toggleMonthMark(item) {
  if (item?.disabled) return;
  if (monthMarks.value === item.value) {
    return;
  }
  monthMarks.value = item.value;
  selectedYear.value = item.year;
  selectedMonthValue.value = item.month.toString();
  viewDate.value = new Date(item.year, item.month - 1, 1);
  isMonthSheetOpen.value = false;
  // 바텀시트가 닫힌 후 InlineDropdown으로 초점 이동
  await nextTick();
  if (monthDropdownRef.value) {
    const button =
      monthDropdownRef.value.$el?.querySelector("button") ||
      monthDropdownRef.value.$el?.querySelector("[role='button']") ||
      monthDropdownRef.value.$el;
    if (button instanceof HTMLElement) {
      button.focus();
    }
  }
}

/**
 * 월 선택 마크 상태 확인
 */
function setMonthMark(item) {
  if (monthMarks.value == "" && item.selected) {
    return item.selected;
  } else if (monthMarks.value !== null) {
    return monthMarks.value === item.value;
  }
  return false;
}

/**
 * 이벤트 상태 정보 계산 (라벨, 색상, 클래스명)
 * - 진행중: 이벤트가 진행 중일 때
 * - 추첨중: 이벤트 종료 후, 당첨정보 개시일 이전까지
 * - 당첨: 이벤트 종료 후, 당첨되었을 경우 당첨정보 개시일에
 * - 미당첨: 이벤트 종료 후, 낙첨되었을 경우 당첨정보 개시일에
 */
function getEventStatus(item) {
  let label = null;
  let color = null;
  let className = null;

  // 진행 중 이벤트인 경우
  if (item.categoryType === "진행 중 이벤트" || item.eventStatus === "ing") {
    label = "진행중";
    color = "green";
    className = "is-ing";
  }
  // eventStatus 기반 상태 확인
  else if (item.eventStatus) {
    switch (item.eventStatus) {
      case "pending":
        label = "추첨중";
        color = "green";
        className = "is-pending";
        break;
      case "win":
        label = "당첨";
        color = "blue";
        className = "is-win";
        break;
      case "lose":
        label = "미당첨";
        color = "gray";
        className = "is-lose";
        break;
      case "ing":
        label = "진행중";
        color = "green";
        className = "is-ing";
        break;
      default:
        break;
    }
  }
  // 종료 이벤트인 경우 - eventStatus가 없으면 null 반환
  else if (item.categoryType === "종료 이벤트") {
    // null 반환
  }
  // 이벤트 종료 후 상태 확인 (eventStatus가 없지만 다른 조건으로 판단)
  else if (item.isEventEnded) {
    if (!item.isWinnerAnnounced) {
      label = "추첨중";
      color = "green";
      className = "is-pending";
    } else if (item.isWon) {
      label = "당첨";
      color = "blue";
      className = "is-win";
    } else {
      label = "미당첨";
      color = "gray";
      className = "is-lose";
    }
  }
  // 기존 rightLabel이 있으면 그대로 사용
  else if (item.rightLabel) {
    label = item.rightLabel;
  }

  return {
    label,
    color,
    className,
  };
}

/**
 * 이벤트 제목 클릭 핸들러
 * @param item - 이벤트 아이템
 */
function handleEventClick(item) {
  // TODO: 이벤트 상세 화면으로 이동하는 로직 구현
  console.log("이벤트 상세 화면으로 이동:", item.id);
}

/**
 * 당첨 내역 보기 버튼 클릭 핸들러
 * @param item - 이벤트 아이템
 */
function handleWinnerDetailClick(item) {
  // TODO: 실제 API에서 당첨 내역 데이터를 가져와서 winnerItems에 설정
  // 현재는 더미 데이터 사용
  isWinnerSheetOpen.value = true;
}

// ==========================================
// 이벤트 데이터
// ==========================================
// 참여한 이벤트 데이터 (진행 중 이벤트 + 종료 이벤트 포함)
const eventAppliedItems = [
  {
    categoryType: "진행 중 이벤트",
    id: 1,
    eventDate: "2025-05-01",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon1.png`,
      alt: "",
    },
    rightLabel: "D-14",
    rightLabelColor: "blue",
    sub: "IKEA 신한카드로 결제하고",
    main: "최대 10만원 캐시백 받기",
    date: "2025-05-01 ~ 2025-05-31",
  },
  {
    categoryType: "진행 중 이벤트",
    id: 7,
    eventDate: "2025-05-03",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon4.png`,
      alt: "",
    },
    sub: "앱에서 결제하고",
    main: "추가 적립 받기",
    date: "2025-05-01 ~ 2025-05-15",
  },
  {
    categoryType: "진행 중 이벤트",
    id: 10,
    eventDate: "2025-05-04",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon2.png`,
      alt: "",
    },
    rightLabel: "D-3",
    rightLabelColor: "blue",
    sub: "청소년 특별 혜택",
    main: "영화 할인 쿠폰",
    date: "2025-05-01 ~ 2025-05-07",
  },
  {
    categoryType: "진행 중 이벤트",
    id: 11,
    eventDate: "2025-05-04",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon1.png`,
      alt: "",
    },
    sub: "문화센터 이용하고",
    main: "강좌 수강료 할인",
    date: "2025-05-01 ~ 2025-05-20",
  },
  {
    categoryType: "진행 중 이벤트",
    id: 12,
    eventDate: "2025-05-04",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon4.png`,
      alt: "",
    },
    sub: "앱 다운로드하고",
    main: "신규 가입 혜택",
    date: "2025-05-01 ~ 2025-05-31",
  },
  {
    categoryType: "진행 중 이벤트",
    id: 13,
    eventDate: "2025-05-05",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon5.png`,
      alt: "",
    },
    rightLabel: "D-10",
    rightLabelColor: "blue",
    sub: "렌터카 예약하고",
    main: "추가 할인 받기",
    date: "2025-05-01 ~ 2025-05-15",
  },
  {
    categoryType: "종료 이벤트",
    id: 17,
    eventDate: "2025-05-01",
    eventStatus: "pending",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon7.png`,
      alt: "",
    },
    label: "이벤트 모음.zip",
    labelColor: "green",
    sub: "캐시백부터 할인까지 여기 다 있ZIP",
    main: "해외여행 필수템",
    date: "2025-04-01 ~ 2025-04-30",
  },
  {
    categoryType: "종료 이벤트",
    id: 18,
    eventDate: "2025-05-01",
    eventStatus: "win",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon3.png`,
      alt: "",
    },
    sub: "SOL페이에 티머니 등록하고",
    main: "1등 당첨되면 발뮤다 더 토스트",
    date: "2025-04-01 ~ 2025-04-30",
    description: "발뮤다 더 토스트 오븐",
    winnerTypeCount: 1, // 당첨 유형 1개: 문구만 표시
  },
  {
    categoryType: "종료 이벤트",
    id: 19,
    eventDate: "2025-05-02",
    eventStatus: "lose",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon3.png`,
      alt: "",
    },
    sub: "SOL페이에 티머니 등록하고",
    main: "1등 당첨되면 발뮤다 더 토스트",
    date: "2025-04-01 ~ 2025-04-30",
  },
  {
    categoryType: "종료 이벤트",
    id: 20,
    eventDate: "2025-05-02",
    eventStatus: "pending",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon3.png`,
      alt: "",
    },
    sub: "카드 발급하고",
    main: "신규 발급 혜택",
    date: "2025-04-15 ~ 2025-04-30",
  },
  {
    categoryType: "종료 이벤트",
    id: 21,
    eventDate: "2025-05-03",
    eventStatus: "win",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon2.png`,
      alt: "",
    },
    sub: "청소년 특별 이벤트",
    main: "도서 구매 할인",
    date: "2025-04-10 ~ 2025-04-30",
    winnerTypeCount: 2, // 당첨 유형 2개 이상: 버튼 표시
  },
  {
    categoryType: "종료 이벤트",
    id: 22,
    eventDate: "2025-05-03",
    eventStatus: "lose",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon1.png`,
      alt: "",
    },
    sub: "백화점에서 쇼핑하고",
    main: "추가 할인 받기",
    date: "2025-04-15 ~ 2025-04-30",
  },
  {
    categoryType: "종료 이벤트",
    id: 23,
    eventDate: "2025-05-04",
    eventStatus: "pending",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon4.png`,
      alt: "",
    },
    sub: "앱 업데이트하고",
    main: "이벤트 참여하기",
    date: "2025-04-20 ~ 2025-04-30",
  },
  {
    categoryType: "종료 이벤트",
    id: 24,
    eventDate: "2025-05-05",
    eventStatus: "win",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon5.png`,
      alt: "",
    },
    sub: "항공권 예약하고",
    main: "마일리지 적립",
    date: "2025-04-01 ~ 2025-04-30",
    winnerTypeCount: 2, // 당첨 유형 2개 이상: 버튼 표시
  },
  {
    categoryType: "종료 이벤트",
    id: 25,
    eventDate: "2025-05-05",
    eventStatus: "win",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon5.png`,
      alt: "",
    },
    sub: "항공권 예약하고",
    main: "마일리지 적립",
    date: "2025-04-01 ~ 2025-04-30",
    description: "어드민에서 설정한 당첨상품명 노출영역입니다.",
    winnerTypeCount: 1, // 당첨 유형 1개: 문구만 표시
  },
  {
    categoryType: "종료 이벤트",
    id: 26,
    eventDate: "2025-05-05",
    eventStatus: "lose",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon3.png`,
      alt: "",
    },
    sub: "카드 혜택 이벤트",
    main: "추가 적립 받기",
    date: "2025-04-10 ~ 2025-04-30",
  },
  {
    categoryType: "종료 이벤트",
    id: 27,
    eventDate: "2025-05-05",
    eventStatus: "pending",
    icon: {
      src: `${$cdnURL}/images/dummy/thumb_benefit_cupon4.png`,
      alt: "",
    },
    sub: "결제계좌 변경하고",
    main: "신세계 백화점 상품권 포함 5가지 혜택 받기",
    date: "2025-05-01 ~ 2025-05-31",
  },
];
</script>
