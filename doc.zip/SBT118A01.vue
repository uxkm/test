<route lang="yaml">
meta:
  id: SBT118A01
  title: 참여한 이벤트
  menu: "혜택 > 이벤트 메인화면 > 이벤트 전체보기 > 응모이력:참여한이벤트 > 월 선택(BS)"
  layout: SubLayout
  category: 혜택
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  header:
    variant: sub
    fixed: true
    back: true
    close: false
</route>
<template>
  <BottomSheet
    closableDimm
    dimmed
    title="조회 기간을 선택해주세요 (최근 9개월)"
    v-model="isOpen"
    class="not-padding-y"
  >
    <div class="sc-list sc-select__list mark full">
      <div class="select-list__group">
        <div
          v-for="(item, i) in items"
          :key="`check-${i}`"
          class="select-list__item"
        >
          <BasicCard
            class="select-card select-card__check"
            variant="white"
            :disabled="item.disabled"
            @contentClick="toggleMark(item)"
            :selected="setMark(item)"
          >
            <ListItem
              class="select-cardlist__item"
              align="centered"
              :left="{ mainText: item.main }"
              :class="{ 'disabled-item': item.disabled }"
            >
              <template #rightControl>
                <Checkbox
                  :value="item.value"
                  :disabled="item.disabled"
                  variant="mark"
                  align="left"
                  class="select-card__checkbox"
                  :model-value="setMark(item)"
                  @update:model-value="onMark(item.value, $event)"
                  @click.stop
                />
              </template>
            </ListItem>
          </BasicCard>
        </div>
      </div>
    </div>
  </BottomSheet>
</template>

<script setup>
import { ref } from "vue";
import { BottomSheet, BasicCard, ListItem, Checkbox } from "@shc-nss/ui/solid";

const isOpen = defineModel({ default: true });

// 이벤트 선택 아이템
const items = ref([
  {
    value: "1",
    main: "2025년 5월",
    selected: true,
  },
  {
    value: "2",
    main: "2025년 4월",
    selected: false,
  },
  {
    value: "3",
    main: "2025년 3월",
    selected: false,
  },
  {
    value: "4",
    main: "2025년 2월",
    selected: false,
  },
  {
    value: "5",
    main: "2025년 1월",
    selected: false,
  },
  {
    value: "6",
    main: "2024년 12월",
    selected: false,
  },
  {
    value: "7",
    main: "2024년 11월",
    selected: false,
  },
  {
    value: "8",
    main: "2024년 10월",
    selected: false,
  },
  {
    value: "9",
    main: "2024년 9월",
    selected: false,
  },
]);

const marks = ref("1");

function onMark(value, checked) {
  if (checked) {
    marks.value = value;
  } else if (marks.value === value) {
    marks.value = null;
  }
}

function toggleMark(item) {
  if (item?.disabled) return;
  if (marks.value === item.value) {
    return;
  }
  marks.value = item.value;
}

function setMark(item) {
  if (marks.value == "" && item.selected) {
    return item.selected;
  } else if (marks.value !== null) {
    return marks.value === item.value;
  }
  return false;
}
</script>
