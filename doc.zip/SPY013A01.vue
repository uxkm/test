<route lang="yaml">
meta:
  id: SPY013A01
  title: ""
  menu: "페이 > 결제/뱅킹 Tab > 결제기능추가 > 약관동의 (BS)"
  layout: SubLayout
  category: 페이
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  header:
    fixed: true
    close: true
</route>
<template>
  <BottomSheet
    title="약관에 동의해주세요."
    v-model="isOpen"
  >
    <div
      class="sc-agree__list compound bg-gray"
      role="region"
    >
      <div class="agree-list__group">
        <!-- ======================================== -->
        <!-- 1뎁스 영역: 기본 약관 항목들 -->
        <!-- ======================================== -->
        <div
          class="agree-sublist"
          role="group"
        >
          <div
            v-for="item in subItems4"
            :key="item.value"
            class="agree-subitem"
            :class="{ 'agree-subitem__accordion': Boolean(item.accordion) }"
          >
            <template v-if="item.accordion">
              <SolidListAccordion
                class="agree-subitem__accordion"
                :rowClickable="false"
                :value="item.value"
                v-model:isExpanded="subAccordionState4[item.value]"
              >
                <template #title>
                  <div
                    class="agree-item agree-item__sub"
                    :class="{
                      'is-checked': subAgrees4.includes(item.value),
                    }"
                  >
                    <Checkbox
                      :value="item.value"
                      variant="box"
                      align="left"
                      :model-value="subAgrees4.includes(item.value)"
                      class="agree-item__checkbox item-checkbox__sub"
                      @update:model-value="onToggleSub4(item.value, $event)"
                      @click.stop
                    >
                      <template #label>
                        <span class="agree-item__label item-label__sub">{{ item.label }}</span>
                      </template>
                    </Checkbox>
                  </div>
                </template>
                <div class="agree-subitem__panel">
                  <div
                    v-if="item.value === 's4-1'"
                    class="agree-depth"
                  >
                    <!-- ======================================== -->
                    <!-- 2뎁스 영역: 서비스 이용약관 -->
                    <!-- ======================================== -->
                    <ul class="agree-sublist agree-sublist__depth2">
                      <li
                        v-for="depth2Item in subItemsDepth2_s4_1"
                        :key="depth2Item.value"
                        class="agree-subitem agree-subitem__depth2"
                      >
                        <!-- 아코디언이 있는 항목 -->
                        <template v-if="depth2Item.accordion">
                          <SolidListAccordion
                            class="agree-subitem__accordion accordion-depth2"
                            :rowClickable="false"
                            :value="depth2Item.value"
                            v-model:isExpanded="subAccordionState4[depth2Item.value]"
                          >
                            <template #title>
                              <div class="agree-item agree-item__sub">
                                <Checkbox
                                  :value="depth2Item.value"
                                  variant="mark"
                                  align="left"
                                  :model-value="subAgrees4.includes(depth2Item.value)"
                                  class="agree-item__checkbox item-checkbox__sub"
                                  @update:model-value="onToggleSub4(depth2Item.value, $event)"
                                  @click.stop
                                >
                                  <template #label>
                                    <span class="agree-item__label item-label__sub">{{
                                      depth2Item.label
                                    }}</span>
                                  </template>
                                </Checkbox>
                              </div>
                            </template>
                          </SolidListAccordion>
                        </template>

                        <!-- 일반 항목 -->
                        <div
                          v-else
                          class="agree-item agree-item__sub"
                        >
                          <Checkbox
                            :value="depth2Item.value"
                            variant="mark"
                            align="left"
                            :model-value="subAgrees4.includes(depth2Item.value)"
                            class="agree-item__checkbox item-checkbox__sub"
                            @update:model-value="onToggleSub4(depth2Item.value, $event)"
                            @click.stop
                          >
                            <template #label>
                              <span class="agree-item__label item-label__sub">{{
                                depth2Item.label
                              }}</span>
                            </template>
                          </Checkbox>
                          <IconButton
                            iconName="Chevron_right"
                            size="small"
                            :aria-label="`${depth2Item.label} 상세 보기`"
                            class="agree-subitem__trigger"
                          />
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </SolidListAccordion>
            </template>
          </div>
        </div>
      </div>
    </div>

    <template #footer>
      <BottomActionContainer :scrollDim="true">
        <BoxButtonGroup
          size="xlarge"
          variant="100"
        >
          <BoxButton text="확인" />
        </BoxButtonGroup>
      </BottomActionContainer>
    </template>
  </BottomSheet>
</template>

<script setup>
import {
  BottomActionContainer,
  BoxButton,
  BottomSheet,
  BoxButtonGroup,
  Checkbox,
  IconButton,
  SolidListAccordion,
} from "@shc-nss/ui/solid";
import { reactive, ref, watch } from "vue";

const isOpen = defineModel({ default: true });

const subItems4 = [
  {
    label: "약관 전체 동의",
    value: "s4-1",
    accordion: true,
  },
];

// 2뎁스 항목들 - 서비스 이용약관 (s4-1)
const subItemsDepth2_s4_1 = [
  { label: "[필수] 서비스 이용 안내", value: "s4-1-1" },
  { label: "[필수] 전자금융거래 기본약관", value: "s4-1-2" },
  { label: "[필수] 개인(신용)정보수집·이용동의", value: "s4-1-3" },
];

const basicAgree4 = ref(false);
const subAgrees4 = ref([]);
const subAccordionState4 = reactive({
  "s4-1": false, // 서비스 이용약관 2뎁스 아코디언 상태
});

/**
 * 동작 로직
 */
function onToggleSub4(value, checked) {
  const set = new Set(subAgrees4.value);

  // 약관 전체 동의(s4-1)를 체크/언체크할 때 하위 항목들도 함께 처리
  if (value === "s4-1") {
    if (checked) {
      // 약관 전체 동의 체크 시 하위 항목들도 모두 체크
      set.add("s4-1");
      subItemsDepth2_s4_1.forEach((item) => {
        set.add(item.value);
      });
    } else {
      // 약관 전체 동의 언체크 시 하위 항목들도 모두 언체크
      set.delete("s4-1");
      subItemsDepth2_s4_1.forEach((item) => {
        set.delete(item.value);
      });
    }
  } else {
    // 하위 항목 체크/언체크
    if (checked) set.add(value);
    else set.delete(value);

    // 하위 항목이 모두 체크되어 있으면 약관 전체 동의도 체크
    const allDepth2Checked = subItemsDepth2_s4_1.every((item) => set.has(item.value));
    if (allDepth2Checked) {
      set.add("s4-1");
    } else {
      set.delete("s4-1");
    }
  }

  subAgrees4.value = Array.from(set);

  // 약관 전체 동의(s4-1)와 하위 뎁스 모두 체크되어야 다음 버튼 활성화
  const requiredItems = ["s4-1", ...subItemsDepth2_s4_1.map((item) => item.value)];
  basicAgree4.value = requiredItems.every((item) => set.has(item));
}

watch(basicAgree4, (checked) => {
  if (checked) {
    // 약관 전체 동의(s4-1)와 하위 뎁스 모두 체크
    const allItems = [
      ...subItems4.map((item) => item.value),
      ...subItemsDepth2_s4_1.map((item) => item.value),
    ];
    subAgrees4.value = allItems;
  } else {
    subAgrees4.value = [];
  }
});
</script>
