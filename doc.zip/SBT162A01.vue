<route lang="yaml">
meta:
  id: SBT162A01
  title: ""
  menu: "혜택 > 이벤트 메인화면 > 이벤트 전체보기 > 이벤트선택(BS)"
  layout: SubLayout
  category: 혜택
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  header:
    variant: sub
    fixed: true
    back: true
    close: false
</route>
<template>
  <BottomSheet
    closableDimm
    dimmed
    title="이벤트를 선택해주세요"
    v-model="isOpen"
    class="non-padding-y"
  >
    <div class="sc-list sc-select__list mark full">
      <div class="select-list__group">
        <div
          v-for="(item, i) in items"
          :key="`check-${i}`"
          class="select-list__item"
        >
          <BasicCard
            class="select-card select-card__check"
            variant="white"
            :disabled="item.disabled"
            @contentClick="toggleMark(item)"
            :selected="setMark(item)"
          >
            <ListItem
              class="select-cardlist__item"
              align="centered"
              :left="{ mainText: item.main }"
              :class="{ 'disabled-item': item.disabled }"
            >
              <template #rightControl>
                <Checkbox
                  :value="item.value"
                  :disabled="item.disabled"
                  variant="mark"
                  align="left"
                  class="select-card__checkbox"
                  :model-value="setMark(item)"
                  @update:model-value="onMark(item.value, $event)"
                  @click.stop
                />
              </template>
            </ListItem>
          </BasicCard>
        </div>
      </div>
    </div>
  </BottomSheet>
</template>

<script setup>
import { ref } from "vue";
import { BottomSheet, BasicCard, ListItem, Checkbox } from "@shc-nss/ui/solid";

const isOpen = defineModel({ default: true });

// 이벤트 선택 아이템
const items = ref([
  {
    value: "ongoing",
    main: "진행중 이벤트",
    selected: true,
  },
  {
    value: "ended",
    main: "종료 이벤트",
    selected: false,
  },
]);

const marks = ref("ongoing");

function onMark(value, checked) {
  if (checked) {
    marks.value = value;
  } else if (marks.value === value) {
    marks.value = null;
  }
}

function toggleMark(item) {
  if (item?.disabled) return;
  if (marks.value === item.value) {
    return;
  }
  marks.value = item.value;
}

function setMark(item) {
  if (marks.value == "" && item.selected) {
    return item.selected;
  } else if (marks.value !== null) {
    return marks.value === item.value;
  }
  return false;
}
</script>
