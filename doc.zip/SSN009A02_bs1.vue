<route lang="yaml">
meta:
  id: SSN009A01_bs1
  title: 카드본인확인
  menu: Sign in/up > 가입하기 > 휴대폰 본인확인 > 타인 명의 핸드폰 > 약관동의 (BS)
  layout: SubLayout
  category: Sign in/up
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  header:
    fixed: true
    back: true
    close: true
</route>
<template>
  <BottomSheet
    title="약관에 동의해주세요."
    v-model="isOpen"
  >
    <div
      class="sc-agree__list compound bg-gray"
      role="region"
    >
      <div class="agree-list__group">
        <!-- ======================================== -->
        <!-- 1뎁스 영역: 기본 약관 항목들 -->
        <!-- ======================================== -->
        <div
          class="agree-sublist"
          role="group"
        >
          <div
            v-for="item in subItems4"
            :key="item.value"
            class="agree-subitem"
            :class="{ 'agree-subitem__accordion': Boolean(item.accordion) }"
          >
            <template v-if="item.accordion">
              <SolidListAccordion
                class="agree-subitem__accordion"
                :rowClickable="false"
                :value="item.value"
                v-model:isExpanded="subAccordionState4[item.value]"
              >
                <template #title>
                  <div
                    class="agree-item agree-item__sub"
                    :class="{
                      'is-checked': subAgrees4.includes(item.value),
                    }"
                  >
                    <Checkbox
                      :value="item.value"
                      variant="box"
                      align="left"
                      :model-value="subAgrees4.includes(item.value)"
                      class="agree-item__checkbox item-checkbox__sub"
                      @update:model-value="onToggleSub4(item.value, $event)"
                      @click.stop
                    >
                      <template #label>
                        <span class="agree-item__label item-label__sub">{{ item.label }}</span>
                      </template>
                    </Checkbox>
                  </div>
                </template>
                <div class="agree-subitem__panel">
                  <div
                    v-if="item.value === 's4-1'"
                    class="agree-depth"
                  >
                    <!-- ======================================== -->
                    <!-- 2뎁스 영역: 서비스 이용약관 -->
                    <!-- ======================================== -->
                    <ul class="agree-sublist agree-sublist__depth2">
                      <li
                        v-for="depth2Item in subItemsDepth2_s4_1"
                        :key="depth2Item.value"
                        class="agree-subitem agree-subitem__depth2"
                      >
                        <!-- 아코디언이 있는 항목 -->
                        <template v-if="depth2Item.accordion">
                          <SolidListAccordion
                            class="agree-subitem__accordion accordion-depth2"
                            :rowClickable="false"
                            :value="depth2Item.value"
                            v-model:isExpanded="subAccordionState4[depth2Item.value]"
                          >
                            <template #title>
                              <div class="agree-item agree-item__sub">
                                <Checkbox
                                  :value="depth2Item.value"
                                  variant="mark"
                                  align="left"
                                  :model-value="subAgrees4.includes(depth2Item.value)"
                                  class="agree-item__checkbox item-checkbox__sub"
                                  @update:model-value="onToggleSub4(depth2Item.value, $event)"
                                  @click.stop
                                >
                                  <template #label>
                                    <span class="agree-item__label item-label__sub">{{
                                      depth2Item.label
                                    }}</span>
                                  </template>
                                </Checkbox>
                              </div>
                            </template>
                          </SolidListAccordion>
                        </template>

                        <!-- 일반 항목 -->
                        <div
                          v-else
                          class="agree-item agree-item__sub"
                        >
                          <Checkbox
                            :value="depth2Item.value"
                            variant="mark"
                            align="left"
                            :model-value="subAgrees4.includes(depth2Item.value)"
                            class="agree-item__checkbox item-checkbox__sub"
                            @update:model-value="onToggleSub4(depth2Item.value, $event)"
                            @click.stop
                          >
                            <template #label>
                              <span class="agree-item__label item-label__sub">{{
                                depth2Item.label
                              }}</span>
                            </template>
                          </Checkbox>
                          <IconButton
                            iconName="Chevron_right"
                            size="small"
                            :aria-label="`${depth2Item.label} 상세 보기`"
                            class="agree-subitem__trigger"
                          />
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </SolidListAccordion>
            </template>
          </div>
        </div>
      </div>
    </div>

    <template #footer>
      <BottomActionContainer :scrollDim="true">
        <BoxButtonGroup
          size="xlarge"
          variant="100"
        >
          <BoxButton
            text="다음"
            :disabled="!basicAgree4"
          />
        </BoxButtonGroup>
      </BottomActionContainer>
    </template>
  </BottomSheet>
</template>

<script setup>
import {
  BottomActionContainer,
  BoxButton,
  BottomSheet,
  BoxButtonGroup,
  Checkbox,
  IconButton,
  SolidListAccordion,
} from "@shc-nss/ui/solid";
import { reactive, ref } from "vue";

const isOpen = defineModel({ default: true });

const subItems4 = [
  {
    label: "약관 전체 동의",
    value: "s4-1",
    accordion: true,
  },
];

// 2뎁스 항목들 - 서비스 이용약관 (s4-1)
const subItemsDepth2_s4_1 = [
  { label: "[필수] 카드사 서비스 이용 약관 동의", value: "s4-1-1" },
  { label: "[필수] 카드본인확인 서비스 이용 동의", value: "s4-1-2" },
  { label: "[필수] 개인(신용)정보 수집 및 이용 동의", value: "s4-1-3" },
  { label: "[필수] 고유식별정보 처리 동의", value: "s4-1-4" },
];

const basicAgree4 = ref(false);
const subAgrees4 = ref([]);
const subAccordionState4 = reactive({
  "s4-1": true, // 서비스 이용약관 2뎁스 아코디언 상태
});

/**
 * 하위뎁스(2뎁스) 항목들이 모두 체크되었는지 확인
 */
function isAllDepth2Checked() {
  const depth2Values = subItemsDepth2_s4_1.map((item) => item.value);
  return depth2Values.every((value) => subAgrees4.value.includes(value));
}

/**
 * 동작 로직
 */
function onToggleSub4(value, checked) {
  const set = new Set(subAgrees4.value);
  if (checked) set.add(value);
  else set.delete(value);
  subAgrees4.value = Array.from(set);

  // 약관 전체 동의(s4-1)를 체크한 경우
  if (value === "s4-1" && checked) {
    // 모든 하위뎁스 항목들도 체크
    subItemsDepth2_s4_1.forEach((item) => {
      if (!set.has(item.value)) {
        set.add(item.value);
      }
    });
    subAgrees4.value = Array.from(set);
    basicAgree4.value = true;
    return;
  }

  // 약관 전체 동의(s4-1)를 해제한 경우
  if (value === "s4-1" && !checked) {
    // 하위뎁스 항목들도 모두 해제
    subItemsDepth2_s4_1.forEach((item) => {
      set.delete(item.value);
    });
    subAgrees4.value = Array.from(set);
    basicAgree4.value = false;
    return;
  }

  // 하위뎁스 항목을 체크/해제한 경우
  if (subItemsDepth2_s4_1.some((item) => item.value === value)) {
    // 모든 하위뎁스가 체크되었는지 확인
    const allDepth2Checked = isAllDepth2Checked();

    if (allDepth2Checked) {
      // 모든 하위뎁스가 체크되면 약관 전체 동의(s4-1)도 체크
      if (!set.has("s4-1")) {
        set.add("s4-1");
        subAgrees4.value = Array.from(set);
      }
      basicAgree4.value = true;
    } else {
      // 하위뎁스 중 하나라도 해제되면 약관 전체 동의(s4-1)도 해제
      if (set.has("s4-1")) {
        set.delete("s4-1");
        subAgrees4.value = Array.from(set);
      }
      basicAgree4.value = false;
    }
  }
}
</script>

<style lang="scss" scoped></style>
