<route lang="yaml">
meta:
  id: SBT163A01
  title: ""
  menu: "혜택 > 이벤트 메인화면 > 이벤트 전체보기 > 응모이력:참여한이벤트 > 당첨이력(BS)"
  layout: SubLayout
  category: 혜택
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  header:
    variant: sub
    fixed: true
    back: true
    close: false
</route>
<template>
  <BottomSheet
    closableDimm
    dimmed
    title="[$사용자명$]님의 당첨 내역입니다."
    v-model="isOpen"
    class="not-padding-y"
  >
    <div class="sc-data__list">
      <div class="data-list__group">
        <DataList
          align="spaceBetween"
          v-for="(item, index) in items"
          :key="index"
        >
          <template #title>
            <span class="data-list__text">{{ item.date }}</span>
          </template>
          <template #content>
            <span class="data-list__text">{{ item.points }}</span>
          </template>
        </DataList>
      </div>
    </div>
    <template #footer>
      <BoxButton
        text="확인"
        color="primary"
        size="xlarge"
        @click="isOpen = false"
      />
    </template>
  </BottomSheet>
</template>

<script setup>
import { ref } from "vue";
import { BottomSheet, DataList, BoxButton } from "@shc-nss/ui/solid";

const isOpen = defineModel({ default: true });

// 당첨 내역 아이템
const items = ref([
  { date: "2025.05.01", points: "마이 신한 포인트 1,000p" },
  { date: "2025.05.02", points: "마이 신한 포인트 500p" },
  { date: "2025.05.03", points: "마이 신한 포인트 10,000" },
  { date: "2025.05.03", points: "마이 신한 포인트 800p" },
  { date: "2025.05.03", points: "마이 신한 포인트 2,000p" },
  { date: "2025.05.03", points: "마이 신한 포인트 마이 신한 포인트 마이 신한 포인트 포인트 2,000p" },
  { date: "2025.05.03", points: "마이 신한 포인트 100p" },
  { date: "2025.05.03", points: "마이 신한 포인트 100p" },
  { date: "2025.05.06", points: "마이 신한 포인트 500p" },
  { date: "2025.05.06", points: "마이 신한 포인트 500p" },
  { date: "2025.05.06", points: "마이 신한 포인트 500p" },
  { date: "2025.05.06", points: "마이 신한 포인트 500p" },
  { date: "2025.05.06", points: "마이 신한 포인트 500p" },
]);
</script>
