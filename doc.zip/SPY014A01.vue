<route lang="yaml">
meta:
  id: SPY014A01
  title: ""
  menu: "페이 > 결제/뱅킹 Tab > 결제기능추가 > 이용안내 (BS)"
  layout: SubLayout
  category: 페이
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  header:
    fixed: true
    close: true
</route>
<template>
  <BottomSheet
    title="이용안내"
    v-model="isOpen"
    class="info-cards-popup"
  >
    <div class="info-cards">
      <BasicCard
        v-for="(item, index) in infoItems"
        :key="index"
        class="info-card"
        variant="solid"
        color="gray"
      >
        <ListItem
          align="top"
          label-orientation="column"
          :left="{
            mainText: item.mainText,
            subText: item.subText,
            direction: 'column',
          }"
        >
          <template #leftIcon>
            <Icon
              name="CheckMark_off"
              :size="20"
              aria-hidden="true"
            />
          </template>
        </ListItem>
      </BasicCard>
    </div>
    <template #footer>
      <BottomActionContainer :scrollDim="true">
        <BoxButtonGroup
          size="xlarge"
          variant="100"
        >
          <BoxButton text="결제기능 추가" />
        </BoxButtonGroup>
      </BottomActionContainer>
    </template>
  </BottomSheet>
</template>

<script setup>
import {
  BottomActionContainer,
  BoxButton,
  BottomSheet,
  BoxButtonGroup,
  Checkbox,
  IconButton,
  SolidListAccordion,
  BasicCard,
  ListItem,
  Icon,
} from "@shc-nss/ui/solid";
import { reactive, ref, watch } from "vue";

const isOpen = defineModel({ default: true });

const infoItems = [
  {
    mainText: "온·오프라인 결제가 가능해요",
    subText: "단, 기차·상품권(충전)·대학등록금 등\n일부 업종은 결제할 수 없어요.",
  },
  {
    mainText: "소득공제가 가능해요",
    subText: "결제 기능을 사용하면 소득공제 정보가\n자동으로 등록돼요.",
  },
];

const subItems4 = [
  {
    label: "약관 전체 동의",
    value: "s4-1",
    accordion: true,
  },
];

// 2뎁스 항목들 - 서비스 이용약관 (s4-1)
const subItemsDepth2_s4_1 = [
  { label: "[필수] 서비스 이용 안내", value: "s4-1-1" },
  { label: "[필수] 전자금융거래 기본약관", value: "s4-1-2" },
  { label: "[필수] 개인(신용)정보수집·이용동의", value: "s4-1-3" },
];

const basicAgree4 = ref(false);
const subAgrees4 = ref([]);
const subAccordionState4 = reactive({
  "s4-1": false, // 서비스 이용약관 2뎁스 아코디언 상태
});

/**
 * 동작 로직
 */
function onToggleSub4(value, checked) {
  const set = new Set(subAgrees4.value);

  // 약관 전체 동의(s4-1)를 체크/언체크할 때 하위 항목들도 함께 처리
  if (value === "s4-1") {
    if (checked) {
      // 약관 전체 동의 체크 시 하위 항목들도 모두 체크
      set.add("s4-1");
      subItemsDepth2_s4_1.forEach((item) => {
        set.add(item.value);
      });
    } else {
      // 약관 전체 동의 언체크 시 하위 항목들도 모두 언체크
      set.delete("s4-1");
      subItemsDepth2_s4_1.forEach((item) => {
        set.delete(item.value);
      });
    }
  } else {
    // 하위 항목 체크/언체크
    if (checked) set.add(value);
    else set.delete(value);

    // 하위 항목이 모두 체크되어 있으면 약관 전체 동의도 체크
    const allDepth2Checked = subItemsDepth2_s4_1.every((item) => set.has(item.value));
    if (allDepth2Checked) {
      set.add("s4-1");
    } else {
      set.delete("s4-1");
    }
  }

  subAgrees4.value = Array.from(set);

  // 약관 전체 동의(s4-1)와 하위 뎁스 모두 체크되어야 다음 버튼 활성화
  const requiredItems = ["s4-1", ...subItemsDepth2_s4_1.map((item) => item.value)];
  basicAgree4.value = requiredItems.every((item) => set.has(item));
}

watch(basicAgree4, (checked) => {
  if (checked) {
    // 약관 전체 동의(s4-1)와 하위 뎁스 모두 체크
    const allItems = [
      ...subItems4.map((item) => item.value),
      ...subItemsDepth2_s4_1.map((item) => item.value),
    ];
    subAgrees4.value = allItems;
  } else {
    subAgrees4.value = [];
  }
});
</script>
