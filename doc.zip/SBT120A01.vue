<route lang="yaml">
meta:
  id: SBT120A01
  title: 이벤트
  menu: "혜택 > 이벤트 메인화면 > 이벤트 전체보기: 종료된 이벤트 > 월 선택(BS)"
  layout: SubLayout
  category: 혜택
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  header:
    variant: sub
    fixed: true
    back: true
    close: false
</route>
<template>
  <BottomSheet
    closableDimm
    dimmed
    title="조회 기간 선택"
    v-model="isOpen"
    class="not-padding-t"
  >
    <!-- 월 조회 필터 - SOLID에서 제공한 컴포넌트 형식에 따라 변경 가능성 있음 -->
    <div class="month-filter__header full-width">
      <DatePicker
        v-model:viewDate="viewDate"
        class="month-filter__datepicker"
      >
        <template #header>
          <IconButton
            class="sv-datepicker__header-btn sv-datepicker__header-btn--prev"
            size="large"
            @click="goPrevMonth"
            :aria-label="prevMonthAriaLabel"
          >
            <template #icon>
              <Icon
                name="Chevron_left"
                :fixed-size="false"
                aria-hidden="true"
              />
            </template>
          </IconButton>
          <h2
            class="sv-datepicker__title"
            tabindex="0"
            :aria-label="currentMonthAriaLabel"
          >
            <span
              class="sv-datepicker__title-content"
              aria-hidden="true"
            >
              {{ title }}
            </span>
          </h2>
          <IconButton
            class="sv-datepicker__header-btn sv-datepicker__header-btn--next"
            size="large"
            @click="goNextMonth"
            :aria-label="nextMonthAriaLabel"
          >
            <template #icon>
              <Icon
                name="Chevron_right"
                :fixed-size="false"
                aria-hidden="true"
              />
            </template>
          </IconButton>
        </template>
      </DatePicker>
    </div>
    <div class="month-filter__body">
      <SelectBoxGroup
        :items="items"
        v-model="selectedValue"
        orientation="horizontal"
        @update:model-value="onSelectValue"
        class="month-filter__grid"
        aria-label="월 선택"
      >
        <template #contents="{ item }">
          <span class="sv-select-box__label" :aria-label="item['aria-label']">{{ item.displayLabel }}</span>
        </template>
      </SelectBoxGroup>
    </div>
    <template #footer>
      <BoxButton
        @click="isOpen = false"
        text="확인"
        size="xlarge"
        color="primary"
      />
    </template>
  </BottomSheet>
</template>

<script setup>
import { ref, computed } from "vue";
import {
  BottomSheet,
  DatePicker,
  IconButton,
  Icon,
  SelectBoxGroup,
  BoxButton,
} from "@shc-nss/ui/solid";
import { addMonths, format, startOfMonth, getYear } from "date-fns";
import { ko } from "date-fns/locale";

const isOpen = defineModel({ default: true });

// DatePicker 관련 로직
const today = new Date();
const viewDate = ref(new Date());

const title = computed(() => {
  // 년도만 표시 (달 제거)
  return format(viewDate.value, "yyyy년", { locale: ko });
});

const currentMonthAriaLabel = computed(() => {
  return `현재 ${title.value}`;
});

const prevMonthAriaLabel = computed(() => {
  const prevMonth = addMonths(viewDate.value, -1);
  const prevYear = getYear(prevMonth);

  // 년도만 표시 (달 제거)
  return `이전 ${prevYear}년도 선택`;
});

const nextMonthAriaLabel = computed(() => {
  const nextMonth = addMonths(viewDate.value, 1);
  const nextYear = getYear(nextMonth);

  // 년도만 표시 (달 제거)
  return `다음 ${nextYear}년도 선택`;
});

const goPrevMonth = () => {
  viewDate.value = startOfMonth(addMonths(viewDate.value, -1));
};

const goNextMonth = () => {
  viewDate.value = startOfMonth(addMonths(viewDate.value, 1));
};

// 월 선택 아이템 (1월 ~ 12월) - UI에는 "8월"만 표시, aria-label에는 "2025년 8월" 형식
const items = computed(() => {
  const year = getYear(viewDate.value);
  return [
    { value: "1", label: "1월", displayLabel: "1월", "aria-label": `${year}년 1월` },
    { value: "2", label: "2월", displayLabel: "2월", "aria-label": `${year}년 2월` },
    { value: "3", label: "3월", displayLabel: "3월", "aria-label": `${year}년 3월` },
    { value: "4", label: "4월", displayLabel: "4월", "aria-label": `${year}년 4월` },
    { value: "5", label: "5월", displayLabel: "5월", "aria-label": `${year}년 5월` },
    { value: "6", label: "6월", displayLabel: "6월", "aria-label": `${year}년 6월` },
    { value: "7", label: "7월", displayLabel: "7월", "aria-label": `${year}년 7월` },
    { value: "8", label: "8월", displayLabel: "8월", "aria-label": `${year}년 8월` },
    { value: "9", label: "9월", displayLabel: "9월", "aria-label": `${year}년 9월` },
    { value: "10", label: "10월", displayLabel: "10월", "aria-label": `${year}년 10월` },
    { value: "11", label: "11월", displayLabel: "11월", "aria-label": `${year}년 11월` },
    { value: "12", label: "12월", displayLabel: "12월", "aria-label": `${year}년 12월` },
  ];
});

const selectedValue = ref("8");

function onSelectValue(value) {
  selectedValue.value = value;
}
</script>
