<route lang="yaml">
meta:
  id: SPY268A01
  title:
  menu: 페이 > 페이:결제/뱅킹 Tab > 신한Pay머니 이용내역 > 송금받기 완료 화면
  layout: SubLayout
  category: 페이
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  header:
    fixed: false
    back: false
    close: false
</route>
<template>
  <!-- 콘텐츠 영역 -->
  <div class="sc-contents__body pt-3xl">
    <div class="sc-feedback__list sc-feedback__sucsess">
      <div class="sc-feedback__inner">
        <div class="feedback-icon">
          <ScIcon
            iconName="icon-sucsess"
            size="68"
          />
        </div>
        <div class="feedback-content">
          <p class="feedback-title">김신한님이 보낸<br />150,110원을 받았어요</p>
        </div>
      </div>
    </div>
  </div>
  <div class="sc-contents__foot section">
    <ListCard
      variant="solid"
      color="gray"
      class="card-list__lg"
    >
      <ListItem
        align="centered"
        :left="{ mainText: leftImageItem.main }"
        :aria-label="`${leftImageItem.main} 카드`"
        tabindex="0"
      >
        <template #leftIcon>
          <img
            :src="leftImageItem.image"
            :alt="leftImageItem.main"
            class="thumb-card"
            aria-hidden="true"
          />
        </template>
      </ListItem>
    </ListCard>
  </div>

  <BottomActionContainer :scrollDim="true">
    <BoxButtonGroup
      size="xlarge"
      variant="100"
    >
      <BoxButton text="확인" />
    </BoxButtonGroup>
  </BottomActionContainer>
</template>

<script setup>
import { AppContextKey } from "@/configs/inject/appContext";
import { ScIcon } from "@shc-nss/ui/shc";
import {
  BottomActionContainer,
  BoxButton,
  BoxButtonGroup,
  ListCard,
  ListItem,
} from "@shc-nss/ui/solid";
import { inject } from "vue";

const { $cdnURL } = inject(AppContextKey);

const imageItems = [
  {
    label: "신한Pay머니",
    main: "신한Pay머니",
    icon: "shinhanpaymoney",
    image: `${$cdnURL}/images/pages/pay/shinhanpaymoney.svg`,
  },
];

const leftImageItem = imageItems[0];
</script>

<style lang="scss" scoped></style>
