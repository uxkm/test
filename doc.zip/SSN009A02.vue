<route lang="yaml">
meta:
  id: SSN009A01
  title: 카드본인확인
  menu: Sign in/up > 가입하기 > 휴대폰 본인확인 > 타인 명의 핸드폰
  layout: SubLayout
  category: Sign in/up
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  header:
    fixed: true
    back: true
    close: true
</route>
<template>
  <ScTitle class="type-single-left section">
    <template #inline>
      <div class="flex items-center">
        <h2 class="title-main">카드정보를 입력해주세요.</h2>
        <Tooltip
          :open="false"
          placement="top-right"
          :showClose="true"
        >
          <template #content>
            정상 사용이 가능한 신한카드번호를 입력해주세요. <br />
            1. 본인명의의 개인카드만 인증할 수 있습니다(법인카드 불가).<br />
            2. 가족회원의 경우 가족카드로 인증할 수 있습니다.<br />
            3. 모바일 단독카드만을 소지한 경우 인증할 수 없습니다.
          </template>
        </Tooltip>
      </div>
    </template>
  </ScTitle>
  <div class="sc-contents__body">
    <div class="section">
      <div class="sc-input__field">
        <div class="input-field__group">
          <div class="field-item">
            <InputField
              label="휴대폰번호"
              :required="true"
              :input-items="phoneNumberInputItems"
              v-model:values="phoneNumberValues"
              variant="outline"
              align="left"
              :show-clear="false"
              :disabled="true"
              aria-label="휴대폰번호"
            />
          </div>
        </div>
        <div class="input-field__group">
          <div
            class="field-item__rowgroup"
            :class="{ 'is-error': cardNumberError }"
          >
            <div class="rowgroup-inner">
              <div class="field-item">
                <InputField
                  label="카드번호"
                  :required="true"
                  :input-items="[
                    {
                      id: 'cardNumber1',
                      name: 'cardNumber1',
                      type: 'tel',
                      placeholder: '○○○○',
                      inputmode: 'numeric',
                      mask: {
                        mask: 'nnnn',
                        definitions: {
                          n: { mask: '#', placeholderChar: '○' },
                        },
                        overwrite: false,
                      },
                      length: 4,
                    },
                  ]"
                  v-model:values="cardNumber1Values"
                  variant="outline"
                  align="center"
                  :show-clear="false"
                  aria-label="카드번호 첫 번째 자리"
                />
              </div>
              <div class="field-item field-item__masked">
                <InputField
                  label=""
                  :required="true"
                  :input-items="[
                    {
                      id: 'cardNumber2',
                      name: 'cardNumber2',
                      type: 'tel',
                      placeholder: '○○○○',
                      inputmode: 'numeric',
                      mask: {
                        mask: 'mmmm',
                        definitions: {
                          m: { mask: '#', displayChar: '●', placeholderChar: '○' },
                        },
                        overwrite: false,
                      },
                      length: 4,
                    },
                  ]"
                  v-model:values="cardNumber2Values"
                  variant="outline"
                  align="center"
                  :show-clear="false"
                  aria-label="카드번호 두 번째 자리"
                />
              </div>
              <div class="field-item field-item__masked">
                <InputField
                  label=""
                  :required="true"
                  :input-items="[
                    {
                      id: 'cardNumber3',
                      name: 'cardNumber3',
                      type: 'tel',
                      placeholder: '○○○○',
                      inputmode: 'numeric',
                      mask: {
                        mask: 'mmmm',
                        definitions: {
                          m: { mask: '#', displayChar: '●', placeholderChar: '○' },
                        },
                        overwrite: false,
                      },
                      length: 4,
                    },
                  ]"
                  v-model:values="cardNumber3Values"
                  variant="outline"
                  align="center"
                  :show-clear="false"
                  aria-label="카드번호 세 번째 자리"
                />
              </div>
              <div class="field-item">
                <InputField
                  label=""
                  :required="true"
                  :input-items="[
                    {
                      id: 'cardNumber4',
                      name: 'cardNumber4',
                      type: 'tel',
                      placeholder: '○○○○',
                      inputmode: 'numeric',
                      mask: {
                        mask: 'nnnn',
                        definitions: {
                          n: { mask: '#', placeholderChar: '○' },
                        },
                        overwrite: false,
                      },
                      length: 4,
                    },
                  ]"
                  v-model:values="cardNumber4Values"
                  variant="outline"
                  align="center"
                  :show-clear="false"
                  aria-label="카드번호 네 번째 자리"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <BottomActionContainer :scrollDim="true">
    <div class="bottom-action__row mb-2xl">
      <BoxButtonGroup
        size="xlarge"
        variant="100"
      >
        <BoxButton text="텍스트" />
      </BoxButtonGroup>
    </div>
    <div class="bottom-keypad-wrap">
      <!-- 2, 3번째 에는 mode="secure"로 변경 기본은 normal -->
      <Keypad
        v-model="inputValue"
        allowLeadingZero
        mode="normal"
        showLeftOption
        showRightOption
        :maxLength="maxLength"
        @update:modelValue="updateValue"
      />
    </div>
  </BottomActionContainer>
</template>

<script setup>
import { ScTitle } from "@shc-nss/ui/shc";
import {
  BaseDropdown,
  BottomActionContainer,
  BoxButton,
  BoxButtonGroup,
  Keypad,
  Tooltip,
  InputField,
} from "@shc-nss/ui/solid";
import { ref } from "vue";

// 휴대폰번호 (입력된 값이 들어오는 정보, disabled 처리)
const phoneNumberValues = ref({
  phoneNumber: "010-1234-5678",
});

const phoneNumberInputItems = [
  {
    id: "phoneNumber",
    name: "phoneNumber",
    type: "tel",
    label: "휴대폰번호",
    placeholder: "휴대폰번호 입력",
    length: 11,
    mask: {
      mask: "###-####-####",
      overwrite: false,
    },
  },
];

// 카드번호 (각 필드별로 개별 values 객체 사용)
const cardNumber1Values = ref({});
const cardNumber2Values = ref({});
const cardNumber3Values = ref({});
const cardNumber4Values = ref({});

// 카드번호 에러 상태
const cardNumberError = ref(false);

// Keypad 관련
const inputValue = ref("");
const maxLength = ref(16);

const updateValue = (value) => {
  inputValue.value = value;
  // 카드번호 입력 처리 로직 추가 가능
};
</script>
