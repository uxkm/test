<route lang="yaml">
meta:
  id: SPY277A01
  title: 타사카드 이용내역
  menu: "페이 > 페이:결제/뱅킹 Tab > 타사카드 이용내역"
  layout: SubLayout
  category: 페이
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  mainClassList: "pt-none"
  header:
    fixed: true
    back: true
    home: true
</route>
<template>
  <!-- 콘텐츠 영역 -->
  <div class="sc-contents__body usage-history external-card">
    <!-- 월별 조회 필터 - SOLID에서 제공한 컴포넌트 형식에 따라 변경 가능성 있음 -->
    <div class="usage-history__header is-sticky">
      <DatePicker
        v-model:viewDate="viewDate"
        class="usage-history__datepicker"
      >
        <template #header>
          <IconButton
            class="sv-datepicker__header-btn sv-datepicker__header-btn--prev"
            size="large"
            :disabled="!canGoPrev"
            @click="goPrevMonth"
            :aria-label="prevMonthAriaLabel"
          >
            <template #icon>
              <Icon
                name="Chevron_left"
                :fixed-size="false"
                aria-hidden="true"
              />
            </template>
          </IconButton>
          <h2
            class="sv-datepicker__title"
            tabindex="0"
            :aria-label="currentMonthAriaLabel"
          >
            <span
              class="sv-datepicker__title-content"
              aria-hidden="true"
            >
              {{ title }}
            </span>
          </h2>
          <IconButton
            class="sv-datepicker__header-btn sv-datepicker__header-btn--next"
            size="large"
            :disabled="!canGoNext"
            @click="goNextMonth"
            :aria-label="nextMonthAriaLabel"
          >
            <template #icon>
              <Icon
                name="Chevron_right"
                :fixed-size="false"
                aria-hidden="true"
              />
            </template>
          </IconButton>
        </template>
      </DatePicker>
    </div>

    <!-- 계좌 선택 영역 -->
    <!-- 진입한 계좌 상세화면의 계좌가 Defualt로 노출 -->
    <InlineDropdown
      class="sc-card__dropdown usage-history__dropdown section"
      :ariaLabel="accountAriaLabel"
      :isOpen="isHistoryDropdownOpen"
      @click="handleHistoryDropdownClick"
    >
      <template #value>
        <span class="card-display">
          <span class="card-info">
            <span class="card-title">{{ selectedAccount.bankName }}</span>
          </span>
        </span>
      </template>
    </InlineDropdown>

    <!-- 조회조건 선택 필터 -->
    <ListTitle
      title=""
      class="usage-history__filter section is-sticky"
    >
      <div class="flex items-center sort">
        <IconButton
          :color="false"
          :disabled="false"
          size="small"
          aria-label="조회조건 선택"
          @click="handleSortClick"
        >
          <template #icon>
            <Icon
              name="Sort"
              aria-hidden="true"
            />
          </template>
        </IconButton>
      </div>
    </ListTitle>

    <!-- 이용내역 리스트 -->
    <!-- 이용내역이 있을 때 -->
    <div
      class="section usage-history__body"
      v-if="usageHistoryByDate.length > 0"
    >
      <template
        v-for="(dateGroup, dateIndex) in usageHistoryByDate"
        :key="dateIndex"
      >
        <section class="usage-history__section">
          <h3
            class="usage-date__title"
            tabindex="0"
            :aria-label="dateGroup.date"
          >
            <span aria-hidden="true">{{ getDisplayDate(dateGroup.date) }}</span>
          </h3>
          <div class="usage-history__list">
            <BasicList
              v-for="(item, itemIndex) in dateGroup.items"
              :key="itemIndex"
              as="div"
              class="usage-history__item"
            >
              <ListItem align="centered">
                <template #leftMainText>
                  <strong class="usage-label">
                    <!-- 거래내역명 -->
                    {{ item.label }}
                    <!-- 계좌번호 끝 4자리 -->
                    {{ item.number }}
                  </strong>
                </template>
                <template #leftSubText>
                  <span class="usage-sub">
                    <!-- 시간 -->
                    <em class="usage-date">{{ item.dateTime }}</em>
                    <!-- 출처 -->
                    <em
                      v-for="(method, methodIndex) in item.paymentMethod"
                      :key="methodIndex"
                    >
                      {{ method }}
                    </em>
                  </span>
                </template>
                <template #rightMainText>
                  <strong class="usage-amount">{{ item.amount }}</strong>
                </template>
                <template #rightSubText>
                  <BoxButton
                    v-if="item.canCancel"
                    text="결제 취소"
                    color="tertiary"
                    size="xsmall"
                    @click="handleCancelPayment(item)"
                  />
                </template>
              </ListItem>
            </BasicList>
          </div>
        </section>

        <Divider
          v-if="dateIndex < usageHistoryByDate.length - 1"
          variant="basic"
          color="secondary"
        />
      </template>
    </div>

    <!-- 이용내역이 없을 때 -->
    <template v-else>
      <NoData mainText="이용 내역이 없어요." />
    </template>
  </div>
</template>

<script setup>
import { ScIcon } from "@shc-nss/ui/shc";
import {
  BasicCard,
  BasicList,
  BoxButton,
  DatePicker,
  Divider,
  Icon,
  IconButton,
  InlineDropdown,
  ListItem,
  ListTitle,
} from "@shc-nss/ui/solid";
import { addMonths, format, isAfter, startOfMonth } from "date-fns";
import { ko } from "date-fns/locale";
import { computed, ref } from "vue";
import NoData from "../../_module/NoData.vue";

const viewDate = ref(new Date());
const today = new Date();

const title = computed(() => {
  return format(viewDate.value, "yyyy.MM");
});

const titleAriaLabel = computed(() => {
  return format(viewDate.value, "yyyy년 M월", { locale: ko });
});

const currentMonthAriaLabel = computed(() => {
  return `현재 ${titleAriaLabel.value} 이용내역`;
});

const canGoPrev = computed(() => {
  // 이전 달로 이동 가능 여부 (필요시 minDate 체크)
  return true;
});

const canGoNext = computed(() => {
  // 다음 달로 이동 가능 여부: 다음 달이 오늘 날짜보다 미래이면 disabled
  const nextMonth = startOfMonth(addMonths(viewDate.value, 1));
  const currentMonth = startOfMonth(today);
  // 다음 달이 현재 월보다 미래이면 false (이용내역 없음)
  return !isAfter(nextMonth, currentMonth);
});

const prevMonthAriaLabel = computed(() => {
  if (!canGoPrev.value) {
    return "이전 달 이용내역 없음";
  }
  const prevMonth = addMonths(viewDate.value, -1);
  const prevMonthLabel = format(prevMonth, "yyyy년 M월", { locale: ko });
  return `이전 달 ${prevMonthLabel} 이용내역`;
});

const nextMonthAriaLabel = computed(() => {
  if (!canGoNext.value) {
    return "다음 달 이용내역 없음";
  }
  const nextMonth = addMonths(viewDate.value, 1);
  const nextMonthLabel = format(nextMonth, "yyyy년 M월", { locale: ko });
  return `다음 달 ${nextMonthLabel} 이용내역`;
});

const goPrevMonth = () => {
  viewDate.value = addMonths(viewDate.value, -1);
};

const goNextMonth = () => {
  viewDate.value = addMonths(viewDate.value, 1);
};

// 계좌 선택 관련
const selectedAccount = ref({
  bankName: "KB국민카드",
});

const isHistoryDropdownOpen = ref(false);

const accountAriaLabel = computed(() => {
  return `현재 선택된 계좌는 ${selectedAccount.value.bankName} ${selectedAccount.value.accountNumber}입니다. 다른 계좌를 선택하려면 클릭하세요`;
});

const handleHistoryDropdownClick = () => {
  isHistoryDropdownOpen.value = !isHistoryDropdownOpen.value;
  console.log("계좌 선택 드롭다운 클릭");
  // TODO: BottomSheet 또는 다른 방식으로 계좌 선택 UI 표시
};

// 조회조건 선택 필터 관련
const handleSortClick = () => {
  console.log("조회조건 선택 클릭");
  // TODO: BottomSheet 또는 다른 방식으로 조회조건 선택 UI 표시
};

// 결제 취소 처리
const handleCancelPayment = (item) => {
  console.log("결제 취소 클릭", item);
  // TODO: 결제 취소 로직 구현
};

const getDisplayDate = (date) => {
  // "1월 27일 수요일 오늘" -> "1.27일(수) 오늘" 형식으로 변환
  const match = date.match(/(\d+)월\s+(\d+)일\s+(\S+)(?:\s+오늘)?/);
  if (match) {
    const [, month, day, dayOfWeek] = match;
    const shortDayOfWeek = dayOfWeek.replace("요일", "");
    const hasToday = date.includes("오늘");
    return `${month}.${day}일(${shortDayOfWeek})${hasToday ? " 오늘" : ""}`;
  }
  return date;
};

const usageHistoryByDate = [
  {
    date: "1월 27일 수요일 오늘",
    items: [
      {
        label: "지에스(GS)25 씨티스퀘어점",
        number: "",
        dateTime: "15:00",
        paymentMethod: ["신한카드 본인 793*", "온라인 결제"],
        amount: "190,000원",
        canCancel: true,
      },
      {
        label: "지에스(GS)25 씨티스퀘어점",
        number: "",
        dateTime: "15:00",
        paymentMethod: ["신한카드 본인 793*", "터치 결제"],
        amount: "190,000원",
        canCancel: true,
      },
      {
        label: "지에스(GS)25 씨티스퀘어점",
        number: "",
        dateTime: "15:00",
        paymentMethod: ["신한카드 본인 793*", "바코드 결제"],
        amount: "190,000원",
        canCancel: true,
      },
      {
        label: "지에스(GS)25 씨티스퀘어점",
        number: "",
        dateTime: "15:00",
        paymentMethod: ["신한카드 본인 793*", "온라인 결제"],
        amount: "230,000원",
        canCancel: false,
      },
    ],
  },
  {
    date: "1월 25일 월요일",
    items: [
      {
        label: "지에스(GS)25 씨티스퀘어점",
        number: "",
        dateTime: "15:00",
        paymentMethod: ["신한카드 본인 793*", "온라인 결제"],
        amount: "230,000원",
        canCancel: false,
      },
      {
        label: "지에스(GS)25 씨티스퀘어점",
        number: "",
        dateTime: "15:00",
        paymentMethod: ["신한카드 본인 793*", "온라인 결제"],
        amount: "230,000원",
        canCancel: false,
      },
    ],
  },
];
</script>

<style lang="scss" scoped>
// 현재 컴포넌트에 제공된 부분에는 상단 년/월 만 선택하는 부분이 없어서 전체 하단 달력 부분 제공 부분까지 호출 후 해당 영역은 숨김
// 개발 방식에 따라 사용 유무 판단
.usage-history__header {
  :deep(.sv-datepicker) {
    .sv-datepicker__body,
    .sv-datepicker__options {
      display: none !important;
    }
  }
}
</style>
