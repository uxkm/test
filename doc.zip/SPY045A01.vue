<route lang="yaml">
meta:
  id: SPY045A01
  title: 오픈뱅킹 이용내역
  menu: "페이 > 페이:결제/뱅킹 Tab > 이용내: 오픈뱅킹 Tab"
  layout: SubLayout
  category: 페이
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  mainClassList: "pt-none"
  header:
    fixed: true
    back: true
    home: true
</route>
<template>
  <!-- 콘텐츠 영역 -->
  <div class="sc-contents__body usage-history open-banking">
    <!-- 
      입금인 경우 em class is-income 추가 색상 변경
      출금인 경우 em class is-expense 추가 색상 변경
    -->

    <!-- 월별 조회 필터 - SOLID에서 제공한 컴포넌트 형식에 따라 변경 가능성 있음 -->
    <div class="usage-history__header is-sticky">
      <DatePicker
        v-model:viewDate="viewDate"
        class="usage-history__datepicker"
      >
        <template #header>
          <IconButton
            class="sv-datepicker__header-btn sv-datepicker__header-btn--prev"
            size="large"
            :disabled="!canGoPrev"
            @click="goPrevMonth"
            :aria-label="prevMonthAriaLabel"
          >
            <template #icon>
              <Icon
                name="Chevron_left"
                :fixed-size="false"
                aria-hidden="true"
              />
            </template>
          </IconButton>
          <h2
            class="sv-datepicker__title"
            tabindex="0"
            :aria-label="currentMonthAriaLabel"
          >
            <span
              class="sv-datepicker__title-content"
              aria-hidden="true"
            >
              {{ title }}
            </span>
          </h2>
          <IconButton
            class="sv-datepicker__header-btn sv-datepicker__header-btn--next"
            size="large"
            :disabled="!canGoNext"
            @click="goNextMonth"
            :aria-label="nextMonthAriaLabel"
          >
            <template #icon>
              <Icon
                name="Chevron_right"
                :fixed-size="false"
                aria-hidden="true"
              />
            </template>
          </IconButton>
        </template>
      </DatePicker>
    </div>

    <!-- 계좌 선택 영역 -->
    <!-- 진입한 계좌 상세화면의 계좌가 Defualt로 노출 -->
    <InlineDropdown
      class="sc-card__dropdown usage-history__dropdown section"
      :ariaLabel="accountAriaLabel"
      :isOpen="isHistoryDropdownOpen"
      @click="handleHistoryDropdownClick"
    >
      <template #value>
        <span class="card-display">
          <span class="card-info">
            <span class="card-title">{{ selectedAccount.bankName }}</span>
            <span class="card-subtitle">{{ selectedAccount.accountNumber }}</span>
          </span>
        </span>
      </template>
    </InlineDropdown>

    <!-- 조회조건 선택 필터 -->
    <ListTitle
      title=""
      class="usage-history__filter section is-sticky"
    >
      <div class="flex items-center sort">
        <IconButton
          :color="false"
          :disabled="false"
          size="small"
          aria-label="조회조건 선택"
        >
          <template #icon>
            <Icon
              name="Sort"
              aria-hidden="true"
            />
          </template>
        </IconButton>
      </div>
    </ListTitle>

    <!-- 이용내역 리스트 -->
    <!-- 이용내역이 있을 때 -->
    <div
      class="section usage-history__body"
      v-if="usageHistoryByDate.length > 0"
    >
      <template
        v-for="(dateGroup, dateIndex) in usageHistoryByDate"
        :key="dateIndex"
      >
        <section class="usage-history__section">
          <h3
            class="usage-date__title"
            tabindex="0"
            :aria-label="dateGroup.date"
          >
            <span aria-hidden="true">{{ getDisplayDate(dateGroup.date) }}</span>
          </h3>
          <div class="usage-history__list">
            <BasicList
              v-for="(item, itemIndex) in dateGroup.items"
              :key="itemIndex"
              as="div"
              class="usage-history__item"
            >
              <ListItem align="centered">
                <template #leftMainText>
                  <strong class="usage-label">
                    <!-- 거래내역명 -->
                    {{ item.label }}
                  </strong>
                </template>
                <template #leftSubText>
                  <span class="usage-sub">
                    <!-- 시간 -->
                    <em class="usage-date">{{ item.dateTime }}</em>
                  </span>
                </template>
                <!-- 입금인 경우 is-income, 출금인 경우 is-expense class 추가 -->
                <template #rightMainText>
                  <strong
                    class="usage-amount"
                    :class="{
                      'is-income': item.type === '입금',
                      'is-expense': item.type === '출금',
                    }"
                    >{{ item.amount }}</strong
                  >
                </template>
                <template #rightSubText>
                  <span class="usage-status">
                    <em
                      :class="{
                        'is-income': item.type === '입금',
                        'is-expense': item.type === '출금',
                      }"
                      >{{ item.type }}</em
                    >
                  </span>
                </template>
              </ListItem>
            </BasicList>
          </div>
        </section>

        <Divider
          v-if="dateIndex < usageHistoryByDate.length - 1"
          variant="basic"
          color="secondary"
        />
      </template>
    </div>

    <!-- 이용내역이 없을 때 -->
    <template v-else>
      <NoData mainText="이용 내역이 없어요." />
    </template>
  </div>
</template>

<script setup>
import { ScIcon } from "@shc-nss/ui/shc";
import {
  BasicCard,
  BasicList,
  BoxButton,
  DatePicker,
  Divider,
  Icon,
  IconButton,
  InlineDropdown,
  ListItem,
  ListTitle,
  TextTabs,
} from "@shc-nss/ui/solid";
import { addMonths, format, isAfter, startOfMonth } from "date-fns";
import { ko } from "date-fns/locale";
import { computed, ref } from "vue";
import NoData from "../../_module/NoData.vue";

const viewDate = ref(new Date());
const today = new Date();

const title = computed(() => {
  return format(viewDate.value, "yyyy.MM");
});

const titleAriaLabel = computed(() => {
  return format(viewDate.value, "yyyy년 M월", { locale: ko });
});

const currentMonthAriaLabel = computed(() => {
  return `현재 ${titleAriaLabel.value} 이용내역`;
});

const canGoPrev = computed(() => {
  // 이전 달로 이동 가능 여부 (필요시 minDate 체크)
  return true;
});

const canGoNext = computed(() => {
  // 다음 달로 이동 가능 여부: 다음 달이 오늘 날짜보다 미래이면 disabled
  const nextMonth = startOfMonth(addMonths(viewDate.value, 1));
  const currentMonth = startOfMonth(today);
  // 다음 달이 현재 월보다 미래이면 false (이용내역 없음)
  return !isAfter(nextMonth, currentMonth);
});

const prevMonthAriaLabel = computed(() => {
  if (!canGoPrev.value) {
    return "이전 달 이용내역 없음";
  }
  const prevMonth = addMonths(viewDate.value, -1);
  const prevMonthLabel = format(prevMonth, "yyyy년 M월", { locale: ko });
  return `이전 달 ${prevMonthLabel} 이용내역`;
});

const nextMonthAriaLabel = computed(() => {
  if (!canGoNext.value) {
    return "다음 달 이용내역 없음";
  }
  const nextMonth = addMonths(viewDate.value, 1);
  const nextMonthLabel = format(nextMonth, "yyyy년 M월", { locale: ko });
  return `다음 달 ${nextMonthLabel} 이용내역`;
});

const goPrevMonth = () => {
  viewDate.value = addMonths(viewDate.value, -1);
};

const goNextMonth = () => {
  viewDate.value = addMonths(viewDate.value, 1);
};

// 계좌 선택 관련
const selectedAccount = ref({
  bankName: "신한은행",
  accountNumber: "110-241-2456",
});

const isHistoryDropdownOpen = ref(false);

const accountAriaLabel = computed(() => {
  return `현재 선택된 계좌는 ${selectedAccount.value.bankName} ${selectedAccount.value.accountNumber}입니다. 다른 계좌를 선택하려면 클릭하세요`;
});

const handleHistoryDropdownClick = () => {
  isHistoryDropdownOpen.value = !isHistoryDropdownOpen.value;
  console.log("계좌 선택 드롭다운 클릭");
  // TODO: BottomSheet 또는 다른 방식으로 계좌 선택 UI 표시
};

const getDisplayDate = (date) => {
  // "1월 27일 수요일 오늘" -> "1.27일(수) 오늘" 형식으로 변환
  const match = date.match(/(\d+)월\s+(\d+)일\s+(\S+)(?:\s+오늘)?/);
  if (match) {
    const [, month, day, dayOfWeek] = match;
    const shortDayOfWeek = dayOfWeek.replace("요일", "");
    const hasToday = date.includes("오늘");
    return `${month}.${day}일(${shortDayOfWeek})${hasToday ? " 오늘" : ""}`;
  }
  return date;
};

const usageHistoryByDate = [
  {
    date: "1월 27일 수요일 오늘",
    items: [
      {
        label: "김신한",
        dateTime: "15:00",
        type: "입금",
        amount: "+190,000원",
      },
      {
        label: "김신한",
        dateTime: "15:00",
        type: "입금",
        amount: "+10,000원",
      },
      {
        label: "김신한",
        dateTime: "15:00",
        type: "입금",
        amount: "+100,000원",
      },
    ],
  },
  {
    date: "1월 25일 월요일",
    items: [
      {
        label: "김신한",
        dateTime: "15:00",
        type: "출금",
        amount: "-100,000원",
      },
      {
        label: "김신한",
        dateTime: "15:00",
        type: "입금",
        amount: "+10,000원",
      },
      {
        label: "김신한",
        dateTime: "15:00",
        type: "출금",
        amount: "-3,000원",
      },
    ],
  },
];
</script>

<style lang="scss" scoped>
// 현재 컴포넌트에 제공된 부분에는 상단 년/월 만 선택하는 부분이 없어서 전체 하단 달력 부분 제공 부분까지 호출 후 해당 영역은 숨김
// 개발 방식에 따라 사용 유무 판단
.usage-history__header {
  :deep(.sv-datepicker) {
    .sv-datepicker__body,
    .sv-datepicker__options {
      display: none !important;
    }
  }
}
</style>
