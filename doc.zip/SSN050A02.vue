<route lang="yaml">
meta:
  id: SSN050A02
  title: 카드신청
  menu: Sign in/up > 가입하기 > 선불전자지급수단신청 > 처음선불카드 나만의 우주만들기
  layout: SubLayout
  category: Sign in/up
  publish: 김대민
  publishVersion: 0.8
  status: 재작업
  header:
    fixed: true
    close: true
    back: true
  etc: 251114 solid Carousel로 교체
</route>
<template>
  <div class="sc-body__title space">
    <div class="title-type">
      <h2
        class="title-main"
        aria-label="카드에 새겨질 나만의 우주를 골라주세요"
        tabindex="0"
      >
        <span aria-hidden="true">
          카드에 새겨질<br />
          <strong class="text-gradient">나만의 우주</strong>를 골라주세요
        </span>
      </h2>
    </div>
  </div>

  <!-- 콘텐츠 영역 -->
  <div class="sc-contents__body my-space-card">
    <SegmentTabs
      v-model="activeTab"
      class="space-card-tabs"
    >
      <Tab>날짜로 고르기</Tab>
      <Tab>
        <span class="popover-tab__text">사진으로 고르기</span>
        <div class="sc-popover__custom hide-close" data-placement="bottom-center">
          <div class="sc-popover__custom-content">
            <span>365개 우주를 한눈에!</span>
          </div>
        </div>
      </Tab>

      <TabPanel>
        <div class="space-card__contents">
          <!-- 입력전 -->
          <div
            v-show="!showResult"
            ref="spaceCardDefaultRef"
            class="space-card__default"
          >
            <div class="space-card__default-contents">
              <div class="space-card__title">
                <img
                  :src="`${$cdnURL}/images/pages/auth/text_space_card_title.png`"
                  alt="기념하고 싶은 날짜를 선택해보세요."
                />
              </div>
              <div class="space-card__tabs-input">
                <label class="space-card__input-label">
                  <input
                    ref="firstInputRef"
                    v-model="dateInputs[0]"
                    type="number"
                    placeholder="0"
                    class="space-card__input"
                    aria-label="기념일 첫번째 자리숫자 입력"
                    maxlength="1"
                  />
                </label>
                <label class="space-card__input-label">
                  <input
                    v-model="dateInputs[1]"
                    type="number"
                    placeholder="0"
                    class="space-card__input"
                    aria-label="기념일 두번째 자리숫자 입력"
                    maxlength="1"
                  />
                </label>
                <label class="space-card__input-label">
                  <input
                    v-model="dateInputs[2]"
                    type="number"
                    placeholder="0"
                    class="space-card__input"
                    aria-label="기념일 세번째 자리숫자 입력"
                    maxlength="1"
                  />
                </label>
                <label class="space-card__input-label">
                  <input
                    v-model="dateInputs[3]"
                    type="number"
                    placeholder="0"
                    class="space-card__input"
                    aria-label="기념일 네번째 자리숫자 입력"
                    maxlength="1"
                  />
                </label>
              </div>
              <div class="space-card__tabs-input-actions">
                <button
                  class="space-card__input-button"
                  :disabled="!isAllInputsFilled"
                  @click="handleShowResult"
                >
                  내 기념일 우주 확인하기
                </button>
              </div>
            </div>
          </div>

          <!-- 내 기념일 우주 확인하기 결과 -->
          <div
            ref="resultRef"
            v-show="showResult"
            class="space-card__result"
            tabindex="-1"
          >
            <figure class="space-card__result-figure">
              <div class="space-card__result-title">
                <span>On August 15</span>
                <strong>Supernova 1987A</strong>
              </div>
              <div class="space-card__result-image-container">
                <img
                  :src="`${$cdnURL}/images/pages/auth/space_card1.png`"
                  alt="ShinhanCard 처음, On September 15 Center of the Crab Nebula"
                  class="space-card__result-image"
                />
              </div>
              <figcaption class="space-card__result-caption">
                <p class="space-card__result-description">
                  이 이미지는 1987년에 천문학자들이 목격한 인근 은하의 별 폭발인 초신성 1987A의
                  잔해를 보여줍니다. 별 폭발로 방출된 물질의 충격파가 주변 가스 고리에 부딪혀 그것을
                  빛나게 하고 있습니다.
                </p>
              </figcaption>
            </figure>
            <div class="space-card__result-actions">
              <button
                class="space-card__result-button"
                @click="handleResetSearch"
              >
                <Icon
                  name="Arrow_refresh"
                  size="16"
                  aria-hidden="true"
                />
                다른 우주 찾기
              </button>
            </div>
          </div>
        </div>
      </TabPanel>
      <TabPanel>
        <!-- 
          스크롤시 고정인 경우 is-sticky class 추가 스크립트로 제어 스크롤시 생성되도록 함 
          처음부터 정적으로 들어가게 되면 다른 탭 클릭 후 아래에서 위로 올라오는 현상 발생.
          스크롤시 header 높이 만큼 위치 했을 때 발생되도록 처리
        -->
        <div
          ref="subtabsRef"
          class="space-card__subtabs"
          :class="{ 'is-sticky': isSubtabsSticky }"
          role="tablist"
          aria-label="월별 우주 카드 선택"
        >
          <button
            type="button"
            v-for="(month, index) in monthOptions"
            :key="index"
            class="space-card__tab"
            :class="{ 'is-active': selectedMonth === month.value }"
            role="tab"
            :aria-selected="selectedMonth === month.value"
            :aria-label="`${month.label} 선택`"
            @click="handleMonthSelect(month.value)"
          >
            <div class="space-card__tab-image">
              <img
                :src="`${$cdnURL}/images/pages/auth/space_planet${month.imageSuffix}.png`"
                :alt="month.label"
                aria-hidden="true"
              />
            </div>
            <div class="space-card__tab-label">{{ month.label }}</div>
          </button>
        </div>

        <ul class="space-card__list">
          <li
            v-for="card in filteredCards"
            :key="card.id"
            class="space-card__list-item"
          >
            <ListCard
              :ref="(el) => setCardRef(card.id, el)"
              variant="outline"
              as="button"
              :aria-label="`${card.subText} ${card.mainText} 카드 상세정보 보기`"
              @contentClick="handleCardClick(card.id)"
            >
              <ListItem
                :left="{
                  mainText: card.mainText,
                  subText: card.subText,
                  direction: 'column-reverse',
                }"
                aria-hidden="true"
              >
                <template #leftIcon>
                  <img
                    :src="`${$cdnURL}/images/pages/auth/space_card${card.imageIndex}.png`"
                    :alt="card.mainText"
                    aria-hidden="true"
                  />
                </template>
                <template #rightControl>
                  <Icon
                    name="Chevron_right"
                    :size="20"
                    aria-hidden="true"
                  />
                </template>
              </ListItem>
            </ListCard>
          </li>
        </ul>
      </TabPanel>
    </SegmentTabs>

    <div class="section mt-3xl">
      <Infobox
        color="info"
        class="infobox__header--none"
      >
        <UnorderedList>
          <UnorderedListItem
            variant="star"
            text="멀고도 작은 면적의 우주를 담고자 장기간 관측한 경우에는 서로 다른 날짜에 같은 디자인이 있을 수 있어요."
          />
          <UnorderedListItem
            variant="star"
            text="사진 인쇄형 카드로 허블 우주 망원경이 보내온 사진을 최대한 전달하고자 하여, 화질이 선명하지 않을 수 있어요."
          />
        </UnorderedList>
      </Infobox>
    </div>

    <section class="section mt-4xl">
      <h3 class="fs-title-l fw-title-l ls-title-l">신한카드 처음 ‘Anniverse’ 프로젝트는?</h3>
      <UnorderedList class="mt-lg">
        <UnorderedListItem
          text="Anniverse는 기념일을 뜻하는 Anniversary와 우주를 뜻하는 Universe를 합친 신한카드 처음의 첫번째 플레이트 디자인 프로젝트명으로, 허블 우주 망원경 30주년을기념하며 NASA가 진행한 “What did Hubble See on your birthday?” 캠페인에서 영감을 얻었어요."
        />
        <UnorderedListItem
          text="NASA는 위 캠페인을 통해 허블 우주 망원경이 내 생일에 촬영한 우주 이미지를 사람들에게 탐험할 수 있게 했어요."
        />
        <UnorderedListItem
          text="저희는 여러분이 기념일을 특별하게 기억하는 방법으로 허블 우주 망원경이 촬영한 우주 사진을 카드로 만들어 드리고 싶어졌고, NASA에 연락해 Anniverse 프로젝트를 위한 우주 사진 365장을 사용할 수 있게 되었어요."
        />
        <UnorderedListItem
          text="모두에게 처음이, 그리고 첫 날이 있듯, 그날 그 순간을 우주 사진으로 기억해 보세요."
        />
      </UnorderedList>
      <Divider
        variant="basic"
        color="secondary"
        orientation="horizontal"
        class="my-lg"
      />
      <UnorderedList>
        <UnorderedListItem
          variant="dash"
          text="[Credits]NASA, ESA, and the Hubble Heritage Team (STScI/AURA)"
        />
      </UnorderedList>
    </section>
  </div>

  <!-- 상세정보 bottom sheet -->
  <BottomSheet
    v-model="isDetailBottomSheetOpen"
    title="상세정보"
    class="space-card__details"
  >
    <figure class="space-card__details-figure">
      <div class="space-card__details-image-container">
        <img
          :src="`${$cdnURL}/images/pages/auth/space_card4.png`"
          alt="ShinhanCard 처음, On May 4 Cat's Eye Nebula"
          class="space-card__details-image"
        />
      </div>
      <div class="space-card__details-title">
        <span>On December 30</span>
        <strong>Supernova 1987A</strong>
      </div>
      <figcaption class="space-card__details-caption">
        <p class="space-card__details-description">
          이 이미지는 1987년에 천문학자들이 목격한 인근 은하의 별 폭발인 초신성 1987A의 잔해를
          보여줍니다. 별 폭발로 방출된 물질의 충격파가 주변 가스 고리에 부딪혀 그것을 빛나게 하고
          있습니다.허블 우주 망원경이 신비로운 화성 북반구의 봄을 포착했습니다. 화성 북극의 만년설은
          녹아내리면서, 단단한 물얼음의 중심까지 수백 킬로미터를 거쳐 점차 축소되었습니다. 아침의
          구름은 행성의 서쪽 가장자리(왼쪽)에서 부드럽게 펼쳐져, 화성의 대기와 기후 변화가 선사하는
          특별한 아름다움을 담고 있습니다. 화성의 봄은 지구와 유사하지만, 화성의 독특한 대기와 기후
          조건으로 그 변화의 강도가 높습니다.
        </p>
      </figcaption>
    </figure>
    <template #footer>
      <BoxButton
        text="이 카드로 신청하기"
        size="xlarge"
      />
    </template>
  </BottomSheet>

  <BottomActionContainer :scrollDim="true">
    <BoxButtonGroup size="xlarge">
      <BoxButton text="이 카드로 신청하기" />
    </BoxButtonGroup>
  </BottomActionContainer>
</template>

<script setup>
import { inject } from "vue";
import {
  ref,
  watch,
  nextTick,
  computed,
  onMounted,
  onUnmounted,
  defineModel,
  defineAsyncComponent,
} from "vue";
import { AppContextKey } from "@/configs/inject/appContext";
import {
  BottomActionContainer,
  BoxButton,
  BoxButtonGroup,
  Infobox,
  UnorderedList,
  UnorderedListItem,
  Divider,
  SegmentTabs,
  Tab,
  TabPanel,
  Icon,
  ListCard,
  ListItem,
  BottomSheet,
} from "@shc-nss/ui/solid";

const { $cdnURL } = inject(AppContextKey);

const activeTab = ref(0);

// 별 효과를 위한 DOM 참조
const spaceCardDefaultRef = ref(null);

// 첫 번째 입력 필드 ref
const firstInputRef = ref(null);

// subtabs ref
const subtabsRef = ref(null);

// subtabs sticky 상태
const isSubtabsSticky = ref(false);

// 결과 영역 ref
const resultRef = ref(null);

// 결과 표시 여부
const showResult = ref(false);

// 상세정보 BottomSheet 열림 상태
const isDetailBottomSheetOpen = defineModel({ default: false });

// 카드 ref 저장
const cardRefs = new Map();
// 클릭한 카드 ID 저장
const clickedCardId = ref(null);

// 선택된 월 (전체 = 'all', 1월~12월 = '1'~'12')
const selectedMonth = ref("all");

// 월별 옵션
const monthOptions = [
  { label: "전체", value: "all", imageSuffix: "_all" },
  { label: "1월", value: "1", imageSuffix: "-1" },
  { label: "2월", value: "2", imageSuffix: "-2" },
  { label: "3월", value: "3", imageSuffix: "-3" },
  { label: "4월", value: "4", imageSuffix: "-4" },
  { label: "5월", value: "5", imageSuffix: "-5" },
  { label: "6월", value: "6", imageSuffix: "-6" },
  { label: "7월", value: "7", imageSuffix: "-7" },
  { label: "8월", value: "8", imageSuffix: "-8" },
  { label: "9월", value: "9", imageSuffix: "-9" },
  { label: "10월", value: "10", imageSuffix: "-10" },
  { label: "11월", value: "11", imageSuffix: "-11" },
  { label: "12월", value: "12", imageSuffix: "-12" },
];

// 우주 카드 데이터 (space_card1~6 이미지 임시 사용 개발시 실제 카드 호출)
const spaceCards = [
  { id: 1, imageIndex: 1, mainText: "Jupiter", subText: "On January 1", month: "1" },
  { id: 2, imageIndex: 2, mainText: "Supernova 1987A", subText: "On February 15", month: "2" },
  { id: 3, imageIndex: 3, mainText: "Crab Nebula", subText: "On March 20", month: "3" },
  { id: 4, imageIndex: 4, mainText: "Orion Nebula", subText: "On April 10", month: "4" },
  { id: 5, imageIndex: 5, mainText: "Andromeda Galaxy", subText: "On May 5", month: "5" },
  { id: 6, imageIndex: 6, mainText: "Milky Way", subText: "On June 12", month: "6" },
  { id: 7, imageIndex: 1, mainText: "Saturn", subText: "On July 7", month: "7" },
  { id: 8, imageIndex: 2, mainText: "Pillars of Creation", subText: "On August 15", month: "8" },
  { id: 9, imageIndex: 3, mainText: "Helix Nebula", subText: "On September 9", month: "9" },
  { id: 10, imageIndex: 4, mainText: "Whirlpool Galaxy", subText: "On October 10", month: "10" },
  { id: 11, imageIndex: 5, mainText: "Eagle Nebula", subText: "On November 11", month: "11" },
  { id: 12, imageIndex: 6, mainText: "Mars", subText: "On December 12", month: "12" },
];

// 선택된 월에 따라 필터링된 카드 목록
const filteredCards = computed(() => {
  if (selectedMonth.value === "all") {
    return spaceCards;
  }
  return spaceCards.filter((card) => card.month === selectedMonth.value);
});

// 날짜 입력값 관리
const dateInputs = ref(["", "", "", ""]);

// 모든 input이 입력되었는지 확인
const isAllInputsFilled = computed(() => {
  return dateInputs.value.every((value) => value !== "" && value !== null && value !== undefined);
});

// 내 기념일 우주 확인하기 핸들러
const handleShowResult = () => {
  showResult.value = true;
  // 결과 영역으로 포커스 이동
  nextTick(() => {
    if (resultRef.value) {
      resultRef.value.focus();
    }
  });
};

// 다른 우주 찾기 핸들러
const handleResetSearch = () => {
  showResult.value = false;
  // 입력값 초기화
  dateInputs.value = ["", "", "", ""];
  // 첫 번째 입력 필드로 포커스 이동
  nextTick(() => {
    if (firstInputRef.value) {
      firstInputRef.value.focus();
    }
  });
};

// 월 선택 핸들러
const handleMonthSelect = (monthValue) => {
  selectedMonth.value = monthValue;
};

// 카드 ref 설정 함수
const setCardRef = (cardId, el) => {
  if (el) {
    cardRefs.set(cardId, el);
  }
};

// 카드 클릭 핸들러
const handleCardClick = (cardId) => {
  clickedCardId.value = cardId;
  isDetailBottomSheetOpen.value = true;
};

// BottomSheet가 닫힐 때 포커스 이동
watch(isDetailBottomSheetOpen, (newValue) => {
  if (!newValue && clickedCardId.value) {
    // BottomSheet가 닫힌 후 포커스 이동
    nextTick(() => {
      const cardRef = cardRefs.get(clickedCardId.value);
      if (cardRef?.$el) {
        const buttonElement = cardRef.$el.querySelector("button[aria-label]");
        if (buttonElement) {
          buttonElement.focus();
        }
      }
      clickedCardId.value = null;
    });
  }
});

// Tab이 변경될 때 처리
watch(
  activeTab,
  (newValue) => {
    // 스크롤 위치 재확인
    nextTick(() => {
      handleScroll();
    });

    // 첫 번째 탭으로 변경되면 sticky 상태 초기화
    if (newValue !== 1) {
      isSubtabsSticky.value = false;
    }
  },
  { immediate: true }
);

// 별 효과 생성 함수
const setStars = () => {
  if (!spaceCardDefaultRef.value) return;

  const numStars = 20;
  for (let i = 0; i < numStars; i++) {
    const star = document.createElement("span");
    // 위치
    star.className = "star";
    star.style.top = Math.random() * 100 + "%";
    star.style.left = Math.random() * 100 + "%";
    // 크기
    const size = Math.floor(Math.random() * 5 + 1);
    star.style.width = size + "px";
    star.style.height = size + "px";
    // 애니메이션 속성
    const delay = Math.floor(Math.random() * 8);
    const duration = Math.floor(Math.random() * 10 + 2);
    star.style.animationDelay = `${delay}s`;
    star.style.animationDuration = `${duration}s`;

    spaceCardDefaultRef.value.appendChild(star);
  }
};

// 스크롤 이벤트 핸들러
const handleScroll = () => {
  // 두 번째 탭(사진으로 고르기)일 때만 sticky 처리
  if (activeTab.value !== 1 || !subtabsRef.value) {
    isSubtabsSticky.value = false;
    return;
  }

  const headerHeight = 56; // --sc-header-height: 3.5rem = 56px
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  const subtabsRect = subtabsRef.value.getBoundingClientRect();

  // subtabs가 상단에서 헤더 높이만큼 위치했을 때 sticky 활성화
  isSubtabsSticky.value = subtabsRect.top <= headerHeight;
};

// 컴포넌트 마운트 시 별 효과 생성 및 스크롤 이벤트 등록
onMounted(() => {
  nextTick(() => {
    setStars();
    window.addEventListener("scroll", handleScroll);
    // 초기 스크롤 위치 확인
    handleScroll();
  });
});

// 컴포넌트 언마운트 시 스크롤 이벤트 제거
onUnmounted(() => {
  window.removeEventListener("scroll", handleScroll);
});
</script>

<style lang="scss" scoped></style>
