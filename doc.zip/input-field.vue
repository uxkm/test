<route lang="yaml">
meta:
  id: input-field
  title: Input field
  menu: Module > Input field Module
  layout: EmptyLayout
  category: Module
  publish: 김대민
  publishVersion: 0.8
  navbar: false
  etc: (공통팀)원정우
</route>

<template>
  <section class="section">
    <div class="demo-title">1. 인풋 안내 정보가 없는 기본형</div>
    <!-- S : 1. 인풋 안내 정보가 없는 기본형 -->
    <div class="sc-input__field">
      <div class="input-field__group not-counter">
        <div class="field-item">
          <!-- 주민등록번호 -->
          <InputField
            label="주민등록번호"
            :required="true"
            :input-items="rrnInputItems"
            v-model:values="rrnValues"
            :show-clear="false"
          />
        </div>

        <div class="field-item">
          <!-- 주민등록번호 Error 예시 -->
          <InputField
            label="주민등록번호"
            :required="true"
            :input-items="rrnInputItems"
            v-model:values="rrnErrorValues"
            :show-clear="false"
            :error="true"
            error-message="에러 메시지"
            :length="0"
          >
            <template
              v-for="(_, name) in $slots"
              #[name]="slotData"
            >
              <slot
                :name="name"
                v-bind="slotData"
              />
            </template>
          </InputField>
        </div>
      </div>

      <div class="input-field__group not-counter">
        <!-- 카드 비밀번호 -->
        <div class="field-item">
          <InputField
            label="카드 비밀번호"
            :required="true"
            :input-items="cardPinInputItems"
            v-model:values="cardPinValues"
            :show-clear="true"
          />
        </div>

        <!-- 카드 비밀번호 Error 예시 -->
        <div class="field-item">
          <InputField
            label="카드 비밀번호"
            :required="true"
            :input-items="cardPinInputItems"
            v-model:values="cardPinErrorValues"
            :show-clear="true"
            :error="true"
            error-message="비밀번호 4자리를 입력해주세요"
          />
        </div>
      </div>
    </div>
    <!-- E : 1. 인풋 안내 정보가 없는 기본형 -->

    <div class="demo-title">2. 인풋 안내 정보가 있는 형태</div>
    <!-- S : 2. 인풋 안내 정보가 있는 형태 -->
    <div class="sc-input__field">
      <!-- 사업자등록번호 그룹 -->
      <div class="input-field__group not-counter">
        <!-- 사업자등록번호 -->
        <div class="field-item">
          <InputField
            label="사업자등록번호"
            :required="true"
            :input-items="businessNumberInputItems"
            v-model:values="businessNumberValues"
            :show-clear="true"
          />
          <!-- field-info는 컴포넌트에 없는 유형으로 InputHelper 컴포넌트 보다 하단애 위치하는 구조 -->
          <p class="field-info">
            사업자등록번호는 필수 입력항목입니다. 신한카드 가맹점주가 아니면 사업자등록증 사본을
            제출해주세요.
          </p>
        </div>

        <!-- 사업자등록번호 Error 예시 -->
        <div class="field-item">
          <InputField
            label="사업자등록번호"
            :required="true"
            :input-items="businessNumberInputItems"
            v-model:values="businessNumberErrorValues"
            :show-clear="true"
            :error="true"
            error-message="에러메세지"
          />
          <!-- field-info는 컴포넌트에 없는 유형으로 InputHelper 컴포넌트 보다 하단애 위치하는 구조 -->
          <p class="field-info">
            사업자등록번호는 필수 입력항목입니다. 신한카드 가맹점주가 아니면 사업자등록증 사본을
            제출해주세요.
          </p>
        </div>
      </div>

      <!-- 노동조합지부 그룹 -->
      <div class="input-field__group not-counter">
        <!-- 노동조합지부 -->
        <div class="field-item">
          <InputField
            label="노동조합지부"
            :required="true"
            :input-items="unionBranchInputItems"
            v-model:values="unionBranchValues"
            :show-clear="true"
          />
          <!-- field-info는 컴포넌트에 없는 유형으로 InputHelper 컴포넌트 보다 하단애 위치하는 구조 -->
          <p class="field-info">
            지역 대표전화 뒤의 2자리 숫자를 입력해주세요. 예) 서울: 02, 경기: 31, 인천: 32, 세종: 44
            등
          </p>
        </div>

        <!-- 노동조합지부 Error 예시 -->
        <div class="field-item">
          <InputField
            label="노동조합지부"
            :required="true"
            :input-items="unionBranchInputItems"
            v-model:values="unionBranchErrorValues"
            :show-clear="true"
            :error="true"
            error-message="에러메세지"
          />
          <!-- field-info는 컴포넌트에 없는 유형으로 InputHelper 컴포넌트 보다 하단애 위치하는 구조 -->
          <p class="field-info">
            지역 대표전화 뒤의 2자리 숫자를 입력해주세요. 예) 서울: 02, 경기: 31, 인천: 32, 세종: 44
            등
          </p>
        </div>
      </div>

      <!-- 휴대폰번호 그룹 -->
      <div class="input-field__group not-counter">
        <!-- 휴대폰번호 -->
        <div class="field-item">
          <InputField
            label="휴대폰번호"
            :required="true"
            :input-items="phoneNumberInputItems"
            v-model:values="phoneNumberValues"
            :show-clear="true"
          />
          <!-- field-info는 컴포넌트에 없는 유형으로 InputHelper 컴포넌트 보다 하단애 위치하는 구조 -->
          <p class="field-info">
            휴대폰번호는 필수 입력항목입니다. 본인 명의의 휴대폰번호를 입력해주세요.
          </p>
        </div>

        <!-- 휴대폰번호 Error 예시 -->
        <div class="field-item">
          <InputField
            label="휴대폰번호"
            :required="true"
            :input-items="phoneNumberInputItems"
            v-model:values="phoneNumberErrorValues"
            :show-clear="true"
            :error="true"
            error-message="에러메세지"
          />
          <!-- field-info는 컴포넌트에 없는 유형으로 InputHelper 컴포넌트 보다 하단애 위치하는 구조 -->
          <p class="field-info">
            휴대폰번호는 필수 입력항목입니다. 본인 명의의 휴대폰번호를 입력해주세요.
          </p>
        </div>
      </div>

      <!-- 영문성명 그룹 -->
      <div class="input-field__group not-counter">
        <!-- 영문성명 -->
        <div class="field-item">
          <InputField
            label="영문성"
            :required="true"
            :input-items="englishNameInputItems"
            v-model:values="englishNameValues"
            :show-clear="true"
          />
          <!-- field-info는 컴포넌트에 없는 유형으로 InputHelper 컴포넌트 보다 하단애 위치하는 구조 -->
          <p class="field-info">입력안내 문구 제공은 Item/Footer의 컬러가 유지됩니다.</p>
        </div>

        <!-- 영문성명 Error 예시 -->
        <div class="field-item">
          <InputField
            label="영문성"
            :required="true"
            :input-items="englishNameInputItems"
            v-model:values="englishNameErrorValues"
            :show-clear="true"
            :error="true"
            error-message="에러메세지"
          />
          <!-- field-info는 컴포넌트에 없는 유형으로 InputHelper 컴포넌트 보다 하단애 위치하는 구조 -->
          <p class="field-info">입력안내 문구 제공은 Item/Footer의 컬러가 유지됩니다.</p>
        </div>
      </div>

      <!-- 주소 -->
      <div class="input-field__group not-counter">
        <div class="field-item">
          <InputFieldTwoLine
            v-model:values="inputValuesAddress"
            :inputItems="inputItemsAdress"
            label="주소"
            required
          />
          <UnorderedList class="field-info-list">
            <UnorderedListItem
              size="medium"
              variant="bullet"
            >
              집주소 외 다른 주소로는 배송 할 수 없어요.<br />예) 학교, 학원 등
            </UnorderedListItem>
          </UnorderedList>
        </div>
      </div>
    </div>
    <!-- E : 2. 인풋 안내 정보가 있는 형태 -->

    <div class="demo-title">3. 안내정보와 오류 메세지가 동일한 경우</div>
    <!-- S : 3. 안내정보와 오류 메세지가 동일한 경우 -->
    <div class="sc-input__field">
      <div class="input-field__group">
        <!-- 레이블 필드 -->
        <div class="field-item">
          <InputField
            label="레이블"
            :required="true"
            :input-items="textFieldInputItems"
            v-model:values="textFieldValues"
            :show-clear="true"
            description="10자 이내로 입력하세요"
          />
        </div>

        <!-- 레이블 필드 Error 예시 -->
        <div class="field-item">
          <InputField
            label="레이블"
            :required="true"
            :input-items="textFieldInputItems"
            v-model:values="textFieldErrorValues"
            :show-clear="true"
            :error="true"
            error-message="10자 이내로 입력하세요"
          />
        </div>
      </div>
    </div>
    <!-- E : 3. 안내정보와 오류 메세지가 동일한 경우 -->

    <div class="demo-title">4. 안내정보와 오류 메세지가 동일하고 안내 정보가 같이 제공되는경우</div>
    <!-- S : 4. 안내정보와 오류 메세지가 동일하고 안내 정보가 같이 제공되는경우 -->
    <div class="sc-input__field">
      <div class="input-field__group not-counter">
        <!-- 레이블 필드 -->
        <div class="field-item">
          <InputField
            label="레이블"
            :required="true"
            :input-items="textField2InputItems"
            v-model:values="textField2Values"
            :show-clear="true"
            description="입력한 번호는 고객님 정보로 등록돼요."
          />
          <!-- field-info는 컴포넌트에 없는 유형으로 InputHelper 컴포넌트 보다 하단애 위치하는 구조 -->
          <p class="field-info">입력안내 문구 제공은 Item/Footer의 컬러가 유지됩니다.</p>
        </div>

        <!-- 레이블 필드 Error 예시 -->
        <div class="field-item">
          <InputField
            label="레이블"
            :required="true"
            :input-items="textField2InputItems"
            v-model:values="textField2ErrorValues"
            :show-clear="true"
            :error="true"
            error-message="에러메세지"
          />
          <!-- field-info는 컴포넌트에 없는 유형으로 InputHelper 컴포넌트 보다 하단애 위치하는 구조 -->
          <p class="field-info">입력안내 문구 제공은 Item/Footer의 컬러가 유지됩니다.</p>
        </div>
      </div>
    </div>
    <!-- E : 4. 안내정보와 오류 메세지가 동일하고 안내 정보가 같이 제공되는경우 -->

    <div class="demo-title">5. 금액 단독입력 라인 인풋필드 (카드 특화)</div>
    <!-- S : 5. 금액 단독입력 라인 인풋필드 (카드 특화) -->
    <div class="sc-input__field">
      <div class="input-field__group not-counter">
        <!-- 금액 입력 필드 -->
        <div class="field-item amount-field">
          <InputField
            :required="true"
            :input-items="amountInputItems"
            v-model:values="amountValues"
            :show-clear="!!amountValues.amount"
            variant="underline"
            description="최소 10만원 / 최대 3,500만원"
          />

          <!-- 빠른 추가 버튼들 -->
          <BoxButtonGroup
            variant="30:30:30"
            size="small"
          >
            <BoxButton
              text="+10만"
              color="tertiary"
              size="medium"
              @click="addAmount(100000)"
            />
            <BoxButton
              text="+50만"
              color="tertiary"
              size="medium"
              @click="addAmount(500000)"
            />
            <BoxButton
              text="+100만"
              color="tertiary"
              size="medium"
              @click="addAmount(1000000)"
            />
            <BoxButton
              text="+1,000만"
              color="tertiary"
              size="medium"
              @click="addAmount(10000000)"
            />
          </BoxButtonGroup>
        </div>

        <!-- 금액 입력 필드 Error 예시 -->
        <div class="field-item amount-field">
          <InputField
            :required="true"
            :input-items="amountInputItems"
            v-model:values="amountErrorValues"
            :show-clear="!!amountErrorValues.amount"
            :error="true"
            error-message="최소 10만원 / 최대 3,500만원"
            variant="underline"
          />

          <!-- 빠른 추가 버튼들 -->
          <BoxButtonGroup
            variant="30:30:30"
            size="small"
          >
            <BoxButton
              text="+10만"
              color="tertiary"
              size="medium"
              @click="addAmount(100000)"
            />
            <BoxButton
              text="+50만"
              color="tertiary"
              size="medium"
              @click="addAmount(500000)"
            />
            <BoxButton
              text="+100만"
              color="tertiary"
              size="medium"
              @click="addAmount(1000000)"
            />
            <BoxButton
              text="+1,000만"
              color="tertiary"
              size="medium"
              @click="addAmount(10000000)"
            />
          </BoxButtonGroup>
        </div>

        <!-- 금액 입력 필드 Disabled 예시 -->
        <div class="field-item amount-field">
          <InputField
            :required="true"
            :input-items="amountInputItems"
            v-model:values="amountDisabledValues"
            :show-clear="false"
            :disabled="true"
            variant="underline"
            description="최소 10만원 / 최대 3,500만원"
          />

          <!-- 빠른 추가 버튼들 -->
          <BoxButtonGroup
            variant="30:30:30"
            size="small"
          >
            <BoxButton
              text="+10만"
              color="tertiary"
              size="medium"
              :disabled="true"
              @click="addAmountDisabled(100000)"
            />
            <BoxButton
              text="+50만"
              color="tertiary"
              size="medium"
              :disabled="true"
              @click="addAmountDisabled(500000)"
            />
            <BoxButton
              text="+100만"
              color="tertiary"
              size="medium"
              :disabled="true"
              @click="addAmountDisabled(1000000)"
            />
            <BoxButton
              text="+1,000만"
              color="tertiary"
              size="medium"
              :disabled="true"
              @click="addAmountDisabled(10000000)"
            />
          </BoxButtonGroup>
        </div>

        <!-- 금액 입력 필드 Readonly 예시 -->
        <div class="field-item amount-field">
          <InputField
            :required="true"
            :input-items="amountInputItems"
            v-model:values="amountReadonlyValues"
            :show-clear="false"
            :readOnly="true"
            variant="underline"
            description="최소 10만원 / 최대 3,500만원"
          />

          <!-- 빠른 추가 버튼들 -->
          <BoxButtonGroup
            variant="30:30:30"
            size="small"
          >
            <BoxButton
              text="+10만"
              color="tertiary"
              size="medium"
              :disabled="true"
              @click="addAmountReadonly(100000)"
            />
            <BoxButton
              text="+50만"
              color="tertiary"
              size="medium"
              :disabled="true"
              @click="addAmountReadonly(500000)"
            />
            <BoxButton
              text="+100만"
              color="tertiary"
              size="medium"
              :disabled="true"
              @click="addAmountReadonly(1000000)"
            />
            <BoxButton
              text="+1,000만"
              color="tertiary"
              size="medium"
              :disabled="true"
              @click="addAmountReadonly(10000000)"
            />
          </BoxButtonGroup>
        </div>
      </div>
    </div>

    <Divider style="margin: 20px 0" />
    <h4>[계좌 잔액 표기 있는 경우]</h4>
    <!-- E : 5. 금액 단독입력 라인 인풋필드 (카드 특화) -->
    <div class="sc-input__field">
      <div class="input-field__group not-counter">
        <!-- 금액 입력 필드 -->
        <div class="field-item amount-field">
          <FormField
            :required="true"
            variant="underline"
            :error="isError"
          >
            <TextInput
              :required="true"
              :input-items="amountInputItems"
              v-model:values="amountValues"
              :show-clear="!!amountValues.amount"
              aria-label="금액 입력"
              variant="underline"
            />
            <div class="amount-field__footer">
              <div class="amount-field__footer__row">
                <span class="amount-field__helper">1회 200만원 / 1일 1,000만원</span>
                <span class="amount-field__helper amount-field__helper--highlight">
                  계좌 잔액 : 계좌 잔액 : 400,000원
                </span>
              </div>

              <!-- error case -->
              <InputHelper error-message="최소 금액은 1원입니다." />
            </div>
          </FormField>

          <!-- 빠른 추가 버튼들 -->
          <BoxButtonGroup size="medium">
            <BoxButton
              text="5천원"
              color="tertiary"
              @click="addAmount(5000)"
            />
            <BoxButton
              text="1만원"
              color="tertiary"
              @click="addAmount(10000)"
            />
            <BoxButton
              text="5만원"
              color="tertiary"
              @click="addAmount(50000)"
            />
            <BoxButton
              text="10만원"
              color="tertiary"
              @click="addAmount(100000)"
            />
            <BoxButton
              text="전액"
              color="tertiary"
              @click="addAmount(400000)"
            />
          </BoxButtonGroup>
        </div>
      </div>
    </div>

    <div class="demo-title">6. 카드번호 입력 인풋</div>
    <!-- S : 6. 카드번호 입력 인풋 -->
    <div class="sc-input__field">
      <div class="input-field__group">
        <!-- 카드번호 입력 필드 (한줄 유형) -->
        <div class="field-item card-number-single-field">
          <InputField
            label="카드번호"
            :required="true"
            :input-items="cardNumberSingleInputItems"
            v-model:values="cardNumberSingleValues"
            variant="outline"
            align="start"
            :show-clear="false"
          />
        </div>

        <!-- 카드번호 입력 필드 (한줄 유형 - 에러 상태) -->
        <div class="field-item card-number-single-field">
          <InputField
            label="카드번호"
            :required="true"
            :input-items="cardNumberSingleInputItems"
            v-model:values="cardNumberSingleErrorValues"
            :error="true"
            variant="outline"
            align="start"
            :show-clear="false"
            error-message="안내메시지(문구는 추후 개발 전달 예정)"
          />
        </div>

        <!-- 카드번호 입력 필드 (한줄 유형 - 비활성화) -->
        <div class="field-item card-number-single-field">
          <InputField
            label="카드번호"
            :required="true"
            :input-items="cardNumberSingleInputItems"
            v-model:values="cardNumberSingleDisabledValues"
            :disabled="true"
            variant="outline"
            align="start"
            :show-clear="false"
          />
        </div>

        <!-- 카드번호 입력 필드 (한줄 유형 - 읽기전용) -->
        <div class="field-item card-number-single-field">
          <InputField
            label="카드번호"
            :required="true"
            tooltip="툴팁메시지"
            :input-items="cardNumberSingleInputItems"
            v-model:values="cardNumberSingleReadonlyValues"
            :readOnly="true"
            variant="outline"
            align="start"
            :show-clear="false"
          />
        </div>
      </div>
      <div class="input-field__group">
        <!-- 카드번호 입력 필드 -->
        <div class="field-item">
          <InputField
            label="레이블"
            :required="false"
            tooltip="툴팁메시지"
            :input-items="cardNumberInputItems"
            v-model:values="cardNumberValues"
            variant="outline"
            align="center"
            :show-clear="false"
            description="안내메시지"
          />
        </div>

        <!-- 카드번호 입력 필드 (에러 상태) -->
        <div class="field-item">
          <InputField
            label="레이블"
            :required="false"
            tooltip="툴팁메시지"
            :input-items="cardNumberInputItems"
            v-model:values="cardNumberErrorValues"
            :error="true"
            variant="outline"
            align="center"
            :show-clear="false"
            description="안내메시지"
            error-message="안내메시지(문구는 추후 개발 전달 예정)"
          />
        </div>

        <!-- 카드번호 입력 필드 (비활성화) -->
        <div class="field-item">
          <InputField
            label="레이블"
            :required="false"
            tooltip="툴팁메시지"
            :input-items="cardNumberInputItems"
            v-model:values="cardNumberDisabledValues"
            :disabled="true"
            variant="outline"
            align="center"
            :show-clear="false"
            description="안내메시지"
          />
        </div>

        <!-- 카드번호 입력 필드 (읽기전용) -->
        <div class="field-item">
          <InputField
            label="레이블"
            :required="false"
            tooltip="툴팁메시지"
            :input-items="cardNumberInputItems"
            v-model:values="cardNumberReadonlyValues"
            :readOnly="true"
            variant="outline"
            align="center"
            :show-clear="false"
            description="안내메시지"
          />
        </div>
      </div>
    </div>
    <!-- E : 6. 카드번호 입력 인풋 -->

    <div class="demo-title">7. 유효기간 입력 인풋</div>
    <!-- S : 7. 유효기간 입력 인풋 -->
    <div class="sc-input__field">
      <div class="input-field__group">
        <!-- 유효기간 입력 필드 -->
        <div class="field-item">
          <div class="expiry-date-inputs">
            <div class="date-field-wrapper">
              <InputFieldDualText
                description="안내메시지"
                :endIcon="endIcon"
                errorMessage=""
                :inputItems="inputDualItems"
                label="유효기간"
                :length="10"
                readOnly="false"
                separator=""
                showClear
                :startIcon="startIcon"
                tooltip=""
                variant="outline"
                required="false"
              />
            </div>
          </div>
        </div>

        <!-- 유효기간 입력 필드 Error 예시 -->
        <div class="field-item">
          <div class="expiry-date-inputs">
            <div class="date-field-wrapper">
              <InputFieldDualText
                description="안내메시지"
                :endIcon="endIcon"
                errorMessage="유효기간 형식이 바르지 않습니다."
                :inputItems="inputDualItems"
                label="유효기간"
                :length="10"
                :error="true"
                readOnly="false"
                separator=""
                showClear
                :startIcon="startIcon"
                tooltip=""
                variant="outline"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- E : 7. 유효기간 입력 인풋 -->

    <div class="demo-title">8. CVC 입력 인풋</div>
    <!-- S : 8. CVC 입력 인풋 -->
    <div class="sc-input__field">
      <div class="input-field__group">
        <!-- CVC 입력 필드 -->
        <div class="field-item">
          <div class="label-group">
            <label
              class="input-label"
              for="cvcField"
              >CVC번호</label
            >
            <IconButton
              size="small"
              iconName="Circle_info"
              aria-label="CVC번호 안내"
            />
          </div>
          <InputField
            :required="true"
            :input-items="cvcInputItems"
            v-model:values="cvcValues"
            variant="outline"
            align="start"
            :show-clear="false"
            aria-label="CVC번호"
          />
        </div>

        <!-- CVC 입력 필드 Error 예시 -->
        <div class="field-item">
          <div class="label-group">
            <label
              class="input-label"
              for="cvcFieldError"
              >CVC번호</label
            >
            <IconButton
              size="small"
              iconName="Circle_info"
              aria-label="CVC번호 안내"
            />
          </div>
          <InputField
            :required="true"
            :input-items="cvcInputItems"
            v-model:values="cvcErrorValues"
            variant="outline"
            align="start"
            :show-clear="false"
            :error="true"
            error-message="CVC번호를 정확히 입력해주세요"
            aria-label="CVC번호"
          />
        </div>
      </div>
    </div>
    <!-- E : 8. CVC 입력 인풋 -->

    <div class="demo-title">9. 카드 비밀번호 입력 인풋</div>
    <!-- S : 9. 카드 비밀번호 입력 인풋 -->
    <div class="sc-input__field">
      <div class="input-field__group">
        <!-- 카드 비밀번호 입력 필드 -->
        <div class="field-item">
          <InputField
            label="카드 비밀번호"
            :required="true"
            :input-items="cardPasswordInputItems"
            v-model:values="cardPasswordValues"
            variant="outline"
            align="start"
            :show-clear="false"
            aria-label="카드 비밀번호"
          />
        </div>

        <!-- 카드 비밀번호 입력 필드 Error 예시 -->
        <div class="field-item">
          <InputField
            label="카드 비밀번호"
            :required="true"
            :input-items="cardPasswordInputItems"
            v-model:values="cardPasswordErrorValues"
            variant="outline"
            align="start"
            :show-clear="false"
            :error="true"
            error-message="카드 비밀번호 4자리를 입력해주세요"
            aria-label="카드 비밀번호"
          />
        </div>
      </div>
    </div>
    <!-- E : 9. 카드 비밀번호 입력 인풋 -->

    <!-- S : 10. #button Slot -->
    <div class="demo-title">10. #button Slot</div>
    <div class="sc-input__field">
      <div class="input-field__group not-counter">
        <div class="field-item">
          <InputField
            id="inputSearch"
            name="inputSearch"
            v-model="inputValue"
            placeholder="도로명, 건물명, 지번검색"
          >
            <template #button>
              <IconButton
                iconName="Search"
                @click="handleClick"
              />
            </template>
          </InputField>
        </div>
      </div>
    </div>
    <!-- E : 10. #button Slot -->

    <div class="demo-title">11. 인풋 + 드롭다운(통신사 선택)</div>
    <!-- S : 11. 인풋 + 드롭다운 -->

    <div class="sc-input__field">
      <div class="input-field__group">
        <div class="field-item phone-number-single-field">
          <div class="phone-number-input-wrapper">
            <InputField
              label="휴대폰번호"
              :required="true"
              :input-items="phoneNumberInputItems2"
              v-model:values="phoneNumberValues"
              :show-clear="true"
            >
              <template #startDropbox>
                <TextDropdown
                  label="통신사선택"
                  size="small"
                  class="phone__drop"
                  :value="selectedValue"
                  v-bind="dropdownProps"
                  @click="openBottomSheet"
                />
              </template>
            </InputField>
          </div>
        </div>
      </div>
    </div>

    <!-- BottomSheet -->
    <BottomSheet
      title="통신사를 선택해주세요."
      v-model="isOpen"
      class="body-full"
    >
      <div class="sc-select__list">
        <div class="select-list__group select-list__image isCheck">
          <ul>
            <li
              v-for="(item, idx) in phoneCompany"
              :key="item.value"
              @click="selectOption(item.label, idx)"
            >
              <p>{{ item.label }}</p>
              <Icon
                name="CheckMark_checked"
                :size="24"
                aria-hidden="true"
                v-if="selectedIndex === idx"
              />
            </li>
          </ul>
        </div>
      </div>
    </BottomSheet>

    <div class="demo-title">12. 자동차운전면허번호</div>
    <div class="sc-input__field">
      <div class="input-field__group">
        <div class="field-item drivers-license-number-field">
          <InputField
            label="자동차운전면허번호"
            :required="true"
            :inputItems="driverInputItems"
          />
        </div>
      </div>
    </div>

    <div class="demo-title">13. 인증번호 입력</div>
    <FormField
      :required="true"
      variant="outline"
      :error="isError"
    >
      <TextInput
        variant="outline"
        :input-items="[
          {
            id: 'certcode',
            name: 'certcode',
            type: 'text',
            placeholder: '인증번호 입력',
            label: '인증번호',
          },
        ]"
        :error="isError"
        errorMessage="인증번호가 일치하지 않습니다."
      >
        <template #endAdornment="{ focused, disabled, error }">
          <TextTimer
            :initial-time="180"
            :status="timerStatus"
            :focused="focused"
            :disabled="disabled"
            :error="error"
            @status-change="handleTimerStatusChange"
          />
        </template>

        <template #button="{ values, focused, hasValue }">
          <BoxButton
            color="quaternary"
            size="small"
            text="재요청"
            @click="startVerification"
          />
        </template>
      </TextInput>
      <!-- case: 인증번호 불일치 -->
      <InputHelper errorMessage="인증번호가 일치하지 않습니다." />
      <!-- case: 인증번호 입력시간 만료 -->
      <InputHelper errorMessage="입력 시간이 지났습니다. 인증번호 재요청 후 다시 입력해주세요." />
    </FormField>

    <div class="demo-title">14. 각각 별도의 인풋필드 4개 유형(SOLID에서 제공된 유형 아님 개발 기준에 맞춰서 조함)</div>
    <!-- [251117] 개발 요청 사항 : 인풋필드 각각 4개가 나오는 UI 필요하여 각 입력 필드 각각 처리 -->

    <div class="sc-input__field">
      <div class="input-field__group">
        <div
          class="field-item__rowgroup"
          :class="{ 'is-error': !cardNumberError }"
        >
          <div class="rowgroup-inner">
            <div class="field-item">
              <InputField
                label="카드번호"
                :required="true"
                :input-items="separateField1InputItems"
                v-model:values="separateField1Values"
                variant="outline"
                align="center"
                :show-clear="false"
                :error="cardNumberError"
                aria-label="카드번호 첫 번째 자리"
              />
            </div>
            <div class="field-item field-item__masked">
              <InputField
                label=""
                :required="true"
                :input-items="separateField2InputItems"
                v-model:values="separateField2Values"
                variant="outline"
                align="center"
                :show-clear="false"
                aria-label="카드번호 두 번째 자리"
              />
            </div>
            <div class="field-item field-item__masked">
              <InputField
                label=""
                :required="true"
                :input-items="separateField3InputItems"
                v-model:values="separateField3Values"
                variant="outline"
                align="center"
                :show-clear="false"
                aria-label="카드번호 세 번째 자리"
              />
            </div>
            <div class="field-item">
              <InputField
                label=""
                :required="true"
                :input-items="separateField4InputItems"
                v-model:values="separateField4Values"
                variant="outline"
                align="center"
                :show-clear="false"
                aria-label="카드번호 네 번째 자리"
              />
            </div>
          </div>
          <!-- 오류일때 나오는 영역 -->
          <!-- <div class="field-item-error">
            <p class="field-error-message">
              <Icon
                name="Solid_circle_alert"
                size="14"
                class="field-error-message__icon"
              />
              카드번호를 입력해주세요
            </p>
          </div> -->
        </div>
      </div>
    </div>


    <div class="sc-input__field">
      <div class="input-field__group">
        <!-- 에러시 is-error 클래스 추가 -->
        <div
          class="field-item__rowgroup"
          :class="{ 'is-error': cardNumberError }"
        >
          <div class="rowgroup-inner">
            <div class="field-item">
              <InputField
                label="카드번호"
                :required="true"
                :input-items="separateField1InputItems"
                v-model:values="separateField1Values"
                variant="outline"
                align="center"
                :show-clear="false"
                :error="cardNumberError"
                aria-label="카드번호 첫 번째 자리"
              />
            </div>
            <div class="field-item field-item__masked">
              <InputField
                label=""
                :required="true"
                :input-items="separateField2InputItems"
                v-model:values="separateField2Values"
                variant="outline"
                align="center"
                :show-clear="false"
                aria-label="카드번호 두 번째 자리"
              />
            </div>
            <div class="field-item field-item__masked">
              <InputField
                label=""
                :required="true"
                :input-items="separateField3InputItems"
                v-model:values="separateField3Values"
                variant="outline"
                align="center"
                :show-clear="false"
                aria-label="카드번호 세 번째 자리"
              />
            </div>
            <div class="field-item">
              <InputField
                label=""
                :required="true"
                :input-items="separateField4InputItems"
                v-model:values="separateField4Values"
                variant="outline"
                align="center"
                :show-clear="false"
                aria-label="카드번호 네 번째 자리"
              />
            </div>
          </div>
          <!-- 오류일때 나오는 영역 -->
          <div class="field-item-error">
            <p class="field-error-message">
              <Icon
                name="Solid_circle_alert"
                size="14"
                class="field-error-message__icon"
              />
              카드번호를 입력해주세요
            </p>
          </div>
        </div>
      </div>
    </div>
    <!-- E : 14. 각각 별도의 인풋필드 4개 유형 -->
  </section>
</template>

<script setup>
import {
  BottomSheet,
  BoxButton,
  BoxButtonGroup,
  customTokens,
  Divider,
  FormField,
  Icon,
  IconButton,
  InputField,
  InputFieldDualText,
  InputFieldTwoLine,
  InputHelper,
  TextDropdown,
  TextInput,
  TextTimer,
  UnorderedList,
  UnorderedListItem,
} from "@shc-nss/ui/solid";
import { ref } from "vue";

// 주민등록번호 듀얼 입력 (앞자리 + 뒷자리)
const rrnValues = ref({});
const rrnErrorValues = ref({});
const rrnInputItems = [
  {
    id: "rrn1",
    name: "rrn1",
    type: "tel",
    placeholder: "생년월일 6자리",
    mask: "######",
    length: 6,
    inputmode: "numeric",
  },
  {
    id: "rrn2",
    name: "rrn2",
    type: "tel",
    placeholder: "뒷자리 첫번째 숫자 입력",
    length: 1,
    inputmode: "numeric",
    mask: {
      mask: "nMMMMMM",
      overwrite: true,
      definitions: {
        n: { mask: "#", placeholderChar: "○" },
        m: { mask: "#", displayChar: "●", placeholderChar: "○" },
        M: { mask: "#", displayChar: "●", placeholderChar: "●" },
      },
      clearIncomplete: false,
      skipInvalid: true,
      lazy: false,
      eager: true,
    },
  },
];

// 숫자 입력 필드들 - inputItems 방식으로 변경
const cardPinValues = ref({});
const cardPinErrorValues = ref({});
const cardPinInputItems = [
  {
    id: "cardPin",
    name: "cardPin",
    type: "tel",
    label: "카드 비밀번호",
    placeholder: "카드 비밀번호 입력",
    length: 4,
    mask: {
      mask: "####",
      overwrite: false,
      definitions: {
        "#": { mask: "#", displayChar: "●" },
      },
    },
  },
];

const businessNumberValues = ref({});
const businessNumberErrorValues = ref({});
const businessNumberInputItems = [
  {
    id: "businessNumber",
    name: "businessNumber",
    type: "tel",
    label: "사업자등록번호",
    placeholder: "사업자등록번호 입력",
    length: 10,
  },
];

const phoneNumberValues = ref({});
const phoneNumberErrorValues = ref({});
const phoneNumberInputItems = [
  {
    id: "phoneNumber",
    name: "phoneNumber",
    type: "tel",
    label: "휴대폰번호",
    placeholder: "휴대폰번호 입력",
    length: 11,
    mask: {
      mask: "###-####-####",
      overwrite: false,
    },
  },
];

// 텍스트 입력 필드들 - inputItems 방식으로 변경
const unionBranchValues = ref({});
const unionBranchErrorValues = ref({});
const unionBranchInputItems = [
  {
    id: "unionBranch",
    name: "unionBranch",
    label: "노동조합지부",
    placeholder: "사업자등록번호 입력",
    length: 20,
    inputmode: "text",
  },
];

const englishNameValues = ref({});
const englishNameErrorValues = ref({});
const englishNameInputItems = [
  {
    id: "englishName",
    name: "englishName",
    label: "영문성명",
    placeholder: "영문이름",
    length: 50,
    inputmode: "latin",
    lang: "en-US",
  },
];

const textFieldValues = ref({});
const textFieldErrorValues = ref({});
const textFieldInputItems = [
  {
    id: "textField",
    name: "textField",
    label: "레이블",
    placeholder: "플레이스홀더",
    length: 10,
    inputmode: "text",
    lang: "ko",
  },
];

const textField2Values = ref({});
const textField2ErrorValues = ref({});
const textField2InputItems = [
  {
    id: "textField2",
    name: "textField2",
    label: "레이블",
    placeholder: "플레이스홀더",
    length: 10,
    inputmode: "text",
    lang: "ko",
  },
];

// 금액 입력 필드들 - 카드 특화
const amountValues = ref({});
const amountErrorValues = ref({});
const amountDisabledValues = ref({});
const amountReadonlyValues = ref({ amount: "3,500만원" });
const amountInputItems = [
  {
    id: "amount",
    name: "amount",
    type: "tel",
    label: "금액",
    placeholder: "1만원 단위로 입력",
    length: 15,
    inputmode: "numeric",
  },
];
const addAmount = (value) => {
  console.log("value : " + value);
};

// 카드번호 입력 필드들 (한줄 유형)
const cardNumberSingleValues = ref({});
const cardNumberSingleErrorValues = ref({});
const cardNumberSingleDisabledValues = ref({});
const cardNumberSingleReadonlyValues = ref({
  cardNumber: "1234-5678-●●●●-123●",
});

// 카드번호 마스킹 함수
const maskCardNumber = (value) => {
  if (!value) return "";

  // 숫자만 추출
  const numbers = value.replace(/\D/g, "");

  // 8자리까지는 그대로 표시
  if (numbers.length <= 8) {
    return numbers.replace(/(.{4})/g, "$1-").replace(/-$/, "");
  }

  // 8자리 이후는 ●로 마스킹
  const visiblePart = numbers.substring(0, 8);
  const maskedPart = "●".repeat(Math.min(numbers.length - 8, 8));

  // 하이픈 추가
  const result = visiblePart + maskedPart;
  return result.replace(/(.{4})/g, "$1-").replace(/-$/, "");
};

// 카드번호 입력 시 마스킹 처리
const handleCardNumberInput = (event, values) => {
  const input = event.target;
  const value = input.value;
  const masked = maskCardNumber(value);

  if (masked !== value) {
    input.value = masked;
    values.cardNumber = masked;
  }
};

const cardNumberSingleInputItems = [
  {
    id: "cardNumber",
    name: "cardNumber",
    type: "text",
    placeholder: "(-) 없이 숫자만 입력",
    inputmode: "numeric",
  },
];

// 카드번호 입력 필드들 (4개 분할 유형)
const cardNumberValues = ref({});
const cardNumberErrorValues = ref({});
const cardNumberError = ref(true); // 에러 상태 예시 (UI 확인용)
const cardNumberDisabledValues = ref({});
const cardNumberReadonlyValues = ref({
  cardNumber1: "1234",
  cardNumber2: "5678",
  cardNumber3: "●●●●",
  cardNumber4: "●●●●",
});
const cardNumberInputItems = [
  {
    id: "cardNumber1",
    name: "cardNumber1",
    type: "tel",
    placeholder: "1234",
    inputmode: "numeric",
    mask: {
      mask: "####",
      definitions: {
        "#": { mask: "#", placeholderChar: "" },
      },
    },
  },
  {
    id: "cardNumber2",
    name: "cardNumber2",
    type: "tel",
    placeholder: "5678",
    inputmode: "numeric",
    mask: {
      mask: "####",
      definitions: {
        "#": { mask: "#", placeholderChar: "" },
      },
    },
  },
  {
    id: "cardNumber3",
    name: "cardNumber3",
    type: "text",
    placeholder: "●●●●",
    inputmode: "numeric",
  },
  {
    id: "cardNumber4",
    name: "cardNumber4",
    type: "text",
    placeholder: "●●●●",
    inputmode: "numeric",
  },
];

// 7번 유형: 유효기간 입력 필드들
const monthValues = ref({});
const yearValues = ref({});
const monthErrorValues = ref({});
const yearErrorValues = ref({});

const monthInputItems = [
  {
    id: "monthField",
    name: "monthField",
    type: "text",
    placeholder: "MM",
    inputmode: "numeric",
    "aria-label": "유효기간 월",
    label: "유효기간 월",
    mask: {
      mask: "##",
      definitions: {
        "#": { mask: "#", placeholderChar: "○" },
      },
    },
  },
];

const yearInputItems = [
  {
    id: "yearField",
    name: "yearField",
    type: "text",
    placeholder: "YY",
    inputmode: "numeric",
    "aria-label": "유효기간 년",
    label: "유효기간 년",
    mask: {
      mask: "##",
      definitions: {
        "#": { mask: "#", placeholderChar: "○" },
      },
    },
  },
];

const startIcon = { iconName: "heart", ariaLabel: "테스트레이블하트" };
const endIcon = { iconName: "Trash" };
const inputDualItems = [
  {
    id: "first",
    name: "first",
    label: "MM",
    placeholder: "MM",
    length: 2,
    startText: "텍1",
  },
  {
    id: "second",
    name: "second",
    label: "YY",
    placeholder: "YY",
    length: 2,
  },
];

// 8번 유형: CVC 입력 필드들
const cvcValues = ref({});
const cvcErrorValues = ref({});

const cvcInputItems = [
  {
    id: "cvcField",
    name: "cvcField",
    type: "text",
    placeholder: "●●●",
    inputmode: "numeric",
    "aria-label": "CVC번호",
    label: "CVC번호",
    mask: {
      mask: "mmm",
      definitions: {
        m: { mask: "#", displayChar: "●", placeholderChar: "○" },
      },
    },
  },
];

// 9번 유형: 카드 비밀번호 입력 필드들
const cardPasswordValues = ref({});
const cardPasswordErrorValues = ref({});

const cardPasswordInputItems = [
  {
    id: "cardPassword",
    name: "cardPassword",
    type: "text",
    placeholder: "●●●●",
    inputmode: "numeric",
    "aria-label": "카드 비밀번호",
    label: "카드 비밀번호",
    mask: {
      mask: "mmmm",
      definitions: {
        m: { mask: "#", displayChar: "●", placeholderChar: "○" },
      },
    },
  },
];

// 휴대폰번호
// BottomSheet 오픈
const isOpen = ref(false);
const openBottomSheet = () => {
  isOpen.value = true;
};
const selectedValue = ref("");
const selectedIndex = ref(null);
const selectOption = (value, idx) => {
  console.log("클릭");
  selectedValue.value = value;
  isOpen.value = false;
  selectedIndex.value = idx;
};

// listItem
const phoneCompany = [
  {
    label: "SKT",
    value: "SKT",
  },
  {
    label: "KT",
    value: "KT",
  },
  {
    label: "LG U+",
    value: "LG U+",
  },
  {
    label: "SKT 알뜰폰",
    value: "SKT 알뜰폰",
  },
  {
    label: "KT 알뜰폰",
    value: "KT 알뜰폰",
  },
  {
    label: "LG U+ 알뜰폰",
    value: "LG U+ 알뜰폰",
  },
];

const phoneNumberInputItems2 = [
  {
    id: "phoneNumber2",
    name: "phoneNumber2",
    type: "tel",
    label: "휴대폰번호",
    length: 11,
    mask: {
      mask: "010-1234-5678",
      overwrite: false,
    },
  },
];

// 자동차운전면허번호 입력
const driverInputItems = [
  {
    id: "first",
    name: "first",
    label: "첫번째",
    placeholder: "플레홀1",
    length: 2,
    mask: {
      mask: "mm",
      overwrite: true,
      definitions: customTokens,
    },
  },
  {
    id: "second",
    name: "second",
    label: "두번째",
    placeholder: "플레홀2",
    length: 6,
    mask: {
      mask: "mmmmmm",
      overwrite: true,
      definitions: customTokens,
    },
  },
  {
    id: "third",
    name: "third",
    label: "세번째",
    placeholder: "플레홀3",
    length: 2,
    mask: {
      mask: "mm",
      overwrite: true,
      definitions: customTokens,
    },
  },
];

// 13. 인증번호 입력

const isError = ref(false);
const timerStatus = ref("running");
const handleTimerStatusChange = (status) => {
  timerStatus.value = status;
  console.log("타이머 상태 업데이트:", status);
};
const startVerification = () => {
  timerStatus.value = "running";
};

isError.value = true; // error case (ui 확인용 / @개발시 삭제)
// timerStatus.value = "success"; // error case (ui 확인용 / @개발시 삭제)

// 주소
const inputValuesAddress = ref({});
const inputItemsAdress = [
  {
    id: "addr__line1",
    name: "addr__line1",
    label: "도로명, 건물명, 지번검색",
    placeholder: "도로명, 건물명, 지번검색",
  },
  {
    id: "addr__line2",
    name: "addr__line2",
    label: "상세주소",
    placeholder: "상세주소",
  },
];

// 별도 InputField 4개 (카드번호 마스킹 예제)
const separateField1Values = ref({});
const separateField1InputItems = [
  {
    id: "cardNumber1",
    name: "cardNumber1",
    type: "tel",
    placeholder: "○○○○",
    inputmode: "numeric",
    mask: {
      mask: "nnnn",
      definitions: {
        n: { mask: "#", placeholderChar: "○" },
      },
      overwrite: false,
    },
    length: 4,
  },
];

const separateField2Values = ref({});
const separateField2InputItems = [
  {
    id: "cardNumber2",
    name: "cardNumber2",
    type: "tel",
    placeholder: "○○○○",
    inputmode: "numeric",
    mask: {
      mask: "mmmm",
      definitions: {
        m: { mask: "#", displayChar: "●", placeholderChar: "○" },
      },
      overwrite: false,
    },
    length: 4,
  },
];

const separateField3Values = ref({});
const separateField3InputItems = [
  {
    id: "cardNumber3",
    name: "cardNumber3",
    type: "tel",
    placeholder: "○○○○",
    inputmode: "numeric",
    mask: {
      mask: "mmmm",
      definitions: {
        m: { mask: "#", displayChar: "●", placeholderChar: "○" },
      },
      overwrite: false,
    },
    length: 4,
  },
];

const separateField4Values = ref({});
const separateField4InputItems = [
  {
    id: "cardNumber4",
    name: "cardNumber4",
    type: "tel",
    placeholder: "○○○○",
    inputmode: "numeric",
    mask: {
      mask: "nnnn",
      definitions: {
        n: { mask: "#", placeholderChar: "○" },
      },
      overwrite: false,
    },
    length: 4,
  },
];
</script>

<style lang="scss" scoped>
// @use "@assets/styles/module/_input-field" as *; // Input field 모듈
</style>
