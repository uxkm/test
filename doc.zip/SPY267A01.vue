<route lang="yaml">
meta:
  id: SPY267A01
  title: 신한Pay머니 이용내역
  menu: "페이 > 페이:결제/뱅킹 Tab > 신한Pay머니 이용내역"
  layout: SubLayout
  category: 페이
  publish: 김대민
  publishVersion: 0.8
  status: 작업완료
  mainClassList: "pt-none"
  header:
    fixed: true
    back: true
    home: true
</route>
<template>
  <!-- 콘텐츠 영역 -->
  <div class="sc-contents__body usage-history">
    <!-- 
      거절인경우 em class 추가 is-reject 색상 변경
      # 이용내역 case 보내기 #
      송금보내기 완료(계좌)
      송금보내기 완료(연락처)
      송금 보내기 후 대기 시 (연락처)
      송금 보내기 거절됨 (연락처)
      송금 보내기 기간만료 (연락처)

      # 이용내역 case 받기 #
      송금 받기 완료(계좌)
      송금 받기 완료(연락처)
      송금 받기 거절됨 (연락처)
      송금 받기 기간만료 (연락처)

      # 대기 목록에 노출 #
      송금 받기 대기 (연락처)
      송금 수락 대기 (연락처)
    -->

    <!-- 대기목록 리스트 - 대기목록이 있는 경우 -->
    <div
      v-if="pendingList && pendingList.length > 0"
      class="usage-history__pending"
    >
      <h2 class="usage-history__pending-title">
        <span class="intitle">
          <ScIcon
            iconName="icon-error"
            size="20"
            aria-hidden="true"
          />
          대기 목록 <em>{{ pendingList.length }}건</em>
        </span>
      </h2>
      <div class="usage-history__pending-list">
        <BasicCard
          v-for="(item, itemIndex) in pendingList"
          :key="itemIndex"
          variant="outline"
          class="usage-history__pending-item"
        >
          <ListItem align="centered">
            <template #leftMainText>
              <strong class="usage-label">
                <!-- 거래내역명 -->
                {{ item.label }}
                <!-- 계좌번호 끝 4자리 -->
                {{ item.number }}
              </strong>
            </template>
            <template #leftSubText>
              <span class="usage-sub">
                <em class="usage-date">{{ item.dateTime }}</em>
                <em
                  v-for="(method, methodIndex) in item.paymentMethod"
                  :key="methodIndex"
                >
                  {{ method }}
                </em>
              </span>
            </template>
            <template #rightMainText>
              <strong class="usage-amount">{{ item.amount }}</strong>
            </template>
            <template #rightSubText>
              <span class="usage-status">
                <em :class="{ 'is-reject': item.isReject, 'is-expired': item.isExpired }">{{
                  item.status
                }}</em>
              </span>
            </template>
          </ListItem>
          <template #actions>
            <div class="usage-history__pending-actions text-right">
              <BoxButton
                v-for="(button, buttonIndex) in item.buttons"
                :key="buttonIndex"
                :text="button.text"
                :color="button.color"
                :size="button.size"
                :class="button.class"
              />
            </div>
          </template>
        </BasicCard>
      </div>
    </div>

    <!-- 월별 조회 필터 - SOLID에서 제공한 컴포넌트 형식에 따라 변경 가능성 있음 -->
    <div class="usage-history__header is-sticky">
      <DatePicker
        v-model:viewDate="viewDate"
        class="usage-history__datepicker"
      >
        <template #header>
          <IconButton
            class="sv-datepicker__header-btn sv-datepicker__header-btn--prev"
            size="large"
            :disabled="!canGoPrev"
            @click="goPrevMonth"
            :aria-label="prevMonthAriaLabel"
          >
            <template #icon>
              <Icon
                name="Chevron_left"
                :fixed-size="false"
                aria-hidden="true"
              />
            </template>
          </IconButton>
          <h2
            class="sv-datepicker__title"
            tabindex="0"
            :aria-label="currentMonthAriaLabel"
          >
            <span
              class="sv-datepicker__title-content"
              aria-hidden="true"
            >
              {{ title }}
            </span>
          </h2>
          <IconButton
            class="sv-datepicker__header-btn sv-datepicker__header-btn--next"
            size="large"
            :disabled="!canGoNext"
            @click="goNextMonth"
            :aria-label="nextMonthAriaLabel"
          >
            <template #icon>
              <Icon
                name="Chevron_right"
                :fixed-size="false"
                aria-hidden="true"
              />
            </template>
          </IconButton>
        </template>
      </DatePicker>
    </div>

    <!-- 이용내역 리스트 -->
    <!-- 이용내역이 있을 때 -->
    <div
      class="section usage-history__body"
      v-if="usageHistoryByDate.length > 0"
    >
      <template
        v-for="(dateGroup, dateIndex) in usageHistoryByDate"
        :key="dateIndex"
      >
        <section class="usage-history__section">
          <h3
            class="usage-date__title"
            tabindex="0"
            :aria-label="dateGroup.date"
          >
            <span aria-hidden="true">{{ getDisplayDate(dateGroup.date) }}</span>
          </h3>
          <div class="usage-history__list">
            <BasicList
              v-for="(item, itemIndex) in dateGroup.items"
              :key="itemIndex"
              as="div"
              class="usage-history__item"
            >
              <ListItem align="centered">
                <template #leftMainText>
                  <strong class="usage-label">
                    <!-- 거래내역명 -->
                    {{ item.label }}
                    <!-- 계좌번호 끝 4자리 -->
                    {{ item.number }}
                  </strong>
                </template>
                <template #leftSubText>
                  <span class="usage-sub">
                    <!-- 시간 -->
                    <em class="usage-date">{{ item.dateTime }}</em>
                    <!-- 출처 -->
                    <em
                      v-for="(method, methodIndex) in item.paymentMethod"
                      :key="methodIndex"
                    >
                      {{ method }}
                    </em>
                  </span>
                </template>
                <!-- 거절인 경우 is-reject class 추가, 기간 만료 인 경우 is-expired class 추가 -->
                <template #rightMainText>
                  <strong
                    class="usage-amount"
                    :class="{ 'is-reject': item.isReject, 'is-expired': item.isExpired }"
                    >{{ item.amount }}</strong
                  >
                </template>
                <template #rightSubText>
                  <span class="usage-status">
                    <em :class="{ 'is-reject': item.isReject, 'is-expired': item.isExpired }">{{
                      item.status
                    }}</em>
                  </span>
                </template>
              </ListItem>
            </BasicList>
          </div>
        </section>

        <Divider
          v-if="dateIndex < usageHistoryByDate.length - 1"
          variant="basic"
          color="secondary"
        />
      </template>
    </div>

    <!-- 이용내역이 없을 때 -->
    <template v-else>
      <NoData mainText="이용 내역이 없어요." />
    </template>
  </div>
</template>

<script setup>
import { ScIcon } from "@shc-nss/ui/shc";
import {
  BasicCard,
  BasicList,
  BoxButton,
  DatePicker,
  Divider,
  Icon,
  IconButton,
  ListItem,
} from "@shc-nss/ui/solid";
import { addMonths, format, isAfter, startOfMonth } from "date-fns";
import { ko } from "date-fns/locale";
import { computed, ref } from "vue";
import NoData from "../../_module/NoData.vue";

const viewDate = ref(new Date());
const today = new Date();

const title = computed(() => {
  return format(viewDate.value, "yyyy.MM");
});

const titleAriaLabel = computed(() => {
  return format(viewDate.value, "yyyy년 M월", { locale: ko });
});

const currentMonthAriaLabel = computed(() => {
  return `현재 ${titleAriaLabel.value} 이용내역`;
});

const canGoPrev = computed(() => {
  // 이전 달로 이동 가능 여부 (필요시 minDate 체크)
  return true;
});

const canGoNext = computed(() => {
  // 다음 달로 이동 가능 여부: 다음 달이 오늘 날짜보다 미래이면 disabled
  const nextMonth = startOfMonth(addMonths(viewDate.value, 1));
  const currentMonth = startOfMonth(today);
  // 다음 달이 현재 월보다 미래이면 false (이용내역 없음)
  return !isAfter(nextMonth, currentMonth);
});

const prevMonthAriaLabel = computed(() => {
  if (!canGoPrev.value) {
    return "이전 달 이용내역 없음";
  }
  const prevMonth = addMonths(viewDate.value, -1);
  const prevMonthLabel = format(prevMonth, "yyyy년 M월", { locale: ko });
  return `이전 달 ${prevMonthLabel} 이용내역`;
});

const nextMonthAriaLabel = computed(() => {
  if (!canGoNext.value) {
    return "다음 달 이용내역 없음";
  }
  const nextMonth = addMonths(viewDate.value, 1);
  const nextMonthLabel = format(nextMonth, "yyyy년 M월", { locale: ko });
  return `다음 달 ${nextMonthLabel} 이용내역`;
});

const goPrevMonth = () => {
  viewDate.value = addMonths(viewDate.value, -1);
};

const goNextMonth = () => {
  viewDate.value = addMonths(viewDate.value, 1);
};

const getDisplayDate = (date) => {
  // "1월 27일 수요일 오늘" -> "1.27일(수) 오늘" 형식으로 변환
  const match = date.match(/(\d+)월\s+(\d+)일\s+(\S+)(?:\s+오늘)?/);
  if (match) {
    const [, month, day, dayOfWeek] = match;
    const shortDayOfWeek = dayOfWeek.replace("요일", "");
    const hasToday = date.includes("오늘");
    return `${month}.${day}일(${shortDayOfWeek})${hasToday ? " 오늘" : ""}`;
  }
  return date;
};

// 대기 목록 데이터
const pendingList = [
  {
    label: "김신한",
    number: "(4729)",
    dateTime: "09:28",
    paymentMethod: ["신한Pay머니"],
    amount: "100,000원",
    status: "받기대기",
    isReject: false,
    isExpired: false,
    buttons: [
      {
        text: "받기",
        color: "quaternary",
        size: "small",
        class: "text-decrease",
      },
    ],
  },
  {
    label: "김신한",
    number: "(1234)",
    dateTime: "09:28",
    paymentMethod: ["조르기"],
    amount: "200,000원",
    status: "수락대기",
    isReject: false,
    isExpired: false,
    buttons: [
      {
        text: "거절",
        color: "quaternary",
        size: "small",
        class: "",
      },
      {
        text: "수락",
        color: "quaternary",
        size: "small",
        class: "text-decrease",
      },
    ],
  },
  {
    label: "김신한",
    number: "(5678)",
    dateTime: "09:28",
    paymentMethod: ["정기조르기"],
    amount: "150,000원",
    status: "수락대기",
    isReject: false,
    isExpired: false,
    buttons: [
      {
        text: "거절",
        color: "quaternary",
        size: "small",
        class: "",
      },
      {
        text: "수락",
        color: "quaternary",
        size: "small",
        class: "text-decrease",
      },
    ],
  },
];

const usageHistoryByDate = [
  {
    date: "1월 27일 수요일 오늘",
    items: [
      {
        label: "김신한",
        number: "(4729)",
        dateTime: "15:00",
        paymentMethod: ["신한Pay머니"],
        amount: "230,000원",
        status: "보내기 거절(11.18 14:00)",
        isReject: true,
      },
      {
        label: "김신한",
        number: "(4729)",
        dateTime: "15:00",
        paymentMethod: ["신한 Flex(플렉스)"],
        amount: "230,000원",
        status: "보내기 대기 중",
        isReject: false,
      },
      {
        label: "김신한",
        number: "(4729)",
        dateTime: "15:00",
        paymentMethod: ["신한Pay머니"],
        amount: "230,000원",
        status: "보내기 완료",
        isReject: false,
      },
      {
        label: "김신한",
        number: "(4729)",
        dateTime: "15:00",
        paymentMethod: ["신한Pay머니", "신한 Flex(플렉스)"],
        amount: "230,000원",
        status: "보내기 기간만료(11.18 14:00)",
        isReject: false,
        isExpired: true,
      },
    ],
  },
  {
    date: "1월 25일 월요일",
    items: [
      {
        label: "김신한",
        number: "(4729)",
        dateTime: "15:00",
        paymentMethod: ["신한Pay머니"],
        amount: "100,000원",
        status: "보내기 대기 중",
        isReject: false,
      },
      {
        label: "김신한",
        number: "(4729)",
        dateTime: "15:00",
        paymentMethod: ["신한Pay머니"],
        amount: "100,000원",
        status: "보내기 거절(11.18 14:00)",
        isReject: true,
      },
      {
        label: "김신한",
        number: "(4729)",
        dateTime: "15:00",
        paymentMethod: ["신한Pay머니"],
        amount: "190,000원",
        status: "보내기 대기 중",
        isReject: false,
      },
      {
        label: "김신한",
        number: "(4729)",
        dateTime: "15:00",
        paymentMethod: ["신한Pay머니"],
        amount: "190,000원",
        status: "보내기 대기 중",
        isReject: false,
      },
      {
        label: "김신한",
        number: "(4729)",
        dateTime: "15:00",
        paymentMethod: ["신한Pay머니"],
        amount: "230,000원",
        status: "받기 완료",
        isReject: false,
      },
      {
        label: "김신한",
        number: "(4729)",
        dateTime: "15:00",
        paymentMethod: ["신한Pay머니"],
        amount: "230,000원",
        status: "받기 거절(11.18 14:00)",
        isReject: true,
      },
      {
        label: "김신한",
        number: "(4729)",
        dateTime: "15:00",
        paymentMethod: ["신한Pay머니"],
        amount: "230,000원",
        status: "받기 기간만료(11.18 14:00)",
        isReject: false,
        isExpired: true,
      },
    ],
  },
];
</script>

<style lang="scss" scoped>
// 현재 컴포넌트에 제공된 부분에는 상단 년/월 만 선택하는 부분이 없어서 전체 하단 달력 부분 제공 부분까지 호출 후 해당 영역은 숨김
// 개발 방식에 따라 사용 유무 판단
.usage-history__header {
  :deep(.sv-datepicker) {
    .sv-datepicker__body,
    .sv-datepicker__options {
      display: none !important;
    }
  }
}
</style>
