<route lang="yaml">
meta:
  id: SBT178A01_pu2
  title: 
  menu: "혜택 > 앱테크 메인화면 > 지역타겟팅 보물팡팡 플로팅(로띠) > 업데이트 알림(PU)"
  layout: EmptyLayout
  category: 혜택
  publish: 김대민
  publishVersion: 0.9
</route>
<template>
  <ModalPopup
    v-model="isOpen"
    title=""
    dimmed  
  >
    <p class="sc-preline">{{ message }}</p>
    <template #footer>
      <BoxButton
        @click="isAlertModal = false"
        text="닫기"
        color="secondary"
      />
      <BoxButton
        @click="isAlertModal = false"
        text="업데이트 하러 가기"
      />
    </template>
  </ModalPopup>
</template>

<script setup>
import { BoxButton, ModalPopup } from "@shc-nss/ui/solid";

const isOpen = defineModel({ default: true });
const message = "업데이트 알림\n\n최신 버전의 앱으로 업데이트하고 이벤트를 즐겨보세요!";
</script>
