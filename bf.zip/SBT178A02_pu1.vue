<route lang="yaml">
meta:
  id: SBT178A02_pu1
  title: 
  menu: "혜택 > 앱테크 메인화면 > 지역타겟팅 보물팡팡 > 위치 확인 로딩 > 위치 확인 불가 안내(PU)"
  layout: EmptyLayout
  category: 혜택
  publish: 김대민
  publishVersion: 0.9
</route>
<template>
  <!-- 현재 위치 확인 불가 할 경우 Modal 호출 -->
  <ModalPopup
    v-model="isAlertModal"
    title=""
    dimmed
    align="center"
  >
    <p class="sc-preline">{{ message }}</p>
    <template #footer>
      <BoxButton
        @click="isAlertModal = false"
        text="확인"
      />
    </template>
  </ModalPopup>
</template>

<script setup>
import { BoxButton, ModalPopup } from '@shc-nss/ui/solid'

const isAlertModal = defineModel({ default: true })
const message = '현재 위치에서는 참여가 불가능합니다.';
</script>

