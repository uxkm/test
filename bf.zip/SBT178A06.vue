<route lang="yaml">
  meta:
    id: SBT178A06
    title: "약관동의"
    menu: "혜택 > 앱테크 메인화면 > 지역타겟팅 보물팡팡 > 약관동의"
    layout: SubLayout
    category: 혜택
    publish: 김대민
    publishVersion: 0.9
    status: 작업완료
    header:
      fixed: true
      back: false
      close: true
      home: false
  </route>
  <template>
    <FullPopup
      v-model="isOpen"
      :title="bodyTitle"
      :closeable="true"
      @close="handleClose"
    >
      <ScTitle mainTitle="마이신한포인트 적립을 위해<br />약관에 동의해주세요." />
  
      <!-- 콘텐츠 영역 -->
      <div class="sc-contents__body sc-agree__page">
        <section>
          <!-- v0.9 또는 0.8에서 신규로 추가된 부분부터 1뎁스 항목체크 모양은 box->mark로 수정 2뎁스항목은 좌측 들여쓰기 구조 class agree_new 추가 -->
          <div
            class="sc-agree__list compound agree_new"
            role="region"
          >
            <div class="agree-list__group">
              <div
                class="agree-item item-basic"
                :class="{ 'is-checked': basicAgree4 }"
              >
                <Checkbox
                  v-model="basicAgree4"
                  class="agree-item__checkbox item-checkbox__basic"
                  variant="box"
                  align="left"
                >
                  <template #label>
                    <span class="agree-item__label item-label__basic">{{ basicItem4.label }}</span>
                  </template>
                </Checkbox>
              </div>
  
              <!-- ======================================== -->
              <!-- 1뎁스 영역: 기본 약관 항목들 -->
              <!-- ======================================== -->
              <div
                class="agree-sublist"
                role="group"
              >
                <div
                  v-for="item in depth1Items"
                  :key="item.value"
                  class="agree-subitem"
                  :class="{ 'agree-subitem__accordion': Boolean(item.accordion) }"
                >
                  <template v-if="item.accordion">
                    <SolidListAccordion
                      class="agree-subitem__accordion"
                      :rowClickable="false"
                      :value="item.value"
                      v-model:isExpanded="subAccordionState4[item.value]"
                    >
                      <template #title>
                        <div
                          class="agree-item agree-item__sub"
                          :class="{ 'is-checked': subAgrees4.includes(item.value) }"
                        >
                          <Checkbox
                            :value="item.value"
                            variant="mark"
                            align="left"
                            :model-value="subAgrees4.includes(item.value)"
                            class="agree-item__checkbox item-checkbox__sub"
                            @update:model-value="onToggleSub4(item.value, $event)"
                            @click.stop
                          >
                            <template #label>
                              <span class="agree-item__label item-label__sub">{{ item.label }}</span>
                            </template>
                          </Checkbox>
                        </div>
                      </template>
                    <div class="agree-subitem__panel">
                      <div
                        v-if="item.value === 's4-4'"
                        class="agree-depth"
                      >
                        <ul class="agree-sublist agree-sublist__depth2">
                          <li
                            v-for="depth2Item in subItemsDepth2_s4_4"
                            :key="depth2Item.value"
                            class="agree-subitem agree-subitem__depth2"
                          >
                            <template v-if="depth2Item.accordion">
                              <SolidListAccordion
                                class="agree-subitem__accordion accordion-depth2"
                                :rowClickable="false"
                                :value="depth2Item.value"
                                v-model:isExpanded="subAccordionState4[depth2Item.value]"
                              >
                                <template #title>
                                  <div class="agree-item agree-item__sub">
                                    <Checkbox
                                      :value="depth2Item.value"
                                      variant="mark"
                                      align="left"
                                      :model-value="subAgrees4.includes(depth2Item.value)"
                                      class="agree-item__checkbox item-checkbox__sub"
                                      @update:model-value="onToggleSub4(depth2Item.value, $event)"
                                      @click.stop
                                    >
                                      <template #label>
                                        <span class="agree-item__label item-label__sub">{{
                                          depth2Item.label
                                        }}</span>
                                      </template>
                                    </Checkbox>
                                  </div>
                                </template>
                                <div class="agree-subitem__panel">
                                  <div
                                    v-if="depth2Item.value === 's4-4-5'"
                                    class="agree-depth"
                                  >
                                    <Card
                                      variant="solid"
                                      color="gray"
                                      class="agree-details"
                                    >
                                      <ul
                                        class="agree-sublist"
                                        role="group"
                                      >
                                        <li
                                          v-for="depth3Item in subItemsDepth3_s4_4_5"
                                          :key="depth3Item.value"
                                          class="agree-subitem agree-subitem__depth3"
                                        >
                                          <div class="agree-item agree-item__sub">
                                            <span class="agree-item__label item-label__sub">{{
                                              depth3Item.label
                                            }}</span>
                                            <IconButton
                                              iconName="Chevron_right"
                                              size="small"
                                              :aria-label="`${depth3Item.label} 상세 보기`"
                                              class="agree-subitem__trigger"
                                            />
                                          </div>
                                        </li>
                                      </ul>
                                    </Card>
                                  </div>
                                </div>
                              </SolidListAccordion>
                            </template>
                            <div
                              v-else
                              class="agree-item agree-item__sub"
                            >
                              <Checkbox
                                :value="depth2Item.value"
                                variant="mark"
                                align="left"
                                :model-value="subAgrees4.includes(depth2Item.value)"
                                class="agree-item__checkbox item-checkbox__sub"
                                @update:model-value="onToggleSub4(depth2Item.value, $event)"
                                @click.stop
                              >
                                <template #label>
                                  <span class="agree-item__label item-label__sub">{{
                                    depth2Item.label
                                  }}</span>
                                </template>
                              </Checkbox>
                              <IconButton
                                iconName="Chevron_right"
                                size="small"
                                :aria-label="`${depth2Item.label} 상세 보기`"
                                class="agree-subitem__trigger"
                              />
                            </div>
                          </li>
                        </ul>
                      </div>
                    </div>
                    </SolidListAccordion>
                  </template>
                  <template v-else>
                    <div
                      class="agree-item agree-item__sub"
                      :class="{ 'is-checked': subAgrees4.includes(item.value) }"
                    >
                      <Checkbox
                        :value="item.value"
                        variant="mark"
                        align="left"
                        :model-value="subAgrees4.includes(item.value)"
                        class="agree-item__checkbox item-checkbox__sub"
                        @update:model-value="onToggleSub4(item.value, $event)"
                        @click.stop
                      >
                        <template #label>
                          <span class="agree-item__label item-label__sub">{{ item.label }}</span>
                        </template>
                      </Checkbox>
                      <IconButton
                        iconName="Chevron_right"
                        size="small"
                        :aria-label="`${item.label} 상세 보기`"
                        class="agree-subitem__trigger"
                      />
                    </div>
                  </template>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
  
      <BottomActionContainer :scrollDim="true">
        <BoxButtonGroup
          size="xlarge"
          variant="100"
        >
          <BoxButton
            text="확인"
            :disabled="!basicAgree4"
          />
        </BoxButtonGroup>
      </BottomActionContainer>
    </FullPopup>
  </template>
  
  <script setup>
  import { ScTitle } from "@shc-nss/ui/shc";
  import {
    BottomActionContainer,
    BoxButton,
    BoxButtonGroup,
  Card,
    Checkbox,
    FullPopup,
    IconButton,
    SolidListAccordion,
  } from "@shc-nss/ui/solid";
  import { computed, reactive, ref, watch } from "vue";
  import { useRoute } from "vue-router";
  
  const route = useRoute();
  const bodyTitle = computed(() => route.meta?.title || "");
  const isOpen = defineModel({ default: true });
  
  const handleClose = () => {
    isOpen.value = false;
  };
  
  /**
   * 유형 4 : 약관동의 기본형
   */
  const basicItem4 = {
    label: "약관 전체 동의",
  };
  
const depth1Items = [
  {
    label: "[필수] 신한 슈퍼SOL 이용약관",
    value: "s4-4",
    accordion: true,
  },
];

  const subItemsDepth2_s4_4 = [
    { label: "[필수] 신한 모바일 플랫폼 이용약관", value: "s4-4-1" },
    { label: "[필수] 신한금융그룹 통합 포인트 서비스 이용 동의", value: "s4-4-2" },
    { label: "[필수] 개인(신용)정보 수집・이용・제공 동의", value: "s4-4-3" },
    { label: "[필수] 개인(신용)정보 수집・이용・제공 동의(포인트 서비스 제공)", value: "s4-4-4" },
    { label: "[필수] 전자금융서비스 이용동의(신한은행)", value: "s4-4-5", accordion: true },
    { label: "[필수] 그룹 로열티 서비스 이용동의(신한은행)", value: "s4-4-6" },
    { label: "[필수] 개인(신용)정보 수집・이용・제공 동의(신한은행)", value: "s4-4-7" },
  ];

  const subItemsDepth3_s4_4_5 = [
    { label: "전자금융거래 기본약관", value: "s4-4-5-1" },
    { label: "신한온라인서비스 이용약관", value: "s4-4-5-2" },
    { label: "전자통지서비스 이용약관", value: "s4-4-5-3" },
    { label: "개인정보 수집 이용동의(비여신금융거래)", value: "s4-4-5-4" },
  ];
  
  const basicAgree4 = ref(false);
  const subAgrees4 = ref([]);
  const subAccordionState4 = reactive({
    "s4-4": true,
    "s4-4-5": false,
  });
  
  /**
   * 동작 로직
   */
  function onToggleSub4(value, checked) {
    const set = new Set(subAgrees4.value);
    if (checked) set.add(value);
    else set.delete(value);
    subAgrees4.value = Array.from(set);
  
    // 전체 항목 수 계산 (1뎁스 + 2뎁스 + 3뎁스)
  const totalItems = depth1Items.length + subItemsDepth2_s4_4.length;
    basicAgree4.value = set.size === totalItems;
  }
  
  watch(basicAgree4, (checked) => {
    if (checked) {
      // 1뎁스 항목들 + 아코디언 내부의 모든 하위 항목들 (2뎁스 + 3뎁스)
      const allItems = [
        ...depth1Items.map((item) => item.value),
        ...subItemsDepth2_s4_4.map((item) => item.value),
      ];
      subAgrees4.value = allItems;
    } else {
      subAgrees4.value = [];
    }
  });
  </script>
  