<route lang="yaml">
meta:
  id: SBT178A01_pu1
  title: 
  menu: "혜택 > 앱테크 메인화면 > 지역타겟팅 보물팡팡 플로팅(로띠) > 이벤트 대상자 안내(PU)"
  layout: EmptyLayout
  category: 혜택
  publish: 김대민
  publishVersion: 0.9
</route>
<template>
  <ModalPopup
    v-model="isOpen"
    title=""
    dimmed
    align="center"
  >
    <p class="sc-preline">{{ message }}</p>
    <template #footer>
      <BoxButton
        @click="isAlertModal = false"
        text="확인"
      />
    </template>
  </ModalPopup>
</template>

<script setup>
import { BoxButton, ModalPopup } from "@shc-nss/ui/solid";

const isOpen = defineModel({ default: true });
const message = "이벤트 대상자가 아닙니다.";
</script>
