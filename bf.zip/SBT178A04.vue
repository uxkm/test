<route lang="yaml">
meta:
  id: SBT178A04
  title: "약관동의"
  menu: "혜택 > 앱테크 메인화면 > 지역타겟팅 보물팡팡 > 약관동의"
  layout: SubLayout
  category: 혜택
  publish: 김대민
  publishVersion: 0.9
  status: 작업완료
  header:
    fixed: true
    back: false
    close: true
    home: false
</route>
<template>
  <FullPopup
    v-model="isOpen"
    :title="bodyTitle"
    :closeable="true"
    @close="handleClose"
  >
    <ScTitle mainTitle="마이신한포인트 적립을 위해<br />약관에 동의해주세요." />

    <!-- 콘텐츠 영역 -->
    <div class="sc-contents__body sc-agree__page">
      <section>
        <!-- v0.9 또는 0.8에서 신규로 추가된 부분부터 1뎁스 항목체크 모양은 box->mark로 수정 2뎁스항목은 좌측 들여쓰기 구조 class agree_new 추가 -->
        <div
          class="sc-agree__list compound agree_new"
          role="region"
        >
          <div class="agree-list__group">
            <div
              class="agree-item item-basic"
              :class="{ 'is-checked': basicAgree4 }"
            >
              <Checkbox
                v-model="basicAgree4"
                class="agree-item__checkbox item-checkbox__basic"
                variant="box"
                align="left"
              >
                <template #label>
                  <span class="agree-item__label item-label__basic">{{ basicItem4.label }}</span>
                </template>
              </Checkbox>
            </div>

            <!-- ======================================== -->
            <!-- 1뎁스 영역: 기본 약관 항목들 -->
            <!-- ======================================== -->
            <div
              class="agree-sublist"
              role="group"
            >
              <div
                v-for="item in depth1Items"
                :key="item.value"
                class="agree-subitem"
                :class="{ 'agree-subitem__accordion': Boolean(item.accordion) }"
              >
                <template v-if="item.accordion">
                  <SolidListAccordion
                    class="agree-subitem__accordion"
                    :rowClickable="false"
                    :value="item.value"
                    v-model:isExpanded="subAccordionState4[item.value]"
                  >
                    <template #title>
                      <div
                        class="agree-item agree-item__sub"
                        :class="{ 'is-checked': subAgrees4.includes(item.value) }"
                      >
                        <Checkbox
                          :value="item.value"
                          variant="mark"
                          align="left"
                          :model-value="subAgrees4.includes(item.value)"
                          class="agree-item__checkbox item-checkbox__sub"
                          @update:model-value="onToggleSub4(item.value, $event)"
                          @click.stop
                        >
                          <template #label>
                            <span class="agree-item__label item-label__sub">{{ item.label }}</span>
                          </template>
                        </Checkbox>
                      </div>
                    </template>
                    <div class="agree-subitem__panel">
                      <div class="agree-depth">
                        <UnorderedList class="sc-info__list">
                          <UnorderedListItem
                            variant="bullet"
                            size="small"
                            text="신한 SOL페이에서 제공하는 쿠폰, 이벤트 등 다양한 혜택 정보를 고객님의 위치 기준으로 받으실 수 있습니다."
                          />
                        </UnorderedList>
                        <ul class="agree-sublist agree-sublist__depth2">
                          <li
                            v-for="depth2Item in subItemsDepth2_locationService"
                            :key="depth2Item.value"
                            class="agree-subitem agree-subitem__depth2"
                          >
                            <div class="agree-item agree-item__sub">
                              <Checkbox
                                :value="depth2Item.value"
                                variant="mark"
                                align="left"
                                :model-value="subAgrees4.includes(depth2Item.value)"
                                class="agree-item__checkbox item-checkbox__sub"
                                @update:model-value="onToggleSub4(depth2Item.value, $event)"
                                @click.stop
                              >
                                <template #label>
                                  <span class="agree-item__label item-label__sub">{{
                                    depth2Item.label
                                  }}</span>
                                </template>
                              </Checkbox>
                              <IconButton
                                iconName="Chevron_right"
                                size="small"
                                :aria-label="`${depth2Item.label} 상세 보기`"
                                class="agree-subitem__trigger"
                              />
                            </div>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </SolidListAccordion>
                </template>
                <template v-else>
                  <div
                    class="agree-item agree-item__sub"
                    :class="{ 'is-checked': subAgrees4.includes(item.value) }"
                  >
                    <Checkbox
                      :value="item.value"
                      variant="mark"
                      align="left"
                      :model-value="subAgrees4.includes(item.value)"
                      class="agree-item__checkbox item-checkbox__sub"
                      @update:model-value="onToggleSub4(item.value, $event)"
                      @click.stop
                    >
                      <template #label>
                        <span class="agree-item__label item-label__sub">{{ item.label }}</span>
                      </template>
                    </Checkbox>
                    <IconButton
                      iconName="Chevron_right"
                      size="small"
                      :aria-label="`${item.label} 상세 보기`"
                      class="agree-subitem__trigger"
                    />
                  </div>
                </template>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>

    <BottomActionContainer :scrollDim="true">
      <BoxButtonGroup
        size="xlarge"
        variant="100"
      >
        <BoxButton
          text="확인"
          :disabled="!basicAgree4"
        />
      </BoxButtonGroup>
    </BottomActionContainer>
  </FullPopup>
</template>

<script setup>
import { ScTitle } from "@shc-nss/ui/shc";
import {
  BottomActionContainer,
  BoxButton,
  BoxButtonGroup,
  Checkbox,
  FullPopup,
  IconButton,
  SolidListAccordion,
  UnorderedList,
  UnorderedListItem,
} from "@shc-nss/ui/solid";
import { computed, reactive, ref, watch } from "vue";
import { useRoute } from "vue-router";

const route = useRoute();
const bodyTitle = computed(() => route.meta?.title || "");
const isOpen = defineModel({ default: true });

const handleClose = () => {
  isOpen.value = false;
};

/**
 * 유형 4 : 약관동의 기본형
 */
const basicItem4 = {
  label: "약관 전체 동의",
};

const depth1Items = [
  {
    label: "[필수] 신한카드 위치기반 사업자 약관동의",
    value: "location-business-terms",
  },
  {
    label: "[필수] 위치정보 서비스 동의사항",
    value: "location-service-consent",
    accordion: true,
  },
  {
    label: "[필수] 위치기반 혜택 알림 수신 동의",
    value: "location-benefit-notification",
  },
  {
    label: "[필수] 개인정보 수집 및 이용 동의서",
    value: "privacy-collection-consent",
  },
];

const subItemsDepth2_locationService = [
  {
    label: "[필수] LG U+ 위치정보 사업자 약관 동의",
    value: "lg-uplus-location-terms",
  },
  {
    label: "[필수] LG U+ 개인정보수집 이용 및 제3자 제공동의",
    value: "lg-uplus-privacy-consent",
  },
  {
    label: "[필수] 로플렛 위치정보 사업자 약관 동의",
    value: "roplet-location-terms",
  },
];

const basicAgree4 = ref(false);
const subAgrees4 = ref([]);
const subAccordionState4 = reactive({
  "location-service-consent": true,
});

/**
 * 동작 로직
 */
function onToggleSub4(value, checked) {
  const set = new Set(subAgrees4.value);
  if (checked) set.add(value);
  else set.delete(value);
  subAgrees4.value = Array.from(set);

  // 전체 항목 수 계산 (1뎁스 + 2뎁스 + 3뎁스)
  const totalItems = depth1Items.length + subItemsDepth2_locationService.length;
  basicAgree4.value = set.size === totalItems;
}

watch(basicAgree4, (checked) => {
  if (checked) {
    // 1뎁스 항목들 + 아코디언 내부의 모든 하위 항목들 (2뎁스 + 3뎁스)
    const allItems = [
      ...depth1Items.map((item) => item.value),
      ...subItemsDepth2_locationService.map((item) => item.value),
    ];
    subAgrees4.value = allItems;
  } else {
    subAgrees4.value = [];
  }
});
</script>
