<route lang="yaml">
meta:
  id: SBT178A02
  title: 
  menu: "혜택 > 앱테크 메인화면 > 지역타겟팅 보물팡팡 > 위치 확인 로딩"
  layout: EmptyLayout
  category: 혜택
  publish: 김대민
  publishVersion: 0.9
</route>
<template>
  <!-- 위치 확인 로딩 -->
  <div
    v-if="treasureModal"
    role="dialog"
    tabindex="-1"
    class="treasure-modal"
  >
    <div class="treasure-modal-content">
      <div
        v-if="!isTreasureFound"
        class="treasure-loading-pending"
        aria-label="위치를 확인 중이에요 잠시만 기다려주세요"
        tabindex="0"
      >
        <div class="loading-pending" aria-hidden="true">
          <div class="lottie">
            <ScLottie
              :animation-link="`${cdnURL}/images/lottie/common/treasure_hunt_loading.json`"
              :width="40"
              :height="40"
              :loop="true"
              :autoPlay="true"
              @onAnimationLoaded="handleAnimation1"
            />
          </div>
        </div>
        <div class="loading-enter" aria-hidden="true">
          <p class="loading-enter-text">
            <!-- <img :src="`${cdnURL}/images/pages/benefits/main/loading-enter-text.svg`" alt="위치를 확인 중이에요 잠시만 기다려주세요" /> -->
            <span>
              위치를 확인 중이에요<br />
              <strong>
                잠시만 기다려주세요
              </strong>
            </span>
          </p>
          <ScLottie
            :animation-link="`${cdnURL}/images/lottie/common/treasure_hunt_compass.json`"
            :width="200"
            :height="220"
            :loop="true"
            :autoPlay="true"
            @onAnimationLoaded="handleAnimation2"
          />
        </div>
      </div>
    </div>
  </div>

  <!-- 포인트 적립 시 노출 화면 -->
  <FullPopup
    v-if="foundModal"
    v-model="foundModal"
    title="보물확인"
    class="treasure-modal"
  >
    <div
      v-if="isTreasureFound"
      ref="modalCont"
      class="treasure-loading-enter"
    >
      <div class="treasure-loading-body">
        <p class="treasure-loading-body-text">
          축하드려요!<br />
          <strong>보물을 찾으셨네요.</strong>
        </p>
        <div class="treasure-loading-lottie">
          <!-- 등장 로티 -->
          <Vue3Lottie
            v-if="options1.animationData"
            :animation-data="options1.animationData"
            :loop="options1.loop"
            :auto-play="true"
            :width="360"
            :height="537"
            @on-animation-loaded="handleAnimation1"
          />
        </div>
        <strong class="treasure-loading-point">
          3P
        </strong>
      </div>
    </div>
  </FullPopup>

  <!-- 현재 위치 확인 불가 할 경우 Modal 호출 -->
  <ModalPopup
    v-model="isAlertModal"
    title=""
    dimmed
    align="center"
  >
    <p class="sc-preline">{{ message }}</p>
    <template #footer>
      <BoxButton
        @click="isAlertModal = false"
        text="확인"
      />
    </template>
  </ModalPopup>
</template>

<script setup>
import { ScIcon, ScLottie } from '@shc-nss/ui/shc'
import { BoxButton, FullPopup, ModalPopup } from '@shc-nss/ui/solid'
import { Vue3Lottie } from 'vue3-lottie'
import { computed, inject, onMounted, ref } from 'vue'
import { AppContextKey } from '@/configs/inject/appContext'

const appContext = inject(AppContextKey, null)
const cdnURL = computed(() => appContext?.$cdnURL ?? '')

// treasure modal
const treasureModal = ref(true)
const foundModal = ref(false)
const isTreasureFound = ref(false)
const isAlertModal = ref(false)

const anim1 = ref(null)
const anim2 = ref(null)
const options1 = ref({
  animationData: null,
  loop: false
})
const options2 = ref({
  animationData: null,
  autoplay: false
})

const buildLottieUrl = (fileName) => {
  const base = cdnURL.value ? cdnURL.value.replace(/\/$/, '') : ''
  return `${base}/images/lottie/common/${fileName}`
}

const loadLottieData = async (fileName, targetOptions) => {
  try {
    const response = await fetch(buildLottieUrl(fileName))
    if (!response.ok) {
      return
    }
    targetOptions.value.animationData = await response.json()
  } catch (error) {
    // ignore fetch errors for publish-only template
  }
}

const handleAnimation1 = (anim) => {
  anim1.value = anim
}

const handleAnimation2 = (anim) => {
  anim2.value = anim
}

const handleClose = () => {
  foundModal.value = false
}

// 팝업 상태 관리
// const isOpen = defineModel({ default: true });

const message = '현재 위치에서는 참여가 불가능합니다.';


onMounted(() => {
  loadLottieData('etc_treasure_enter.json', options1)
  loadLottieData('etc_treasure_waiting.json', options2)
  // UI 확인용 임시 처리 개발시 수정하여 작업 - 포인트 적립 시 노출
  setTimeout(() => {
    isTreasureFound.value = true
    treasureModal.value = false
    foundModal.value = true
  }, 3000)
})
</script>

