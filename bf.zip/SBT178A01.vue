<route lang="yaml">
meta:
  id: SBT178A01
  title: 
  menu: "혜택 > 앱테크 메인화면 > 지역타겟팅 보물팡팡 플로팅(로띠)"
  layout: EmptyLayout
  category: 혜택
  publish: 김대민
  publishVersion: 0.9
</route>
<template>
  <!-- 모달처럼 body 하위 요소에 추가 -->
  <teleport to="body">
    <!-- 상황에 맞게 z-index 조절 필요 -->
    <div class="floating-treasure" style="--z-index: 100;">
      <div class="treasure-container">
        <div class="treasure-content">
          <a role="link" class="treasure-trigger" tabindex="0" aria-label="보물이에요!">
            <!-- 등장 로티 -->
            <ScLottie
              v-if="prevShow"
              :animation-link="`${cdnURL}/images/lottie/common/treasure_hunt_trigger_coin_01.json`"
              :width="118"
              :height="134"
              :loop="false"
              :autoPlay="true"
              @onAnimationLoaded="handleAnimation1"
              aria-hidden="true"
            />
            <!-- 대기 로티 -->
            <ScLottie
              v-if="nextShow"
              :animation-link="`${cdnURL}/images/lottie/common/treasure_hunt_trigger_coin_02.json`"
              :width="118"
              :height="134"
              :loop="true"
              :autoPlay="true"
              @onAnimationLoaded="handleAnimation2"
              aria-hidden="true"
            />
            <span v-if="nextShow" class="treasure-tooltip" aria-hidden="true">보물이에요!</span>
          </a>
        </div>
        <button
          type="button"
          aria-label="닫기"
          class="treasure-close"
        >
          <span
            class="treasure-close-icon"
            aria-hidden="true"
          >
            <ScIcon
              iconName="X"
              size="12"
            />
          </span>
        </button>
      </div>
    </div>
  </teleport>
</template>

<script setup>
import { inject, onBeforeUnmount, onMounted, ref } from "vue";
import { ScIcon, ScLottie } from "@shc-nss/ui/shc";
import { AppContextKey } from "@/configs/inject/appContext";

const appContext = inject(AppContextKey, null);
const cdnURL = appContext?.$cdnURL ?? "";

const prevShow = ref(true);
const nextShow = ref(false);
const anim1 = ref(null);
const anim2 = ref(null);
let swapTimer = null;

function scheduleSwap() {
  if (swapTimer) {
    return;
  }
  swapTimer = setTimeout(() => {
    prevShow.value = false;
    nextShow.value = true;
  }, 1000);
}

function handleAnimation1(anim) {
  anim1.value = anim;
  scheduleSwap();
}

function handleAnimation2(anim) {
  anim2.value = anim;
}

onMounted(() => {
  scheduleSwap();
});

onBeforeUnmount(() => {
  if (swapTimer) {
    clearTimeout(swapTimer);
  }
});
</script>
